import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/theme/theme.dart';

Widget loading({Color? color = kBlackColor}) {
  return Center(
    child: SizedBox(
      height: 35,
      width: 35,
      child: CircularProgressIndicator(color: color ?? kBlackColor),
    ),
  );
}

Container circularProgress() {
  return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.only(top: 10.0),
      child: const CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation(Colors.black),
      ));
}

showLoadingDialog(context) {
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (context) {
      return WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: AlertDialog(
          insetPadding: const EdgeInsets.all(fixPadding * 2.0),
          contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 3.0, horizontal: fixPadding * 2.0),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                height: 35,
                width: 35,
                child: CircularProgressIndicator(
                  color: lightBlackColor,
                ),
              ),
              heightSpace,
              height5Space,
              Text(
                getTranslation(context, 'otp.please_wait'),
                style: semibold16LightBlack,
              )
            ],
          ),
        ),
      );
    },
  );
}

showCircularLoadingDialog(context) {
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (context) {
      return WillPopScope(
        onWillPop: () async {
          return false;
        },
        child: const SizedBox(
          height: 35,
          width: 35,
          child: Center(
            child: CircularProgressIndicator(
              color: blackColor,
              strokeWidth: 5.0,
            ),
          ),
        ),
      );
    },
  );
}

openDialog({String? title, String? description, String? buttonText, Function()? onCancel, Function()? onPressed}) {
  Get.dialog(
    AlertDialog(
      insetPadding: const EdgeInsets.all(fixPadding * 2.0),
      contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 3.0, horizontal: fixPadding * 2.0),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          heightSpace,
          height5Space,
          Text(
            "",
            style: semibold16LightBlack,
          ),
          height5Space,
          height5Space,
          height5Space,
        ],
      ),
    ),
  );
}
