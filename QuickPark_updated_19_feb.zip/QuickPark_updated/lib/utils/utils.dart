import 'dart:async';
import 'dart:developer';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:url_launcher/url_launcher.dart';

class Utils {
  static showCustomSnackBar(BuildContext context, String message, {int duration = 3}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: Duration(seconds: duration),
      ),
    );
  }

  static void toast(String message, {Toast toastLength = Toast.LENGTH_SHORT}) {
    unawaited(
      Fluttertoast.showToast(
        msg: message,
        backgroundColor: Colors.black87,
        textColor: Colors.white,
        toastLength: toastLength,
      ),
    );
  }

  static void errorToast(String message, {Toast toastLength = Toast.LENGTH_SHORT}) {
    unawaited(
      Fluttertoast.showToast(
        msg: message,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        toastLength: toastLength,
      ),
    );
  }

  static Future<void> openMap(double latitude, double longitude) async {
    String googleUrl = 'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
    if (await canLaunchUrl(Uri.parse(googleUrl))) {
      await launch(googleUrl);
    } else {
      errorToast("Something wrong Please try again");
    }
  }

  static launchUrl(url) async {
    if (await canLaunchUrl(url)) {
      launchUrl(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  static Future<bool> requestLocationPermission() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      log("Location services are disabled. Please enable the services");
      return false;
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        log("Location permissions are denied");
        return false;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      log("Location permissions are permanently denied, we cannot request permissions.");
      return false;
    }
    return true;
  }

  static Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
  }

  DateTime? backPressTime;

  onWillPop(context) {
    DateTime now = DateTime.now();
    if (backPressTime == null || now.difference(backPressTime!) >= const Duration(seconds: 2)) {
      backPressTime = now;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: blackColor,
          content: Text(
            getTranslation(context, 'app_exit.exit_text'),
            style: bold15White,
          ),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(milliseconds: 1500),
        ),
      );
      return Future.value(false);
    } else {
      return Future.value(true);
    }
  }
}

hideKeyBoard(BuildContext context) {

  FocusScope.of(context).requestFocus(FocusNode());
  FocusManager.instance.primaryFocus?.unfocus();
  // FocusScope.of(context).unfocus();

  SystemChannels.textInput.invokeMethod('TextInput.hide');
}

class MapUtils {
  //+ this means we cannot make the instance of this class
  //+ make all members static so that we can access.
  MapUtils._();
}
