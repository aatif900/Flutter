//
import 'dart:developer';

String getMessageFromErrorCode(errorCode) {
  log("Passed errorCode $errorCode");
  switch (errorCode) {
    //+SIGN UP
    case "weak-password":
      return "The password provided is too weak.";

    case "email-already-in-use":
      return "An account is already registered with your email address";

    case "invalid-email":
      return "Email address is invalid.";

    case "operation-not-allowed":
      return "Email/password accounts are not enabled. Please enable them in the Firebase Console.";

    //+SIGN IN
    case "user-not-found":
      return "No user found with this email.";

    case "wrong-password":
      return "Wrong password combination.";

    case "INVALID_LOGIN_CREDENTIALS":
      return "Enter credentials is not correct please try again";

    //+PHONE
    case "invalid-phone-number":
      return "The provided phone number is not valid.";

    case "too-many-requests":
      // return "Too many requests please try again after some time.";
      return "Please verify your email address";

    case "credential-already-in-use":
      return "Already in use";

    case "provider-already-linked":
      return "This phone number is already linked ! Please try with different number";

    //

    case "ERROR_USER_DISABLED":
    case "user-disabled":
      return "User disabled.";
    case "ERROR_TOO_MANY_REQUESTS":
    case "account-exists-with-different-credential":
    case "ERROR_OPERATION_NOT_ALLOWED":
    case "ERROR_INVALID_EMAIL":
    default:
      return "Something went wrong. Please try again.";
  }
}








