import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/pages/booking/select_vehicle.dart';
import 'package:parkingproject/pages/screens.dart';

Route<dynamic>? routes(settings) {
  switch (settings.name) {
    case '/':
      return PageTransition(child: const SplashScreen(), type: PageTransitionType.fade, settings: settings);
    case '/onboarding':
      return PageTransition(child: const OnBoardingScreen(), type: PageTransitionType.fade, settings: settings);
    case '/login':
      return PageTransition(child: const LoginScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/register':
      return PageTransition(child: const RegisterScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/otp':
      return PageTransition(child: const OTPScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/bottomBar':
      return PageTransition(child: const BottomBar(), type: PageTransitionType.fade, settings: settings);
    case '/home':
      return PageTransition(child: const HomeScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/notification':
      return PageTransition(child: const NotificationScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/detail':
      return PageTransition(child: DetailScreen(parkingModel: ParkingModel()), type: PageTransitionType.rightToLeft, settings: settings);
    case '/review':
      return PageTransition(child: const ReviewScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/images':
      return PageTransition(child: const ImageScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/direction':
      return PageTransition(child: const DirectionScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/arrived':
      return PageTransition(child: const ArrivedScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/parkingTime':
      return PageTransition(child: const ParkingTimeScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/extendParkingTime':
      return PageTransition(child: const ExtendParkingTimeScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/paymentMethods':
      return PageTransition(child: const PaymentMethodsScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/creditCard':
      return PageTransition(child: const CreditCardScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/bookingConfirm':
      return PageTransition(child: const BookingConfirmationScreen(), type: PageTransitionType.rightToLeft, settings: settings);

    /*case '/parkingTicket':
      return PageTransition(child: const ParkingTicketScreen(), type: PageTransitionType.rightToLeft, settings: settings);*/

    case '/selectVehical':
      return PageTransition(child: SelectVehicleScreen(parkingModel: ParkingModel()), type: PageTransitionType.rightToLeft, settings: settings);
    case '/addVehical':
      return PageTransition(child: const AddVehicleScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/bookParkingDetail':
      return PageTransition(child: const BookParkingDetailScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/selectSlot':
      return PageTransition(child: const SelectSlotScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/myBooking':
      return PageTransition(child: const MyBookingScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/bookMark':
      return PageTransition(child: const BookMarkScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/profile':
      return PageTransition(child: const ProfileScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/editProfile':
      return PageTransition(child: const EditProfileScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/wallet':
      return PageTransition(child: const WalletScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/myVehicle':
      return PageTransition(child: const MyVehicleScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/helpAndSupport':
      return PageTransition(child: const HelpSupportScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/privacyPolicy':
      return PageTransition(child: const PrivacyPolicyScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/termsCondition':
      return PageTransition(child: const TermsAndConditionScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/languages':
      return PageTransition(child: const LanguagesScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    case '/appSettings':
      return PageTransition(child: const AppSettingsScreen(), type: PageTransitionType.rightToLeft, settings: settings);
    default:
      return null;
  }
}
