//+NEW SEARCH FIELD
/*  Row(
                        children:   [
                             Expanded(
                            child: Container(
                              // padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10.0),
                                color: whiteColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: blackColor.withOpacity(0.25),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                              child: Theme(
                                data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                                child: SizedBox(
                                  height: 60,
                                  child: GooglePlaceAutoCompleteTextField(
                                    textEditingController: searchTextEditingController,
                                    googleAPIKey: googleMapApiKey,
                                    // debounceTime: 100,
                                    isCrossBtnShown: true,
                                    isLatLngRequired: false,
                                    countries: const ["in", "fr"],

                                    inputDecoration: InputDecoration(
                                      // contentPadding: EdgeInsets.zero,
                                      hintText: "Search",
                                      // border: InputBorder.none,
                                      border: InputBorder.none,
                                      hintStyle: bold15Grey,
                                      enabledBorder: InputBorder.none,
                                      prefixIcon: const Icon(Icons.search, size: 20),
                                    ),

                                    getPlaceDetailWithLatLng: (Prediction prediction) {
                                      print("placeDetails ${prediction.lat}");
                                    },

                                    itemClick: (Prediction prediction) async {
                                      searchTextEditingController.text = prediction.description ?? "";
                                      searchTextEditingController.selection = TextSelection.fromPosition(TextPosition(offset: prediction.description?.length ?? 0));

                                      //+ this is where we can either navigate to map or put a pin on the map on this same page and close the list

                                      hideKeyBoard(context);
                                      final placeId = prediction.placeId!;
                                      final details = await googlePlace.details.get(placeId);
                                      log("details ${details.toString()}");
                                      log("details ${details?.result}");
                                      lat = details?.result?.geometry?.location?.lat ?? 0.0;
                                      lng = details?.result?.geometry?.location?.lng ?? 0.0;
                                      log("lat long are: $lat & lng: $lng");
                                      location = prediction.description ?? "";
                                      searchTextEditingController.text = prediction.description ?? "";

                                      homeProvider.googleMapController?.animateCamera(CameraUpdate.newLatLng(LatLng(lat ?? 0.0, lng ?? 0.0)));
                                      homeProvider.allMarkers.add(Marker(
                                        markerId: const MarkerId("locationMarker"),
                                        position: LatLng(lat ?? 0.0, lng ?? 0.0),
                                        icon: BitmapDescriptor.fromBytes(await Utils.getBytesFromAsset("assets/home/parkingMarker.png", 70)),
                                        infoWindow: const InfoWindow(title: "Location"),
                                      ));

                                      setState(() {});
                                    },
                                    seperatedBuilder: const Divider(),
                                    itemBuilder: (context, index, Prediction prediction) {
                                      return SingleChildScrollView(
                                        child: Container(
                                          padding: const EdgeInsets.all(10),
                                          child: Row(
                                            children: [
                                              const Icon(Icons.location_on),
                                              const SizedBox(
                                                width: 7,
                                              ),
                                              Expanded(
                                                child: Text(prediction.description ?? ""),
                                              )
                                            ],
                                          ),
                                        ),
                                      );
                                    },

                                    // default 600 ms ,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 5),
                           Container(
                            height: 50,
                            // padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
                            decoration: BoxDecoration(
                              color: whiteColor,
                              borderRadius: BorderRadius.circular(10.0),
                              boxShadow: [
                                BoxShadow(
                                  color: blackColor.withOpacity(0.25),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                            child: IconButton(
                              onPressed: () {
                                pageNavigator(context, const ApplyFilterPage());
                              },
                              icon: const Icon(
                                Icons.filter_list_outlined,
                                color: lightBlackColor,
                              ),
                            ),
                          )
                        ],
                      ),*/

//+filterBottomSheet
/*
  filterBottomSheet(ui.Size size, BuildContext context) {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    FilterProvider filterProvider = Provider.of<FilterProvider>(context, listen: false);

    return showModalBottomSheet(
      isScrollControlled: true,
      constraints: BoxConstraints(
        maxHeight: size.height - 80,
      ),
      backgroundColor: Colors.transparent,
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, state) {
          return Container(
            width: double.maxFinite,
            decoration: const BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(20.0),
              ),
            ),
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(vertical: fixPadding * 2.0),
              physics: const BouncingScrollPhysics(),
              children: [
                Column(
                  children: [
                    Container(
                      height: 2,
                      width: 60,
                      decoration: const BoxDecoration(
                        color: greyD9Color,
                      ),
                    ),
                    heightSpace,
                    height5Space,
                    Text(
                      getTranslation(context, 'extend_parking_time.filter'),
                      style: bold18TextColor,
                    ),
                    heightSpace,
                    height5Space,
                    Container(
                      height: 1,
                      width: double.maxFinite,
                      color: greyD4Color,
                    )
                  ],
                ),
                heightSpace,
                heightSpace,
                //+DISTANCE
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                      child: Text(
                        getTranslation(context, 'extend_parking_time.distance'),
                        style: bold16LightBlack,
                      ),
                    ),
                    heightSpace,
                    heightSpace,
                    SfSliderTheme(
                      data: SfSliderThemeData(
                        thumbStrokeWidth: 1.5,
                        thumbStrokeColor: whiteColor,
                        tooltipBackgroundColor: primaryColor,
                        tooltipTextStyle: bold14LightBlack,
                      ),
                      child: SfSlider(
                        min: 0.0,
                        max: 150.0,
                        enableTooltip: true,
                        activeColor: primaryColor,
                        inactiveColor: const Color(0xFFE6E6E6),
                        tooltipTextFormatterCallback: (dynamic actualValue, String formattedText) {
                          return "${homeProvider.selectedFilterDistance.toStringAsFixed(1)} km";
                        },
                        shouldAlwaysShowTooltip: true,
                        interval: 1.0,
                        onChanged: (value) {
                          state(() {
                            setState(() {
                              homeProvider.selectedFilterDistance = value;
                              log("selectedFilterDistance ${homeProvider.selectedFilterDistance}");
                            });
                          });
                        },
                        value: homeProvider.selectedFilterDistance,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "0.00km",
                            style: bold14Grey,
                          ),
                          Text(
                            "150km",
                            style: bold14Grey,
                          )
                        ],
                      ),
                    ),
                  ],
                ),
                heightSpace,
                heightSpace,
                //+PRICE

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                      child: Text(
                        getTranslation(context, 'extend_parking_time.price'),
                        style: bold16LightBlack,
                      ),
                    ),
                    heightSpace,
                    heightSpace,
                    SfSliderTheme(
                      data: SfSliderThemeData(
                        thumbStrokeWidth: 1.5,
                        thumbStrokeColor: whiteColor,
                        tooltipBackgroundColor: primaryColor,
                        tooltipTextStyle: bold14LightBlack,
                      ),
                      child: SfSlider(
                        min: 2.0,
                        max: 200.0,
                        enableTooltip: true,
                        activeColor: primaryColor,
                        inactiveColor: const Color(0xFFE6E6E6),
                        tooltipTextFormatterCallback: (dynamic actualValue, String formattedText) {
                          return "\$${homeProvider.selectedFilterPrice.toInt()}";
                        },
                        shouldAlwaysShowTooltip: true,
                        interval: 1.0,
                        onChanged: (value) {
                          state(() {
                            setState(() {
                              homeProvider.selectedFilterPrice = value;
                              log("selectedFilterPrice ${homeProvider.selectedFilterPrice}");
                            });
                          });
                        },
                        value: homeProvider.selectedFilterPrice,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "\$2.00/${getTranslation(context, 'extend_parking_time.per_hour')}",
                            style: bold14Grey,
                          ),
                          Text(
                            "\$200.00/${getTranslation(context, 'extend_parking_time.per_hour')}",
                            style: bold14Grey,
                          )
                        ],
                      ),
                    )
                  ],
                ),
                heightSpace,
                heightSpace,
                //+RATING
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        getTranslation(context, 'extend_parking_time.rating'),
                        style: bold16LightBlack,
                      ),
                      heightSpace,
                      height5Space,
                      Wrap(
                        spacing: fixPadding,
                        runSpacing: fixPadding,
                        children: [
                          for (int i = 1; i <= 5; i++)
                            GestureDetector(
                              onTap: () {
                                state(() {
                                  setState(() {
                                    homeProvider.selectedFilterRating = i;
                                    log("selectedFilterRating ${homeProvider.selectedFilterRating}");
                                  });
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding / 2),
                                decoration: BoxDecoration(
                                  color: whiteColor,
                                  borderRadius: BorderRadius.circular(5.0),
                                  border: Border.all(
                                    color: homeProvider.selectedFilterRating == i ? primaryColor : const Color(0xFFE6E6E6),
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      i.toString(),
                                      style: homeProvider.selectedFilterRating == i ? bold14TextColor : bold14Grey,
                                    ),
                                    widthBox(2),
                                    Icon(
                                      Icons.star,
                                      size: 15,
                                      color: homeProvider.selectedFilterRating == i ? textColor : greyColor,
                                    )
                                  ],
                                ),
                              ),
                            ),
                        ],
                      )
                    ],
                  ),
                ),
                heightSpace,
                heightSpace,
                heightSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: buttonWidget(
                          getTranslation(context, 'extend_parking_time.clear_all'),
                          () async {
                            final homProvider = Provider.of<HomeProvider>(context, listen: false);
                            await homProvider.getDataFromFirebase();
                            homProvider.changeBoolValue(false);
                            log("new applyFilter value ${homProvider.applyFilter}");

                            Navigator.pop(context);
                          },
                          whiteColor,
                          textColor,
                        ),
                      ),
                      widthSpace,
                      widthSpace,
                      Expanded(
                        child: buttonWidget(
                          getTranslation(context, 'extend_parking_time.apply'),
                          () async {
                            final homProvider = Provider.of<HomeProvider>(context, listen: false);
                            await homProvider.getFilterDataFromFirebase();
                            homProvider.changeBoolValue(true);
                            // Navigator.of(context).pop();
                            log("new applyFilter value ${homProvider.applyFilter}");
                            // Navigator.pop(context);
                          },
                          primaryColor,
                          lightBlackColor,
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          );
        });
      },
    );
  }
  */

//+ ADDING StreamBuilder
// StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
//   stream: ffstore.collection(collectionParkingProvider).snapshots(),
//   builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
//     if (snapshot.connectionState == ConnectionState.waiting) {
//       return const SizedBox();
//     } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
//       if (snapshot.hasError) {
//         return const Text('Error');
//       } else if (snapshot.hasData && snapshot.data != null) {
//         log(" snapshot.data!.docs length ${snapshot.data!.docs.length}");
//
//         return SizedBox(
//           height: 180.0,
//           width: size.width,
//           child: PageView.builder(
//             physics: const BouncingScrollPhysics(),
//             controller: pageController,
//             itemCount: snapshot.data!.docs.length,
//             scrollDirection: Axis.horizontal,
//             onPageChanged: (index) {
//               // moveCamera(homeProvider.allDataList[index].lat, homeProvider.allDataList[index].lng);
//               // log("on page changed ${homeProvider.allDataList[index].lat}, ${homeProvider.allDataList[index].lng}");
//             },
//             // itemCount: parkingList.length,
//             itemBuilder: (context, index) {
//               ParkingModel parkingModelValue = ParkingModel.fromJson(homeProvider.allDataList[index].toJson());
//               return _buildListContent(index, size, homeProvider.allDataList, parkingModelValue);
//
//             },
//           ),
//         );
//       } else {
//         return Container();
//       }
//     } else {
//       return Text('State: ${snapshot.connectionState}');
//     }
//   },
// ),

//+WORKING CODE WORKING CODE
