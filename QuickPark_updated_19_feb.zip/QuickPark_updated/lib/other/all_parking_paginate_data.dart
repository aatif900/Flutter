// ignore_for_file: unused_local_variable

import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/pages/auth/login.dart';
import 'package:parkingproject/pages/booking/select_vehicle.dart';
import 'package:parkingproject/pages/home/home_detail.dart';
import 'package:parkingproject/provider/booking_provider.dart';
import 'package:parkingproject/provider/filter_provider.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/my_logger.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:provider/provider.dart';

import '../../models/parking_model.dart';

class AllParkingPagination extends StatefulWidget {
  const AllParkingPagination({super.key});

  @override
  State<AllParkingPagination> createState() => _AllParkingPaginationState();
}

class _AllParkingPaginationState extends State<AllParkingPagination> {
  ///
  List<ParkingModel> list1 = [];
  List<Map<String, dynamic>> list = [];

  DocumentSnapshot? lastDocument;
  late QuerySnapshot<Map<String, dynamic>> querySnapshot;

  bool isMoreData = true;

  getPaginated() async {
    if (isMoreData) {
      final collectionReference = ffstore.collection(collectionParking);

      collectionReference.get().then((value) => infoLog("All document length ${value.docs.length}"));

      if (lastDocument == null) {
        querySnapshot = await collectionReference.limit(5).get();
      } else {
        querySnapshot = await collectionReference.limit(5).startAfterDocument(lastDocument!).get();
      }
      lastDocument = querySnapshot.docs.last;

      list.addAll(querySnapshot.docs.map((e) => e.data()));
      list1.addAll(querySnapshot.docs.map((e) => ParkingModel.fromJson(e.data())));
      setState(() {});
      if (querySnapshot.docs.length < 5) {
        isMoreData = false;
      }
    } else {
      infoLog("NO MORE DATA");
    }
  }

  @override
  void initState() {
    getPaginated();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    FilterProvider filterProvider = Provider.of<FilterProvider>(context, listen: false);

    List<ParkingModel> parKingList = context.watch<List<ParkingModel>>();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: scaffoldBgColor,
        elevation: 0,
        centerTitle: true,
        // automaticallyImplyLeading: false,
        title: Text(
          getTranslation(context, 'extend_parking_time.filter'),
          style: bold20LightBlack,
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
      ),
      /*body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: filterProvider.filteredDataList.isNotEmpty
            ? ListView.builder(
                itemCount: filterProvider.filteredDataList.length,
                itemBuilder: (BuildContext context, int index) {
                  ParkingModel parkingModelValue = ParkingModel.fromJson(filterProvider.filteredDataList[index].toJson());
                  log("parkingModel ${parkingModelValue.toJson()}");
                  return _buildListContent(index, size, filterProvider.filteredDataList, parkingModelValue);
                },
              )
            : Center(
                child: Text(
                  "No Parking Found",
                  style: semibold18LightBlack,
                ),
              ),
      ),*/
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: parKingList.isNotEmpty
            ? ListView.builder(
                itemCount: parKingList.length,
                itemBuilder: (BuildContext context, int index) {
                  ParkingModel parkingModelValue = ParkingModel.fromJson(parKingList[index].toJson());
                  log("parkingModel ${parkingModelValue.toJson()}");
                  return _buildListContent(index, size, parKingList, parkingModelValue);
                },
              )
            : Center(
                child: Text(
                  "No Parking Found",
                  style: semibold18LightBlack,
                ),
              ),
      ),
    );
  }

  _buildListContent(int index, Size size, List<ParkingModel> list, ParkingModel parkingModel) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: GestureDetector(
        onTap: () {},
        child: GestureDetector(
          onTap: () {
            pageNavigator(context, DetailScreen(parkingModel: parkingModel));
          },
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: fixPadding),
            margin: const EdgeInsets.symmetric(horizontal: fixPadding),
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [buttonShadow],
            ),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                  child: Row(
                    children: [
                      Container(
                        height: size.width * 0.2,
                        width: size.width * 0.2,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5.0),
                          boxShadow: [boxShadow],
                          image: DecorationImage(
                            image: NetworkImage(parkingModel.image.toString()),
                            fit: BoxFit.cover,
                          ),
                          // image: DecorationImage(
                          //   image: AssetImage(
                          //     parkingModel.image.toString(),
                          //   ),
                          //
                          //
                          //   fit: BoxFit.cover,
                          // ),
                        ),
                        alignment: Alignment.bottomRight,
                        child: Container(
                          padding: const EdgeInsets.all(3.0),
                          decoration: const BoxDecoration(
                            color: whiteColor,
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(5.0),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.star,
                                color: textColor,
                                size: 16,
                              ),
                              widthBox(3.0),
                              Text(
                                (parkingModel.rating.toString() == "0.1") ? "0.0" : parkingModel.rating.toString(),
                                style: semibold14LightBlack,
                              )
                            ],
                          ),
                        ),
                      ),
                      widthSpace,
                      width5Space,
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              parkingModel.parkingName.toString(),
                              style: semibold18LightBlack,
                              overflow: TextOverflow.ellipsis,
                            ),
                            heightBox(3.0),
                            Text(
                              parkingModel.address.toString(),
                              style: semibold14Grey,
                              overflow: TextOverflow.ellipsis,
                            ),
                            heightBox(3.0),
                            Text.rich(
                              TextSpan(
                                text: "\$ ${parkingModel.priceHourly.toString()} ",
                                style: semibold16LightBlack,
                                children: [
                                  TextSpan(
                                    text: getTranslation(context, 'extend_parking_time.per_hour'),
                                    style: semibold15Grey,
                                  )
                                ],
                              ),
                              style: semibold14Grey,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                heightSpace,
                DottedBorder(
                  padding: EdgeInsets.zero,
                  color: greyD4Color,
                  dashPattern: const [3],
                  child: Container(),
                ),
                heightSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text.rich(
                              TextSpan(text: "${getTranslation(context, 'extend_parking_time.distance_value')} : ", style: medium14LightBlack, children: [
                                TextSpan(text: "${parkingModel.distance} ${getTranslation(context, 'extend_parking_time.min_walk')}", style: semibold14LightBlack)
                              ]),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text.rich(
                              TextSpan(text: "${getTranslation(context, 'extend_parking_time.slot_available')} : ", style: medium14LightBlack, children: [
                                TextSpan(
                                  text: "${parkingModel.slot} ${getTranslation(context, 'extend_parking_time.slot')}".toString(),
                                  style: semibold14LightBlack,
                                )
                              ]),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      width5Space,
                      GestureDetector(
                        onTap: () {
                          // Navigator.pushNamed(context, '/detail');
                          final bookingProvider = Provider.of<BookingProvider>(context, listen: false);

                          User? currentUser = FirebaseAuth.instance.currentUser;
                          log("current user $currentUser");

                          if (currentUser == null) {
                            pageNavigator(context, const LoginScreen());
                          } else {
                            bookingProvider.updateSelectedParkingModel(parkingModel);

                            pageNavigator(context, SelectVehicleScreen(parkingModel: parkingModel));
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: fixPadding, horizontal: fixPadding * 1.7),
                          decoration: BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.circular(5.0),
                            boxShadow: [buttonShadow],
                          ),
                          child: Text(
                            getTranslation(context, 'extend_parking_time.book_now'),
                            style: bold16LightBlack,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
