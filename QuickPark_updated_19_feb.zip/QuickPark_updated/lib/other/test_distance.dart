import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: DistanceFilter(
        locations: [
          Location(name: 'Location A', latitude: 37.7749, longitude: -122.4194),
          Location(name: 'Location B', latitude: 34.0522, longitude: -118.2437),
          Location(name: 'Location C', latitude: 40.7128, longitude: -74.0060)
        ],
        maxDistance: 500, // Maximum distance in kilometers
        referenceLat: 37.7749, // Reference latitude
        referenceLon: -122.4194, // Reference longitude
      ),
    ),
  );
}

class DistanceFilter extends StatelessWidget {
  final List<Location> locations;
  final double maxDistance; // Maximum distance in kilometers
  final double referenceLat;
  final double referenceLon;

  DistanceFilter({
    required this.locations,
    required this.maxDistance,
    required this.referenceLat,
    required this.referenceLon,
  });

  @override
  Widget build(BuildContext context) {
    List<Location> filteredLocations =
        locations.where((location) => calculateDistance(referenceLat, referenceLon, location.latitude, location.longitude) <= maxDistance).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Locations within $maxDistance km'),
      ),
      body: ListView.builder(
        itemCount: filteredLocations.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(filteredLocations[index].name),
            subtitle: Text(
                'Distance: ${calculateDistance(referenceLat, referenceLon, filteredLocations[index].latitude, filteredLocations[index].longitude).toStringAsFixed(2)} km'),
          );
        },
      ),
    );
  }
}

class Location {
  final String name;
  final double latitude;
  final double longitude;

  Location({required this.name, required this.latitude, required this.longitude});
}

double calculateDistance(double startLat, double startLon, double endLat, double endLon) {
  const int earthRadius = 6371; // Radius of the Earth in kilometers

  double toRadians(double degree) {
    return degree * (pi / 180.0);
  }

  double dLat = toRadians(endLat - startLat);
  double dLon = toRadians(endLon - startLon);

  double a = sin(dLat / 2) * sin(dLat / 2) + cos(toRadians(startLat)) * cos(toRadians(endLat)) * sin(dLon / 2) * sin(dLon / 2);

  double c = 2 * atan2(sqrt(a), sqrt(1 - a));

  return earthRadius * c; // Distance in kilometers
}
