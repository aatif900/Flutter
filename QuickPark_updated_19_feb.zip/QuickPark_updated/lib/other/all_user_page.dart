import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:provider/provider.dart';

class AllUserPage extends StatefulWidget {
  const AllUserPage({super.key});

  @override
  State<AllUserPage> createState() => _AllUserPageState();
}

class _AllUserPageState extends State<AllUserPage> {
  @override
  Widget build(BuildContext context) {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    List userList = Provider.of<List<UserModel>>(context);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: scaffoldBgColor,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          getTranslation(context, 'profile.profile'),
          style: bold20LightBlack,
        ),
      ),
      body: ListView.builder(
        itemCount: userList.length,
        itemBuilder: (_, int index) {
          userList.forEach((element) {
            log("${element.toJson()}");
          });
          // UserModel userModel = UserModel.fromJson(userList as Map<String,dynamic>);
          // // log("User Model : ${userModel.toJson()}");
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: ListTile(
              leading: const CircleAvatar(
                backgroundColor: Colors.amber,
              ),
              title: Text(
                userList[index].emailAddress,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 20.0,
                ),
              ),
              subtitle: Text(
                userList[index].userName,
                style: const TextStyle(
                  fontSize: 25.0,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
