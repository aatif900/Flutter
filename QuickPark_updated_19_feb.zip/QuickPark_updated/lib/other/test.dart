import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_places_flutter/google_places_flutter.dart';
import 'package:google_places_flutter/model/prediction.dart';
import 'package:parkingproject/constants/key.dart';
import 'package:parkingproject/theme/theme.dart';

class TestPage extends StatelessWidget {
  TestPage({super.key});

  final List parkingList = [
    {
      "image": "assets/home/parking1.png",
      "parkingName": "Hapton holies parking",
      "adress": "Vehari",
      "price": "\$5",
      "distance": 3,
      "slot": 25,
      "rate": 4.5,
      "latLang": const GeoPoint(30.0455248451079, 72.3440931765388),
      "id": "11",
      "lat": "30.0455248451079",
      "lng": "72.3440931765388",
    },
    {
      "image": "assets/home/parking2.png",
      "parkingName": "DMC parking spot",
      "adress": "Multan",
      "price": "\$10",
      "distance": 5,
      "slot": 15,
      "rate": 3.5,
      "latLang": const GeoPoint(30.15891065211537, 71.51720966843742),
      "id": "12",
      "lat": "30.15891065211537",
      "lng": "771.51720966843742",
    },
    {
      "image": "assets/home/parking3.png",
      "parkingName": "Leed parking space",
      "adress": "Lahore",
      "price": "\$3",
      "distance": 10,
      "slot": 30,
      "rate": 2.5,
      "latLang": const GeoPoint(31.527255577196453, 74.34691219575576),
      "id": "13",
      "lat": "31.527255577196453",
      "lng": " 74.34691219575576",
    },
  ];

  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        decoration: BoxDecoration(
          color: whiteColor,
          boxShadow: [
            BoxShadow(
              color: blackColor.withOpacity(0.25),
              blurRadius: 6,
            ),
          ],
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: SizedBox(
          height: 50,
          child: Theme(
            data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
            child: GooglePlaceAutoCompleteTextField(
              textEditingController: controller,
              googleAPIKey: googleMapApiKey,
              inputDecoration: InputDecoration(
                hintText: "Search",
                // border: InputBorder.none,
                border: InputBorder.none,

                enabledBorder: InputBorder.none,
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: IconButton(
                  onPressed: () {
                    // filterBottomSheet(size, context);
                  },
                  icon: const Icon(
                    Icons.filter_list_outlined,
                    color: lightBlackColor,
                  ),
                ),
              ),
              // debounceTime: 100,
              countries: const ["in", "fr"],
              isLatLngRequired: false,
              getPlaceDetailWithLatLng: (Prediction prediction) {
                print("placeDetails ${prediction.lat}");
              },

              itemClick: (Prediction prediction) {
                controller.text = prediction.description ?? "";
                controller.selection = TextSelection.fromPosition(TextPosition(offset: prediction.description?.length ?? 0));
              },
              seperatedBuilder: const Divider(),
              // OPTIONAL// If you want to customize list view item builder
              itemBuilder: (context, index, Prediction prediction) {
                return Container(
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    children: [
                      const Icon(Icons.location_on),
                      const SizedBox(
                        width: 7,
                      ),
                      Expanded(child: Text("${prediction.description ?? ""}"))
                    ],
                  ),
                );
              },

              isCrossBtnShown: true,

              // default 600 ms ,
            ),
          ),
        ),
      ),
      /*floatingActionButton: FloatingActionButton(
        onPressed: () async {
          var uuid = Uuid();
          for (int i = 0; i <= parkingList.length; i++) {}
          parkingList.forEach((element) async {
            await ffstore.collection("ParkingProvider").doc(uuid.v4()).set(element);
            log("parking list element ${element}");
          });
        },
        child: Icon(Icons.add),
      ),*/
    );
  }
}
