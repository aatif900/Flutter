import 'package:flutter/material.dart';
import 'package:parkingproject/theme/theme.dart';

buttonWidget(String title, Function() onTap, Color color, Color textColor) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      width: double.maxFinite,
      padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 1.4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        boxShadow: [boxShadow],
        color: color,
      ),
      alignment: Alignment.center,
      child: Text(
        title,
        style: bold18TextColor.copyWith(color: textColor),
        overflow: TextOverflow.ellipsis,
      ),
    ),
  );
}
