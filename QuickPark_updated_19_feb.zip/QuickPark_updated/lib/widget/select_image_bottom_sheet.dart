import 'package:flutter/material.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/theme/theme.dart';

changePhotoBottomSheet(Size size, BuildContext context, VoidCallback onCameraTap, VoidCallback onGalleryTap) {
  return showModalBottomSheet(
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    context: context,
    builder: (context) {
      return Container(
        padding: const EdgeInsets.all(fixPadding * 2.0),
        decoration: const BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(40.0),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              getTranslation(context, 'edit_profile.change_photo'),
              style: bold18LightBlack,
            ),
            heightSpace,
            heightSpace,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                imageChangeOption(context, size, Icons.camera_alt, getTranslation(context, 'edit_profile.camera'), const Color(0xFF1E4799), onCameraTap),
                imageChangeOption(context, size, Icons.photo, getTranslation(context, 'edit_profile.gallery'), const Color(0xFF1E996D), onGalleryTap),

                /*imageChangeOption(context, size, CupertinoIcons.delete_solid, getTranslation(context, 'edit_profile.remove_image'), const Color(0xFFEF1717), () {
                  Navigator.of(context).pop();
                }),*/
              ],
            )
          ],
        ),
      );
    },
  );
}

imageChangeOption(BuildContext context, Size size, icon, title, color, Function() onTap) {
  return GestureDetector(
    onTap: onTap,
    child: Column(
      children: [
        Container(
          height: size.height * 0.07,
          width: size.height * 0.07,
          decoration: BoxDecoration(
            color: whiteColor,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: blackColor.withOpacity(0.25),
                blurRadius: 6,
              )
            ],
          ),
          alignment: Alignment.center,
          child: Icon(
            icon,
            color: color,
          ),
        ),
        heightSpace,
        Text(
          title,
          style: medium15LightBlack,
          overflow: TextOverflow.ellipsis,
        )
      ],
    ),
  );
}
