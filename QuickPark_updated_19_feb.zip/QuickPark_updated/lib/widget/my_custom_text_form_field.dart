import 'package:flutter/material.dart';
import 'package:parkingproject/theme/theme.dart';

class MyTextFormField extends StatelessWidget {
  final TextEditingController? controller;
  final String? topText;
  final String? hintText;
  final TextInputType? keyboardType;
  final TextStyle? topTextStyle;

  const MyTextFormField({super.key, this.controller, this.hintText, this.topText, this.keyboardType, this.topTextStyle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: fixPadding),
          child: Text(
            topText ?? "",
            style: topTextStyle ?? semibold16LightBlack,
          ),
        ),
        heightSpace,
        Container(
          width: double.maxFinite,
          decoration: BoxDecoration(
            color: whiteColor,
            boxShadow: [boxShadow],
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Theme(
            data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
            child: TextFormField(
              controller: controller,
              cursorColor: primaryColor,
              keyboardType: keyboardType ?? TextInputType.name,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 2),
                border: InputBorder.none,
                hintText: hintText ?? "",
                hintStyle: semibold15Grey,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
