import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:parkingproject/provider/data_provider.dart';

class DbKeys {
  static const String dataTypeAGENTS = 'dataTypeAGENTS';
}

class InfiniteCOLLECTIONListViewWidgetAdmin extends StatefulWidget {
  final FirestoreDataProvider? firestoreDataProviderAGENTS;
  final String? datatype;
  final Widget? list;
  final Query? refData;
  final bool? isReverse;
  final EdgeInsets? padding;
  final String? parentId;

  const InfiniteCOLLECTIONListViewWidgetAdmin({
    this.firestoreDataProviderAGENTS,
    this.datatype,
    this.isReverse,
    this.padding,
    this.parentId,
    this.list,
    this.refData,
    Key? key,
  }) : super(key: key);

  @override
  _InfiniteCOLLECTIONListViewWidgetAdminState createState() => _InfiniteCOLLECTIONListViewWidgetAdminState();
}

class _InfiniteCOLLECTIONListViewWidgetAdminState extends State<InfiniteCOLLECTIONListViewWidgetAdmin> {
  final scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    scrollController.addListener(scrollListener);
    if (widget.datatype == DbKeys.dataTypeAGENTS) {
      widget.firestoreDataProviderAGENTS!.fetchNextData(widget.datatype, widget.refData, true);
    }
  }

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  void scrollListener() {
    if (scrollController.offset >= scrollController.position.maxScrollExtent / 2 && !scrollController.position.outOfRange) {
      if (widget.datatype == DbKeys.dataTypeAGENTS) {
        if (widget.firestoreDataProviderAGENTS!.hasNext) {
          widget.firestoreDataProviderAGENTS!.fetchNextData(widget.datatype, widget.refData, false);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) => ListView(
        physics: const ScrollPhysics(),
        shrinkWrap: true,
        reverse: widget.isReverse == null || widget.isReverse == false ? false : true,
        controller: scrollController,
        padding: widget.padding ?? const EdgeInsets.all(0),
        children: (widget.datatype == DbKeys.dataTypeAGENTS)
            ? [
                Container(child: widget.list),
                (widget.firestoreDataProviderAGENTS!.hasNext == true)
                    ? Center(
                        child: GestureDetector(
                          onTap: () {
                            widget.firestoreDataProviderAGENTS!.fetchNextData(widget.datatype, widget.refData, false);
                          },
                          child: Padding(
                            padding: widget.firestoreDataProviderAGENTS!.recievedDocs.isEmpty
                                ? EdgeInsets.fromLTRB(38, MediaQuery.of(context).size.height / 3, 38, 38)
                                : const EdgeInsets.all(18.0),
                            child: Container(child: circularProgress()),
                          ),
                        ),
                      )
                    : widget.firestoreDataProviderAGENTS!.recievedDocs.isEmpty
                        ? noDataWidget(
                            context: context,
                            padding: EdgeInsets.fromLTRB(28, MediaQuery.of(context).size.height / 3.7, 28, 10),
                            title: 'No Agents',
                          )
                        : const SizedBox(),
              ]
            : [],
      );
}

Container circularProgress() {
  return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.only(top: 10.0),
      child: const CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation(Colors.black),
      ));
}

Widget noDataWidget({
  required BuildContext context,
  EdgeInsets? padding = const EdgeInsets.all(38),
  String? title = "No data",
  String? subtitle = "",
  IconData? iconData = Icons.no_accounts,
  Color? iconColor = Colors.amber,
}) {
  return Center(
    child: Padding(
      padding: padding ?? EdgeInsets.fromLTRB(40, MediaQuery.of(context).size.height / 12, 40, 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Container(
              padding: const EdgeInsets.all(22),
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              height: 100,
              width: 100,
              child: Icon(iconData ?? Icons.person, size: 44, color: iconColor ?? Colors.red)),
          const SizedBox(
            height: 30,
          ),
          Text(
            title ?? 'No Data',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.red.withOpacity(0.6), fontSize: 15, fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 10,
          ),
          Text(
            subtitle ?? '',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.red.withOpacity(0.6), fontSize: 12.5, fontWeight: FontWeight.w400),
          ),
          const SizedBox(
            height: 30,
          ),
        ],
      ),
    ),
  );
}
