



/*  Map<String ,dynamic> myMap= {
  requestMap: {"parkingEndDateTime":1702368300000,
    "notifyUser":true,"isSentStartNotification":false,
    "description":"saif ullah booked a parking","notificationType":"bookedParking",
    "title":"Booked Parking","userName":"saif ullah","type":"BookingCancel",
    "userId":"vik9oJ6a1dN4VJfs2R2aLUl5gIA3","createdAt":1702367659938,
    "isSentEndNotification":false,"parkingStartDateTime":1702368000000,"otherUserId":"vik9oJ6a1dN4VJfs2R2aLUl5gIA3"},
    screenName: ScheduleParkingStartTimeNear,
    type: ScheduleParkingStartTimeNear

}*/
