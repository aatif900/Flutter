import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/models/user_model.dart';

class FirebaseServices {
  //recieve the data

  Stream<List<ParkingModel>> getAllParkingList() {
    return ffstore
        .collection(collectionParking)
        .snapshots()
        .map((snapShot) => snapShot.docs.map((document) => ParkingModel.fromJson(document.data as Map<String, dynamic>)).toList());
  }

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>> getAllParkingListLiveListen() {
    return ffstore
        .collection(collectionParking) //
        .snapshots()
        .listen((event) {
      event.docs.map((document) => ParkingModel.fromJson(document.data as Map<String, dynamic>)).toList();
    });
  }

  Stream<List<UserModel>> getAllUserList() {
    return ffstore
        .collection(collectionUsers) //
        .snapshots()
        .map((snapShot) => snapShot.docs.map((document) => UserModel.fromJson(document.data())).toList());
  }

  //+-------------------------------------------------

  final StreamController<List<ParkingModel>> _userListController = StreamController<List<ParkingModel>>();

  Stream<List<ParkingModel>> get parkingListStream => _userListController.stream;

  void updateUserList(List<ParkingModel> userList) {
    _userListController.add(userList);
  }

  void dispose() {
    _userListController.close();
  }
}
