import 'dart:convert';

AppSettingModel appSettingModelFromJson(String str) => AppSettingModel.fromJson(json.decode(str));

String appSettingModelToJson(AppSettingModel data) => json.encode(data.toJson());

class AppSettingModel {
  final bool? notification;
  final int? createdAt;

  AppSettingModel({
    this.notification,
    this.createdAt,
  });

  factory AppSettingModel.fromJson(Map<String, dynamic> json) {
    return AppSettingModel(
      notification: json["notification"],
      createdAt: json["createdAt"],
    );
  }

  Map<String, dynamic> toJson() => {
        "notification": notification,
        "createdAt": createdAt,
      };
}
