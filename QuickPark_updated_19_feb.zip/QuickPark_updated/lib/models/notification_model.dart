// To parse this JSON data, do
//
//     final notificationModel = notificationModelFromJson(jsonString);

import 'dart:convert';

NotificationModel notificationModelFromJson(String str) => NotificationModel.fromJson(json.decode(str));

String notificationModelToJson(NotificationModel data) => json.encode(data.toJson());

class NotificationModel {
  final int? createdAt;
  final String? title;
  final String? notificationType;
  final String? description;
  final String? userId;
  final String? userName;
  final String? toSendID;
  final String? type;
  final int? parkingStartDateTime;
  final int? parkingEndDateTime;
  final bool? isSentStartNotification;
  final bool? isSentEndNotification;
  final bool? notifyUser;

  NotificationModel({
    this.createdAt,
    this.notificationType,
    this.title,
    this.description,
    this.userId,
    this.userName,
    this.toSendID,
    this.type,
    this.parkingStartDateTime,
    this.parkingEndDateTime,
    this.isSentStartNotification,
    this.isSentEndNotification,
    this.notifyUser,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) => NotificationModel(
        createdAt: json["createdAt"],
        notificationType: json["notificationType"],
        title: json["title"],
        description: json["description"],
        userId: json["userId"],
        userName: json["userName"],
        toSendID: json["otherUserId"],
        type: json["type"],
        parkingStartDateTime: json["parkingStartDateTime"],
        parkingEndDateTime: json["parkingEndDateTime"],
        isSentStartNotification: json["isSentStartNotification"],
        isSentEndNotification: json["isSentEndNotification"],
        notifyUser: json["notifyUser"],
      );

  Map<String, dynamic> toJson() => {
        "createdAt": createdAt,
        "notificationType": notificationType,
        "title": title,
        "description": description,
        "userId": userId,
        "userName": userName,
        "otherUserId": toSendID,
        "type": type,
        "parkingStartDateTime": parkingStartDateTime,
        "parkingEndDateTime": parkingEndDateTime,
        "isSentStartNotification": isSentStartNotification,
        "isSentEndNotification": isSentEndNotification,
        "notifyUser": notifyUser,
      };
}
