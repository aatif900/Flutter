import 'dart:convert';

BookingModel bookingModelFromJson(String str) => BookingModel.fromJson(json.decode(str));

String bookingModelToJson(BookingModel data) => json.encode(data.toJson());

class BookingModel {
  final String? documentID;
  final String? parkingProviderId;
  final String? bookedByName;
  final String? bookedById;
  final String? bookedByImage;
  final int? parkingStartDate;
  final int? parkingEndDate;
  final String? duration;
  final String? vehicleName;
  final int? startingTime;
  final int? endingTime;
  final String? parkingSLot;
  final int? pricePerHour;
  final int? tax;
  final int? totalPrice;
  final int? createdAt;
  final String? parkingName;
  final String? parkingAddress;
  final int? parkingPricePerHour;
  final String? parkingImage;
  final String? phoneNumber;
  final double? parkingRating;
  final bool? isSentStartNotification;
  final bool? isSentEndNotification;
  final String? lat;
  final String? lng;
  final String? licencePlateNumber;

  BookingModel({
    this.documentID,
    this.parkingProviderId,
    this.bookedByName,
    this.bookedById,
    this.bookedByImage,
    this.parkingStartDate,
    this.parkingEndDate,
    this.duration,
    this.vehicleName,
    this.startingTime,
    this.endingTime,
    this.parkingSLot,
    this.pricePerHour,
    this.tax,
    this.totalPrice,
    this.createdAt,
    this.parkingName,
    this.parkingAddress,
    this.parkingPricePerHour,
    this.parkingImage,
    this.phoneNumber,
    this.parkingRating,
    this.isSentStartNotification,
    this.isSentEndNotification,
    this.lat,
    this.lng,
    this.licencePlateNumber,
  });

  factory BookingModel.fromJson(Map<String, dynamic> json) => BookingModel(
        parkingProviderId: json["parkingProviderId"],
        documentID: json["documentID"],
        bookedByName: json["bookedByName"],
        bookedById: json["bookedByID"],
        bookedByImage: json["bookedByImage"],
        parkingStartDate: json["parkingStartDate"],
        parkingEndDate: json["parkingEndDate"],
        duration: json["duration"],
        vehicleName: json["vehicleName"],
        startingTime: json["startingTIme"],
        endingTime: json["endingTime"],
        parkingSLot: json["parkingSLot"],
        pricePerHour: json["pricePerHour"],
        tax: json["tax"],
        totalPrice: json["totalPrice"],
        createdAt: json["createdAt"],
        parkingName: json["parkingName"],
        parkingAddress: json["parkingAddress"],
        parkingPricePerHour: json["parkingPricePerHour"],
        parkingImage: json["parkingImage"],
        phoneNumber: json["phoneNumber"],
        parkingRating: json["parkingRating"],
        isSentStartNotification: json["isSentStartNotification"],
        isSentEndNotification: json["isSentEndNotification"],
        lat: json["lat"],
        lng: json["lng"],
        licencePlateNumber: json["licencePlateNumber"],
      );

  Map<String, dynamic> toJson() => {
        "parkingProviderId": parkingProviderId,
        "documentID": documentID,
        "bookedByName": bookedByName,
        "bookedByID": bookedById,
        "bookedByImage": bookedByImage,
        "parkingStartDate": parkingStartDate,
        "parkingEndDate": parkingEndDate,
        "duration": duration,
        "vehicleName": vehicleName,
        "startingTIme": startingTime,
        "endingTime": endingTime,
        "parkingSLot": parkingSLot,
        "pricePerHour": pricePerHour,
        "tax": tax,
        "totalPrice": totalPrice,
        "createdAt": createdAt,
        "parkingName": parkingName,
        "parkingAddress": parkingAddress,
        "parkingPricePerHour": parkingPricePerHour,
        "parkingImage": parkingImage,
        "phoneNumber": phoneNumber,
        "parkingRating": parkingRating,
        "isSentStartNotification": isSentStartNotification,
        "isSentEndNotification": isSentEndNotification,
        "lat": lat,
        "lng": lng,
        "licencePlateNumber": licencePlateNumber,
      };
}
