// To parse this JSON data, do
//
//     final addVehicleModel = addVehicleModelFromJson(jsonString);

import 'dart:convert';

VehicleModel addVehicleModelFromJson(String str) => VehicleModel.fromJson(json.decode(str));

String addVehicleModelToJson(VehicleModel data) => json.encode(data.toJson());

class VehicleModel {
  final String? vehicleType;
  final String? vehicleName;
  final String? vehicleRegistrationNo;
  final String? vehicleManufacturer;
  final String? vehicleColor;
  final String? vehicleLicencePlate;
  final int? createdAt;

  VehicleModel({
    this.vehicleType,
    this.vehicleName,
    this.vehicleRegistrationNo,
    this.vehicleManufacturer,
    this.vehicleColor,
    this.vehicleLicencePlate,
    this.createdAt,
  });

  VehicleModel copyWith({
    String? vehicleType,
    String? vehicleName,
    String? vehicleRegistrationNo,
    String? vehicleManufacturer,
    String? vehicleColor,
    String? vehicleLicencePlate,
    int? createdAt,
  }) =>
      VehicleModel(
        createdAt: createdAt ?? this.createdAt,
        vehicleType: vehicleType ?? this.vehicleType,
        vehicleName: vehicleName ?? this.vehicleName,
        vehicleRegistrationNo: vehicleRegistrationNo ?? this.vehicleRegistrationNo,
        vehicleManufacturer: vehicleManufacturer ?? this.vehicleManufacturer,
        vehicleColor: vehicleColor ?? this.vehicleColor,
        vehicleLicencePlate: vehicleLicencePlate ?? this.vehicleLicencePlate,
      );

  factory VehicleModel.fromJson(Map<String, dynamic> json) => VehicleModel(
        vehicleType: json["vehicleType"],
        vehicleName: json["vehicleName"],
        vehicleRegistrationNo: json["vehicleRegistrationNo"],
        vehicleManufacturer: json["vehicleManufacturer"],
        vehicleColor: json["vehicleColor"],
        vehicleLicencePlate: json["vehicleLicencePlate"],
        createdAt: json["createdAt"],
      );

  Map<String, dynamic> toJson() => {
        "vehicleType": vehicleType,
        "vehicleName": vehicleName,
        "vehicleRegistrationNo": vehicleRegistrationNo,
        "vehicleManufacturer": vehicleManufacturer,
        "vehicleColor": vehicleColor,
        "vehicleLicencePlate": vehicleLicencePlate,
        "createdAt": createdAt,
      };
}
