import 'dart:convert';

UserModel userModelFromJson(String str) => UserModel.fromJson(json.decode(str));

String userModelToJson(UserModel data) => json.encode(data.toJson());

class UserModel {
  String? deviceType;
  String? fcmToken;
  String? userName;
  String? firstName;
  String? lastName;
  String? phoneNumber;
  String? emailAddress;
  String? password;
  String? uid;
  String? profileImgUrl;
  String? country;
  String? city;
  String? zipCode;
  String? houseNumber;
  String? address;
  int? joiningDate;
  bool? isPhoneLinked;
  bool? isProfileComplete;


  UserModel({
    this.deviceType,
    this.fcmToken,
    this.userName,
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.emailAddress,
    this.password,
    this.uid,
    this.profileImgUrl,
    this.country,
    this.city,
    this.zipCode,
    this.houseNumber,
    this.address,
    this.joiningDate,
    this.isPhoneLinked,
    this.isProfileComplete,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        deviceType: json["deviceType"],
        fcmToken: json["fcmToken"],
        userName: json["userName"],
        firstName: json["firstName"],
        lastName: json["lastName"],
        phoneNumber: json["phoneNumber"],
        emailAddress: json["emailAddress"],
        password: json["password"],
        uid: json["uid"],
        profileImgUrl: json["profileImgUrl"],
        country: json["country"],
        city: json["city"],
        zipCode: json["zipCode"],
        houseNumber: json["houseNumber"],
        address: json["address"],
        joiningDate: json["joiningDate"],
        isPhoneLinked: json["isPhoneLinked"],
        isProfileComplete: json["isProfileComplete"],
      );

  Map<String, dynamic> toJson() => {
        "deviceType": deviceType,
        "fcmToken": fcmToken,
        "userName": userName,
        "firstName": firstName,
        "lastName": lastName,
        "phoneNumber": phoneNumber,
        "emailAddress": emailAddress,
        "password": password,
        "uid": uid,
        "profileImgUrl": profileImgUrl,
        "country": country,
        "city": city,
        "zipCode": zipCode,
        "houseNumber": houseNumber,
        "address": address,
        "joiningDate": joiningDate,
        "isPhoneLinked": isPhoneLinked,
        "isProfileComplete": isProfileComplete,
      };
}
