// To parse this JSON data, do
//
//     final parkingProviderModel = parkingProviderModelFromJson(jsonString);

import 'dart:convert';

ParkingModel parkingProviderModelFromJson(String str) => ParkingModel.fromJson(json.decode(str));

String parkingProviderModelToJson(ParkingModel data) => json.encode(data.toJson());

class ParkingModel {
  final String? parkingProviderId;
  final String? providerType;
  final String? phoneNumber;
  final String? vehicleType;
  final String? title;
  final String? description;
  final String? documentID;
  final String? image;
  final String? parkingName;
  final String? address;
  final double? rating;

  final String? lat;
  final String? lng;
  final int? createdAt;
  final double? distance;
  final int? slot;
  final int? priceHourly;
  final int? priceDaily;
  final int? priceWeekly;
  final int? priceMonthly;
  final bool? isCovered;
  final bool? isLocked;
  final bool? isFullHourAccess;
  final bool? isVideoSurveillance;
  final bool? monthlyRent;
  List<dynamic>? imageList;
  List<dynamic>? selectedVehicles;

  ParkingModel({
    this.parkingProviderId,
    this.providerType,
    this.phoneNumber,
    this.vehicleType,
    this.description,
    this.documentID,
    this.title,
    this.image,
    this.parkingName,
    this.address,
    this.priceHourly,
    this.priceDaily,
    this.priceWeekly,
    this.priceMonthly,
    this.distance,
    this.slot,
    this.rating,
    this.lat,
    this.lng,
    this.createdAt,
    this.imageList,
    this.selectedVehicles,
    this.isCovered,
    this.isLocked,
    this.isFullHourAccess,
    this.isVideoSurveillance,
    this.monthlyRent,
  });

  factory ParkingModel.fromJson(Map<String, dynamic> json) => ParkingModel(
        parkingProviderId: json["parkingProviderId"],
        providerType: json["providerType"],
        phoneNumber: json["phoneNumber"],
        vehicleType: json["vehicleType"],
        description: json["description"],
        title: json["title"],
        documentID: json["documentID"],
        image: json["image"],
        parkingName: json["parkingName"],
        address: json["address"],
        priceHourly: json["priceHourly"],
        priceMonthly: json["priceMonthly"],
        priceDaily: json["priceDaily"],
        priceWeekly: json["priceWeekly"],
        distance: json["distance"],
        slot: json["slot"],
        createdAt: json["createdAt"],
        rating: json["rating"],
        lat: json["lat"],
        lng: json["lng"],
        imageList: json['imageList'] != null ? List<String>.from(json['imageList'].map((x) => x)) : [],
        selectedVehicles: json['selectedVehicles'] != null ? List<String>.from(json['selectedVehicles'].map((x) => x)) : [],
        isCovered: json["isCovered"],
        isLocked: json["isLocked"],
        isFullHourAccess: json["isFullHourAccess"],
        isVideoSurveillance: json["isVideoSurveillance"],
        monthlyRent: json["monthlyRent"],
      );

  Map<String, dynamic> toJson() => {
        "parkingProviderId": parkingProviderId,
        "providerType": providerType,
        "phoneNumber": phoneNumber,
        "vehicleType": vehicleType,
        "description": description,
        "title": title,
        "documentID": documentID,
        "image": image,
        "parkingName": parkingName,
        "address": address,
        "priceHourly": priceHourly,
        "priceMonthly": priceMonthly,
        "priceDaily": priceDaily,
        "priceWeekly": priceWeekly,
        "distance": distance,
        "slot": slot,
        "createdAt": createdAt,
        "rating": rating,
        "lat": lat,
        "lng": lng,
        "isCovered": isCovered,
        "isLocked": isLocked,
        "isFullHourAccess": isFullHourAccess,
        "isVideoSurveillance": isVideoSurveillance,
        "monthlyRent": monthlyRent,
        'imageList': imageList != null ? List<String>.from(imageList!.map((x) => x)) : [],
        'selectedVehicles': selectedVehicles != null ? List<String>.from(selectedVehicles!.map((x) => x)) : [],
      };
}
