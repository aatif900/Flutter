import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:parkingproject/models/user_model.dart';

class ChatRoomModel {
  ChatRoomModel({
    this.users,
    this.user1Model,
    this.user2Model,
    this.chatRoomId = "",
    this.notDeletedFor,
    this.isBlocked = false,
    this.blockedById = "",
    this.createdAt = 0,
    this.lastMessage = "",
    this.lastMessageAt = 0,
    this.lastMessageType = "",
  });

  bool? isBlocked;
  String? blockedById;
  UserModel? user1Model;
  UserModel? user2Model;
  String? chatRoomId;
  List<String>? users;
  List<String>? notDeletedFor;
  int? createdAt;
  int? lastMessageAt;
  String? lastMessage;
  String? lastMessageType;

  ChatRoomModel.fromDocumentSnapshot(DocumentSnapshot documentSnapshot) {
    Map<String, dynamic> doc = documentSnapshot.data() as Map<String, dynamic>;
    isBlocked = doc["isBlocked"];
    blockedById = doc["blockedById"];
    user1Model = UserModel.fromJson(doc["user1Model"]);
    user2Model = UserModel.fromJson(doc["user2Model"]);
    chatRoomId = doc["chatRoomId"];
    createdAt = doc["createdAt"];
    lastMessageAt = doc["lastMessageAt"];
    lastMessage = doc["lastMessage"];
    lastMessageType = doc["lastMessageType"];
    users = List<String>.from(doc["users"]);
    notDeletedFor = List<String>.from(doc["notDeletedFor"]);
  }
}
