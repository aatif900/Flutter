import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/booking_model.dart';
import 'package:parkingproject/models/notification_model.dart';
import 'package:parkingproject/pages/MyBooking/ticket_screen_ongoing_parking.dart';
import 'package:parkingproject/pages/profile/languages.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

class OnGoingBookingPage extends StatelessWidget {
  OnGoingBookingPage({super.key});

  List? ongoingList = [
    {
      "status": translation('my_booking.active_now'),
      "data": [
        {
          "title": "Hapton holies parking",
          "image": "assets/myBooking/image6.png",
          "address": "1024 Botanic garden road,new york",
          "date": "3 April 2022",
          "price": "\$5",
          "rate": 4.5,
          "hour": 1
        },
      ]
    },
    {
      "status": translation('my_booking.paid'),
      "data": [
        {
          "title": "Easkartoon shopping mall",
          "image": "assets/myBooking/image2.png",
          "address": "1024 Botanic garden road,new york",
          "date": "3 April 2022",
          "price": "\$15",
          "rate": 3.5,
          "hour": 2
        },
        {
          "title": "DCM parking spot",
          "image": "assets/myBooking/image5.png",
          "address": "1024 Botanic garden road,new york",
          "date": "3 April 2022",
          "price": "\$10",
          "rate": 2.5,
          "hour": 3
        },
      ]
    }
  ];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
    log("authProvider.userModel.uid ${authProvider.userModel.uid}");
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: ffstore.collection(collectionBooking).where("bookedByID", isEqualTo: authProvider.userModel.uid).snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return loading();
        } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasError) {
            return const Text('Error');
          } else if (snapshot.hasData) {
            log("snapshot hasData and length :  ${snapshot.data!.docs.length}");
            if (snapshot.data!.docs.isNotEmpty) {
              return ListView.builder(
                padding: const EdgeInsets.all(fixPadding * 2.0),
                physics: const BouncingScrollPhysics(),
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (context, index) {
                  BookingModel bookingModel = BookingModel.fromJson(snapshot.data!.docs[index].data() as Map<String, dynamic>);
                  String documentId = snapshot.data!.docs[index].id;

                  return Padding(
                    padding: EdgeInsets.only(bottom: index == 0 ? fixPadding : 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Active now",
                          style: bold16LightBlack,
                        ),
                        Container(
                          margin: const EdgeInsets.symmetric(vertical: fixPadding),
                          width: double.maxFinite,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            boxShadow: [boxShadow],
                            color: whiteColor,
                          ),
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(fixPadding),
                                child: Row(
                                  children: [
                                    Container(
                                      height: size.width * 0.2,
                                      width: size.width * 0.25,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5.0),
                                        boxShadow: [boxShadow],
                                        image: DecorationImage(
                                          image: NetworkImage(
                                            bookingModel.parkingImage.toString(),
                                          ),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      alignment: Alignment.bottomRight,
                                      child: Container(
                                        padding: const EdgeInsets.all(3.0),
                                        decoration: const BoxDecoration(
                                          color: whiteColor,
                                          borderRadius: BorderRadius.only(
                                            bottomRight: Radius.circular(5.0),
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Icon(
                                              Icons.star,
                                              color: textColor,
                                              size: 16,
                                            ),
                                            widthBox(3.0),
                                            Text(
                                              "${bookingModel.parkingRating} ",
                                              style: semibold14LightBlack,
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                    widthSpace,
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "${bookingModel.parkingName}",
                                            style: semibold16LightBlack,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            "${bookingModel.parkingAddress}",
                                            style: semibold14Grey,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            " ${DateFormat.yMMMd().format(DateTime.fromMillisecondsSinceEpoch(bookingModel.parkingStartDate ?? DateTime.now().millisecondsSinceEpoch))}  ",
                                            style: semibold14Grey,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text.rich(
                                            TextSpan(
                                                text: "${bookingModel.pricePerHour}/",
                                                style: semibold16LightBlack,
                                                children: [TextSpan(text: " 1 ${getTranslation(context, 'my_booking.hour')}", style: semibold12Grey)]),
                                            overflow: TextOverflow.ellipsis,
                                          )
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Row(
                                children: [
                                  // item['status'] == getTranslation(context, 'my_booking.active_now') ? viewTimerButton() :
                                  // cancelBookingButton(index, item, context),
                                  //+Cancel Booking Button
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () {
                                        showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          context: context,
                                          builder: (context) {
                                            return Container(
                                              width: double.maxFinite,
                                              decoration: const BoxDecoration(
                                                borderRadius: BorderRadius.vertical(
                                                  top: Radius.circular(20.0),
                                                ),
                                                color: whiteColor,
                                              ),
                                              child: ListView(
                                                shrinkWrap: true,
                                                padding: EdgeInsets.zero,
                                                children: [
                                                  heightSpace,
                                                  Center(
                                                    child: Container(
                                                      height: 1,
                                                      width: 60,
                                                      color: greyD9Color,
                                                    ),
                                                  ),
                                                  heightSpace,
                                                  heightSpace,
                                                  Text(
                                                    getTranslation(context, 'my_booking.cancel_booking'),
                                                    style: bold18Red,
                                                    textAlign: TextAlign.center,
                                                  ),
                                                  heightSpace,
                                                  heightSpace,
                                                  Container(
                                                    height: 1,
                                                    width: double.maxFinite,
                                                    color: greyD4Color,
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets.all(fixPadding * 2.0),
                                                    child: Column(
                                                      children: [
                                                        Text(
                                                          getTranslation(context, 'my_booking.are_you_sure_message'),
                                                          style: semibold18LightBlack,
                                                          textAlign: TextAlign.center,
                                                        ),
                                                        heightSpace,
                                                        height5Space,
                                                        Text(
                                                          getTranslation(context, 'my_booking.content'),
                                                          style: medium14Grey,
                                                          textAlign: TextAlign.center,
                                                        ),
                                                        heightSpace,
                                                        heightSpace,
                                                        Row(
                                                          children: [
                                                            Expanded(
                                                              child: buttonWidget(
                                                                getTranslation(context, 'my_booking.close'),
                                                                () {
                                                                  Navigator.pop(context);
                                                                },
                                                                whiteColor,
                                                                textColor,
                                                              ),
                                                            ),
                                                            widthSpace,
                                                            widthSpace,
                                                            Expanded(
                                                              child: buttonWidget(
                                                                getTranslation(context, 'my_booking.yes_continue'),
                                                                () async {
                                                                  final authProvider = Provider.of<AuthProvider>(context, listen: false);
                                                                  String id = Uuid().v4();
                                                                  await ffstore.collection(collectionBooking).doc(documentId).delete();

                                                                  NotificationModel notificationModel = NotificationModel(
                                                                    createdAt: DateTime.now().millisecondsSinceEpoch,
                                                                    title: "Booking Cancel",
                                                                    description: "Someone cancel their booking",
                                                                    userName: authProvider.userModel.firstName,
                                                                    type: "BookingCancel",
                                                                    userId: authProvider.userModel.uid,
                                                                    toSendID: bookingModel.parkingProviderId,
                                                                  );
                                                                  await ffstore.collection(collectionNotifications).doc(id).set(notificationModel.toJson());

                                                                  Navigator.of(context).pop();

                                                                  Utils.toast("Successfully !");
                                                                },
                                                                primaryColor,
                                                                lightBlackColor,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        );
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.all(fixPadding),
                                        decoration: BoxDecoration(
                                          color: whiteColor,
                                          borderRadius: languageValue == 4
                                              ? const BorderRadius.only(bottomRight: Radius.circular(10.0))
                                              : const BorderRadius.only(bottomLeft: Radius.circular(10.0)),
                                          boxShadow: [boxShadow],
                                        ),
                                        alignment: Alignment.center,
                                        child: Text(
                                          getTranslation(context, 'my_booking.cancel_booking'),
                                          style: bold16TextColor,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                  ),
                                  viewTicketButton(() {
                                    pageNavigator(context, TicketScreenOnGoingParking(bookingModel: bookingModel));
                                    // Navigator.pushNamed(context, '/parkingTicket', arguments: {"id": 2});
                                  }, context)
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            } else {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      "assets/myBooking/emojione_disappointed-face.png",
                      height: 35,
                      width: 35,
                    ),
                    heightSpace,
                    Text(getTranslation(context, 'my_booking.no_booking_yet'), style: bold18Grey)
                  ],
                ),
              );
            }
          } else {
            return Container();
          }
        } else {
          log("in last else of ConnectionState.done and: ${snapshot.connectionState}");
          return Container();
        }
      },
    );
  }

  viewTicketButton(Function() onTap, context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(
            fixPadding,
          ),
          decoration: BoxDecoration(
            color: primaryColor,
            borderRadius: languageValue == 4
                ? const BorderRadius.only(
                    bottomLeft: Radius.circular(10.0),
                  )
                : const BorderRadius.only(
                    bottomRight: Radius.circular(10.0),
                  ),
            boxShadow: [boxShadow],
          ),
          alignment: Alignment.center,
          child: Text(
            getTranslation(context, 'my_booking.view_ticket'),
            style: bold16LightBlack,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }

  buttonWidget(String title, Function() onTap, Color color, Color textColor) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 1.2),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [boxShadow],
          color: color,
        ),
        child: Text(
          title,
          style: bold18TextColor.copyWith(color: textColor),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }
}
