import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/booking_model.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../theme/theme.dart';

class TicketScreenOnGoingParking extends StatelessWidget {
  final BookingModel? bookingModel;
  final ParkingModel? parkingModel;

  const TicketScreenOnGoingParking({super.key, this.parkingModel, this.bookingModel});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: scaffoldBgColor,
          titleSpacing: 20.0,
          shadowColor: shadowColor.withOpacity(0.25),
          foregroundColor: lightBlackColor,
          automaticallyImplyLeading: false,
          title: Text(
            getTranslation(context, 'parking_ticket.parking_ticket'),
            style: bold18LightBlack,
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(fixPadding * 2.0),
          physics: const BouncingScrollPhysics(),
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      borderRadius: BorderRadius.circular(10.0),
                      boxShadow: [boxShadow],
                    ),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2, vertical: fixPadding * 2.0),
                          child: Text(
                            getTranslation(context, 'parking_ticket.scan_text'),
                            style: semibold16LightBlack,
                            textAlign: TextAlign.center,
                          ),
                        ),
                        height5Space,
                        //+QR CODE PART

                        QrImageView(
                          padding: EdgeInsets.all(5),
                          data: jsonEncode(bookingModel?.toJson()),
                          version: QrVersions.auto,
                          size: 200.0,
                        ),
                        SizedBox(height: 10),

                        heightSpace,
                        heightSpace,
                        parkingDetail(context),
                        heightSpace,
                        heightSpace,
                        Container(
                          width: double.maxFinite,
                          padding: const EdgeInsets.all(fixPadding),
                          decoration: const BoxDecoration(color: Color(0xFFF0EEEE)),
                          alignment: Alignment.center,
                          child: Text(
                            "${getTranslation(context, 'parking_ticket.payment')} : \$ ${bookingModel?.totalPrice}(${getTranslation(context, 'parking_ticket.creditcard')})",
                            style: semibold16LightBlack,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Positioned(
                  left: -20,
                  right: -20,
                  top: size.height * 0.27,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: 40,
                        width: 40,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: scaffoldBgColor,
                        ),
                      ),
                      Container(
                        height: 40,
                        width: 40,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: scaffoldBgColor,
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
            heightSpace,
            heightSpace,
            Column(
              children: [
                GestureDetector(
                  onTap: () {
                    if (bookingModel?.lat != null && bookingModel?.lng != null) {
                      Utils.openMap(double.parse(bookingModel!.lat ?? ""), double.parse(bookingModel?.lng ?? ""));
                    } else {
                      Utils.errorToast("Something wrong unable to get directors");
                    }
                  },
                  child: Container(
                    width: double.maxFinite,
                    padding: const EdgeInsets.all(fixPadding * 1.4),
                    decoration: BoxDecoration(
                      color: primaryColor,
                      borderRadius: BorderRadius.circular(10.0),
                      boxShadow: [buttonShadow],
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      getTranslation(context, 'parking_ticket.get_direction'),
                      style: bold18LightBlack,
                    ),
                  ),
                ),
                heightSpace,
                heightSpace,
                Center(
                  child: InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      getTranslation(context, 'parking_ticket.not_now'),
                      style: bold18TextColor,
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  parkingDetail(context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2),
      child: Column(
        children: [
          parkingDetailRow(
            getTranslation(context, 'parking_ticket.name'),
            bookingModel?.parkingName ?? "",
            getTranslation(context, 'parking_ticket.parking_area'),
            "${bookingModel?.parkingAddress}",
          ),
          heightSpace,
          heightSpace,
          parkingDetailRow(
            getTranslation(context, 'parking_ticket.vehicle'),
            "${bookingModel?.vehicleName}",
            "License Plate",
            bookingModel?.licencePlateNumber != null ? "${bookingModel?.licencePlateNumber}" : "Not Available",
          ),
          heightSpace,
          heightSpace,
          parkingDetailRow(
            "Start Date",
            DateFormat.yMMMd().format(DateTime.fromMillisecondsSinceEpoch(bookingModel?.parkingStartDate ?? DateTime.now().millisecondsSinceEpoch)),
            "Time",
            "${DateFormat.jm().format(DateTime.fromMillisecondsSinceEpoch(bookingModel?.startingTime ?? DateTime.now().millisecondsSinceEpoch))} ",
          ),
          heightSpace,
          heightSpace,
          parkingDetailRow(
            "End Date",
            DateFormat.yMMMd().format(DateTime.fromMillisecondsSinceEpoch(bookingModel?.parkingEndDate ?? DateTime.now().millisecondsSinceEpoch)),
            "Time",
            "${DateFormat.jm().format(DateTime.fromMillisecondsSinceEpoch(bookingModel?.parkingEndDate ?? DateTime.now().millisecondsSinceEpoch))} ",
          ),
          heightSpace,
          heightSpace,
          parkingDetailRow(
            getTranslation(context, 'parking_ticket.duration'),
            "${bookingModel?.duration}",
            getTranslation(context, 'parking_ticket.phone'),
            "${bookingModel?.phoneNumber}",
          ),
          heightSpace,
          heightSpace,
        ],
      ),
    );
  }

  parkingDetailRow(title1, detail1, title2, detail2) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title1,
                style: semibold14Grey,
              ),
              Text(
                detail1,
                style: semibold15LightBlack,
              )
            ],
          ),
        ),
        widthSpace,
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title2,
                style: semibold14Grey,
              ),
              Text(
                detail2,
                style: semibold15LightBlack,
              )
            ],
          ),
        )
      ],
    );
  }
}
