import 'package:flutter/material.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/pages/profile/languages.dart';
import 'package:parkingproject/theme/theme.dart';

class BookingHistory extends StatefulWidget {
  BookingHistory({super.key});

  @override
  State<BookingHistory> createState() => _BookingHistoryState();
}

class _BookingHistoryState extends State<BookingHistory> {
  //
  int currentIndex = 3;

  List bookingHistory = [
    {
      "title": "Hapton holies parking",
      "image": "assets/myBooking/image6.png",
      "address": "1024 Botanic garden road,new york",
      "date": "3 April 2022",
      "price": "\$20",
      "rate": 4.5,
      "hour": 4
    },
    {
      "title": "Easkartoon shopping mall",
      "image": "assets/myBooking/image4.png",
      "address": "1024 Botanic garden road,new york",
      "date": "5 April 2022",
      "price": "\$15",
      "rate": 3.5,
      "hour": 3
    },
    {
      "title": "DCM parking spot",
      "image": "assets/myBooking/image3.png",
      "address": "1024 Botanic garden road,new york",
      "date": "6 April 2022",
      "price": "\$10",
      "rate": 2.5,
      "hour": 3
    },
    {
      "title": "DCM parking spot",
      "image": "assets/myBooking/image2.png",
      "address": "1024 Botanic garden road,new york",
      "date": "7 April 2022",
      "price": "\$12",
      "rate": 4.5,
      "hour": 1
    },
  ];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding),
      itemCount: bookingHistory.length,
      itemBuilder: (context, index) {
        return Container(
          margin: const EdgeInsets.symmetric(vertical: fixPadding),
          width: double.maxFinite,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: [boxShadow],
            color: whiteColor,
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(fixPadding),
                child: Row(
                  children: [
                    Container(
                      height: size.width * 0.2,
                      width: size.width * 0.25,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.0),
                        boxShadow: [boxShadow],
                        image: DecorationImage(
                          image: AssetImage(
                            bookingHistory[index]['image'].toString(),
                          ),
                          fit: BoxFit.cover,
                        ),
                      ),
                      alignment: Alignment.bottomRight,
                      child: Container(
                        padding: const EdgeInsets.all(3.0),
                        decoration: const BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(5.0),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.star,
                              color: textColor,
                              size: 16,
                            ),
                            widthBox(3.0),
                            Text(
                              bookingHistory[index]['rate'].toString(),
                              style: semibold14LightBlack,
                            ),
                          ],
                        ),
                      ),
                    ),
                    widthSpace,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            bookingHistory[index]['title'].toString(),
                            style: semibold16LightBlack,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            bookingHistory[index]['address'].toString(),
                            style: semibold14Grey,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            bookingHistory[index]['date'].toString(),
                            style: semibold14Grey,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text.rich(
                            TextSpan(
                                text: "${bookingHistory[index]['price']}/",
                                style: semibold16LightBlack,
                                children: [TextSpan(text: "${bookingHistory[index]['hour']} ${getTranslation(context, 'my_booking.hour')}", style: semibold12Grey)]),
                            overflow: TextOverflow.ellipsis,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Row(
                children: [
                  giveRateButton(size, context),
                  viewTicketButton(() {
                    Navigator.pushNamed(context, '/parkingTicket', arguments: {"id": 0});
                  }),
                ],
              )
            ],
          ),
        );
      },
    );
  }

  giveRateButton(Size size, context) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          giveRateBottomSheet(size, context);
        },
        child: Container(
          padding: const EdgeInsets.all(fixPadding),
          decoration: BoxDecoration(
            color: whiteColor,
            borderRadius: languageValue == 4
                ? const BorderRadius.only(
                    bottomRight: Radius.circular(10.0),
                  )
                : const BorderRadius.only(
                    bottomLeft: Radius.circular(10.0),
                  ),
            boxShadow: [boxShadow],
          ),
          alignment: Alignment.center,
          child: Text(
            getTranslation(context, 'my_booking.give_rate'),
            style: bold16TextColor,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }

  giveRateBottomSheet(Size size, context) {
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, state) {
          return Container(
            width: double.maxFinite,
            padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(20.0),
              ),
              color: whiteColor,
            ),
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.only(bottom: fixPadding * 2.0, top: fixPadding * 1.5, left: fixPadding * 2.0, right: fixPadding * 2.0),
              physics: const BouncingScrollPhysics(),
              children: [
                Center(
                  child: Container(
                    height: 1,
                    width: 60,
                    color: greyD9Color,
                  ),
                ),
                heightSpace,
                heightSpace,
                Text(
                  getTranslation(context, 'my_booking.your_review'),
                  style: bold18TextColor,
                  textAlign: TextAlign.center,
                ),
                heightSpace,
                height5Space,
                Text(
                  getTranslation(context, 'my_booking.please_text'),
                  style: semibold18LightBlack,
                  textAlign: TextAlign.center,
                ),
                heightSpace,
                heightSpace,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (int i = 0; i < 5; i++) _buildStar(i, state),
                  ],
                ),
                heightSpace,
                heightSpace,
                Container(
                  height: size.height * 0.15,
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: whiteColor,
                    boxShadow: [boxShadow],
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Theme(
                    data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                    child: TextField(
                      expands: true,
                      maxLines: null,
                      minLines: null,
                      cursorColor: primaryColor,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                        border: InputBorder.none,
                        hintText: getTranslation(context, 'my_booking.say_something'),
                        hintStyle: medium16Grey,
                      ),
                    ),
                  ),
                ),
                heightSpace,
                heightSpace,
                heightSpace,
                Row(
                  children: [
                    Expanded(
                      child: buttonWidget(
                        getTranslation(context, 'my_booking.remind_later'),
                        () {
                          Navigator.pop(context);
                        },
                        whiteColor,
                        textColor,
                      ),
                    ),
                    widthSpace,
                    widthSpace,
                    Expanded(
                      child: buttonWidget(
                        getTranslation(context, 'my_booking.send'),
                        () {
                          Navigator.pop(context);
                        },
                        primaryColor,
                        lightBlackColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
      },
    );
  }

  _buildStar(int index, state) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding / 4),
      child: InkWell(
        onTap: () {
          state(() {
            setState(() {
              currentIndex = index;
            });
          });
        },
        child: Icon(
          Icons.star_rounded,
          color: (currentIndex >= index) ? primaryColor : const Color(0xFFBAB3B3),
          size: 35,
        ),
      ),
    );
  }

  buttonWidget(String title, Function() onTap, Color color, Color textColor) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 1.2),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [boxShadow],
          color: color,
        ),
        child: Text(
          title,
          style: bold18TextColor.copyWith(color: textColor),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }

  viewTicketButton(Function() onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(
            fixPadding,
          ),
          decoration: BoxDecoration(
            color: primaryColor,
            borderRadius: languageValue == 4
                ? const BorderRadius.only(
                    bottomLeft: Radius.circular(10.0),
                  )
                : const BorderRadius.only(
                    bottomRight: Radius.circular(10.0),
                  ),
            boxShadow: [boxShadow],
          ),
          alignment: Alignment.center,
          child: Text(
            getTranslation(context, 'my_booking.view_ticket'),
            style: bold16LightBlack,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }
}
