import 'package:flutter/material.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/pages/auth/login.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:provider/provider.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Column(
        children: [
          topCarImage(size),
          Expanded(
            child: Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(fixPadding * 2.0),
                physics: const BouncingScrollPhysics(),
                children: [
                  loginText(),
                  heightSpace,
                  pleaseText(),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  emailField(context),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  loginButton(),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  Center(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.arrow_back_ios_new_outlined,
                          size: 12,
                          color: lightBlackColor,
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => LoginScreen()));
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(right: 0),
                            child: Text(
                              "Back to Login",
                              style: TextStyle(
                                color: lightBlackColor,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                decoration: TextDecoration.underline,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  /* Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [const Text("Dont'have an account?"), signUpButton(context)],
                  )*/
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  TextButton signUpButton(BuildContext context) {
    return TextButton(
        onPressed: () {
          // Navigator.pushNamed(context, '/register');
        },
        child: const Text(
          'Sign up',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
        ));
  }

  loginButton() {
    return GestureDetector(
      onTap: () {
        // showLoadingDialog(context);
        // // Navigator.pushNamed(context, '/register');
        AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
        authProvider.sendPasswordResetEmail(context);
      },
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.all(fixPadding * 1.4),
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [buttonShadow],
        ),
        alignment: Alignment.center,
        child: Text(
          "Continue",
          style: bold18LightBlack,
        ),
      ),
    );
  }

  emailField(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Container(
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [boxShadow],
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
        child: TextFormField(
          controller: authProvider.emailAddressController,
          cursorColor: primaryColor,
          keyboardType: TextInputType.emailAddress,
          validator: (val) {
            if (val?.isEmpty ?? false) {
              return 'Please enter email address';
            }
            return null;
          },
          decoration: InputDecoration(
              contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
              border: InputBorder.none,
              prefixIcon: const Icon(
                Icons.email_outlined,
                size: 20,
              ),
              hintText: getTranslation(context, 'register.email_address'),
              hintStyle: bold16Grey),
        ),
      ),
    );
  }

  loginText() {
    return Text(
      "Forgot Password",
      style: bold20LightBlack,
      textAlign: TextAlign.center,
    );
  }

  pleaseText() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2),
      child: Text(
        "Please enter your email address",
        textAlign: TextAlign.center,
        style: bold14Grey,
      ),
    );
  }

  topCarImage(Size size) {
    return Container(
      height: size.height * 0.29,
      width: double.maxFinite,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage(
            "assets/auth/car.png",
          ),
          fit: BoxFit.fill,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: const [0.85, 1.0],
            colors: [
              whiteColor.withOpacity(0),
              greyA1Color,
            ],
          ),
        ),
      ),
    );
  }
}
