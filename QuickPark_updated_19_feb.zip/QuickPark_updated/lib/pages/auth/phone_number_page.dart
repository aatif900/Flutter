import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:provider/provider.dart';

import '../../theme/theme.dart';
import '../profile/languages.dart';

class PhoneNumberScreen extends StatefulWidget {
  const PhoneNumberScreen({super.key});

  @override
  State<PhoneNumberScreen> createState() => _PhoneNumberScreenState();
}

class _PhoneNumberScreenState extends State<PhoneNumberScreen> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Column(
        children: [
          topCarImage(size),
          Expanded(
            child: Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(fixPadding * 2.0),
                physics: const BouncingScrollPhysics(),
                children: [
                  registerText(),
                  heightSpace,
                  pleaseText(),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  phoneField(context),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  SizedBox(height: MediaQuery.sizeOf(context).height * 0.3),
                  registerButton(),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  registerButton() {
    return GestureDetector(
      onTap: () async {
        AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

        if (authProvider.phoneNumberController.text.isEmpty) {
          Utils.showCustomSnackBar(context, "Please enter phone number");
        } else {

          await authProvider.phoneSignUpMissingLinkedPhone(context);
        }
      },
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.all(fixPadding * 1.4),
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [buttonShadow],
        ),
        alignment: Alignment.center,
        child: Text(
          // getTranslation(context, 'register.register'),
          "Continue",
          style: bold18LightBlack,
        ),
      ),
    );
  }

  phoneField(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Container(
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [boxShadow],
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
        child: Row(
          children: [
            // SizedBox(width: 10),
            // Container(
            //   // width: double.maxFinite,
            //   decoration: BoxDecoration(
            //     color: whiteColor,
            //     boxShadow: [boxShadow],
            //     borderRadius: BorderRadius.circular(10.0),
            //   ),
            //   child: Theme(
            //     data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
            //     child: const Icon(
            //       Icons.phone_android_outlined,
            //       size: 20,
            //     ),
            //   ),
            // ),

            GestureDetector(
              onTap: () {
                showCountryPicker(
                  context: context,
                  exclude: <String>['KN', 'MF'],
                  showPhoneCode: true,
                  onSelect: (Country country) {
                    authProvider.getCountryCodeAndPhone(
                      country.flagEmoji,
                      country.phoneCode,
                    );
                  },
                  countryListTheme: CountryListThemeData(
                    searchTextStyle: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      // color: whiteColor,
                    ),
                    bottomSheetHeight: MediaQuery.sizeOf(context).height * 0.7,
                    textStyle: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      // color: whiteColor,

                      // color: kBlackColor,
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16.0),
                      topRight: Radius.circular(16.0),
                    ),
                    // Optional. Styles the search field.
                    inputDecoration: InputDecoration(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 15),
                      hintText: 'Search...',
                      hintStyle: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        // color: kSecondaryColor,
                      ),
                      // fillColor: kPrimaryColor,
                      filled: true,
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(
                          // color: Colors.red,
                          width: 1.0,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(
                          // color: kBorderColor,
                          width: 1.0,
                        ),
                      ),
                    ),
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 0),
                width: 90,
                height: 45,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                  color: whiteColor,
                  boxShadow: const [
                    BoxShadow(
                        // color: kSecondaryColor.withOpacity(0.05),
                        // blurRadius: 2,
                        // offset: const Offset(0, 1),
                        ),
                  ],
                ),
                child: Center(
                  child: Consumer<AuthProvider>(
                    builder: (context, authProvider, child) {
                      return Text(
                        '${authProvider.countryFlag}  +${authProvider.countryCode.toString()}',
                        style: semibold14Grey.copyWith(
                          color: const Color(0xFF8E8E8E),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            // const SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                cursorColor: primaryColor,
                keyboardType: TextInputType.phone,
                controller: authProvider.phoneNumberController,
                validator: (val) {
                  if (val?.isEmpty ?? false) {
                    return 'Please enter phone number';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                  border: InputBorder.none,
                  prefixIcon: const Icon(
                    Icons.phone_android_outlined,
                    size: 20,
                  ),
                  hintText: getTranslation(context, 'register.phone_number'),
                  hintStyle: bold16Grey,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  registerText() {
    return Text(
      // getTranslation(context, 'register.user_name'),
      "Enter Phone Number",
      style: bold20LightBlack,
      textAlign: TextAlign.center,
    );
  }

  pleaseText() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2),
      child: Text(
        getTranslation(context, 'register.please_text'),
        textAlign: TextAlign.center,
        style: bold14Grey,
      ),
    );
  }

  topCarImage(Size size) {
    return Container(
      height: size.height * 0.29,
      width: double.maxFinite,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage(
            "assets/auth/car.png",
          ),
          fit: BoxFit.fill,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: const [0.85, 1.0],
            colors: [
              whiteColor.withOpacity(0),
              greyA1Color,
            ],
          ),
        ),
        alignment: languageValue == 4 ? Alignment.topRight : Alignment.topLeft,
        child: IconButton(
          padding: const EdgeInsets.only(top: fixPadding * 3.5, left: fixPadding * 2.0, right: fixPadding * 2.0, bottom: fixPadding * 2.0),
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: lightBlackColor,
          ),
        ),
      ),
    );
  }
}
