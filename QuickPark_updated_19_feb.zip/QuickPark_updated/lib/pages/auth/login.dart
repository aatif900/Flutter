import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/pages/auth/forgot_password.dart';
import 'package:parkingproject/pages/auth/register.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:provider/provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    log("login page he ha");
    final size = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: Scaffold(
        body: Column(
          children: [
            topCarImage(size),
            Expanded(
              child: Form(
                key: _formKey,
                child: ListView(
                  padding: const EdgeInsets.all(fixPadding * 2.0),
                  physics: const BouncingScrollPhysics(),
                  children: [
                    loginText(),
                    heightSpace,
                    pleaseText(),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    emailField(context),
                    heightSpace,
                    heightSpace,
                    passwordField(context),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    loginButton(),
                    heightSpace,
                    GestureDetector(
                      onTap: () {
                        pageNavigator(context, ForgotPasswordScreen());
                      },
                      child: const Padding(
                        padding: EdgeInsets.only(right: 09),
                        child: Text(
                          "Forgot Password ?",
                          style: TextStyle(
                            color: lightBlackColor,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            decoration: TextDecoration.underline,
                          ),
                          textAlign: TextAlign.end,
                        ),
                      ),
                    ),
                    heightSpace,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text("Dont'have an account?"),
                        signUpButton(context),
                      ],
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  TextButton signUpButton(BuildContext context) {
    return TextButton(
        onPressed: () {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => RegisterScreen()));
        },
        child: const Text(
          'Sign up',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
        ));
  }

  loginButton() {
    return GestureDetector(
      onTap: () {
        AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
        authProvider.signInWithEmailAndPassword(context);
      },
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.all(fixPadding * 1.4),
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [buttonShadow],
        ),
        alignment: Alignment.center,
        child: Text(
          getTranslation(context, 'login.login'),
          style: bold18LightBlack,
        ),
      ),
    );
  }

  passwordField(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Container(
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [boxShadow],
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
        child: Consumer<AuthProvider>(
          builder: (context, provider, child) {
            return TextFormField(
              obscureText: authProvider.isHidden,
              cursorColor: primaryColor,
              controller: authProvider.passwordController,
              // keyboardType: TextInputType.phone,
              validator: (val) {
                if (val?.isEmpty ?? false) {
                  return 'Please enter password';
                } else if (val!.length < 6) {
                  return "Password must be six or greater then six digit";
                }
                return null;
              },
              decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                  border: InputBorder.none,
                  prefixIcon: const Icon(
                    Icons.phone_android_outlined,
                    size: 20,
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      authProvider.isHidden ? Icons.visibility_off : Icons.visibility,
                    ),
                    onPressed: authProvider.togglePasswordView,
                  ),
                  hintText: getTranslation(context, 'register.password'),
                  hintStyle: bold16Grey),
            );
          },
        ),
      ),
    );
  }

  emailField(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Container(
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [boxShadow],
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
        child: TextFormField(
          controller: authProvider.emailAddressController,
          cursorColor: primaryColor,
          keyboardType: TextInputType.emailAddress,
          validator: (val) {
            if (val?.isEmpty ?? false) {
              return 'Please enter email address';
            }
            return null;
          },
          decoration: InputDecoration(
              contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
              border: InputBorder.none,
              prefixIcon: const Icon(
                Icons.email_outlined,
                size: 20,
              ),
              hintText: getTranslation(context, 'register.email_address'),
              hintStyle: bold16Grey),
        ),
      ),
    );
  }

  loginText() {
    return Text(
      getTranslation(context, 'login.login'),
      style: bold20LightBlack,
      textAlign: TextAlign.center,
    );
  }

  pleaseText() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2),
      child: Text(
        // getTranslation(context, 'login.please_text'),
        "Please enter your email address and password to login to your account ",

        textAlign: TextAlign.center,
        style: bold14Grey,
      ),
    );
  }

  topCarImage(Size size) {
    return Container(
      height: size.height * 0.29,
      width: double.maxFinite,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage(
            "assets/auth/car.png",
          ),
          fit: BoxFit.fill,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: const [0.85, 1.0],
            colors: [
              whiteColor.withOpacity(0),
              greyA1Color,
            ],
          ),
        ),
      ),
    );
  }
}
