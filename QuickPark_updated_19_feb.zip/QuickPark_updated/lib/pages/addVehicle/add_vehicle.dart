import 'package:flutter/material.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/add_vehicle_model.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:parkingproject/widget/column_builder.dart';
import 'package:parkingproject/widget/my_custom_text_form_field.dart';

import '../../theme/theme.dart';

class AddVehicleScreen extends StatefulWidget {
  const AddVehicleScreen({super.key});

  @override
  State<AddVehicleScreen> createState() => _AddVehicleScreenState();
}

class _AddVehicleScreenState extends State<AddVehicleScreen> {
  TextEditingController registrationController = TextEditingController();
  TextEditingController manufacturerController = TextEditingController();
  TextEditingController vehicleColorController = TextEditingController();
  TextEditingController vehicleLicencePlateController = TextEditingController();

  final vehicleTypeList = [
    "Car",
    "SUV",
    "Motorcycle",
    "Camper",
  ];

  final vehicalNameList = [
    {
      "image": "assets/addVehical/yellowCar.png",
      "name": "Tata Nexon",
    },
    {
      "image": "assets/addVehical/purpleCar.png",
      "name": "Honda e",
    },
    {
      "image": "assets/addVehical/greenCar.png",
      "name": "Volvo XC40 Recharge",
    },
    {
      "image": "assets/addVehical/purpleCar.png",
      "name": "Kia EV6",
    },
    {
      "image": "assets/addVehical/yellowCar.png",
      "name": "BMW i4",
    },
    {
      "image": "assets/addVehical/greenCar.png",
      "name": "MG ZS EV",
    },
    {
      "image": "assets/addVehical/purpleCar.png",
      "name": "Porsche Taycan",
    },
    {
      "image": "assets/addVehical/whiteCar.png",
      "name": "Jaguar I-Pace",
    },
    {
      "image": "assets/addVehical/yellowCar.png",
      "name": "Porsche Taycan",
    },
    {
      "image": "assets/addVehical/cyanCar.png",
      "name": "BMW iX",
    },
    {
      "image": "assets/addVehical/greenCar.png",
      "name": "Tesla",
    },
    {
      "image": "assets/addVehical/yellowCar.png",
      "name": "Mercedes-Benz ",
    },
    {
      "image": "assets/addVehical/purpleCar.png",
      "name": "Mini Cooper SE",
    },
  ];
  String? vehicleType;
  String? vehicalname;

  @override
  void initState() {
    vehicleType = vehicleTypeList[0];
    vehicalname = vehicalNameList[3]['name'];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: scaffoldBgColor,
        titleSpacing: 0.0,
        shadowColor: shadowColor.withOpacity(0.25),
        foregroundColor: lightBlackColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
        title: Text(
          getTranslation(context, 'add_vehicle.add_vehicle'),
          style: bold18LightBlack,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(fixPadding * 2.0),
        physics: const BouncingScrollPhysics(),
        children: [
          vehicleTypeField(),
          heightSpace,
          heightSpace,
          MyTextFormField(
            controller: manufacturerController,
            topTextStyle: semibold16Grey,
            topText: "Vehicle Manufacturer & Type",
            hintText: "Vehicle Manufacturer & Type",
          ),
          heightSpace,
          heightSpace,
          MyTextFormField(
            controller: vehicleColorController,
            topTextStyle: semibold16Grey,
            topText: "Vehicle Color",
            hintText: "Vehicle Color",
          ),
          heightSpace,
          heightSpace,
          MyTextFormField(
            controller: vehicleLicencePlateController,
            topTextStyle: semibold16Grey,
            topText: "Vehicle Licence Plate",
            hintText: "Vehicle Licence Plate",
          ),
          heightSpace,
          heightSpace,
          heightSpace,
          heightSpace,
          addButton(context)
        ],
      ),
    );
  }

  addButton(BuildContext context) {
    return GestureDetector(
      onTap: addVehicleToDataBase,
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.all(fixPadding * 1.4),
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [buttonShadow],
        ),
        child: Text(
          getTranslation(context, 'add_vehicle.add'),
          style: bold18LightBlack,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  vehicalRegisterNumber() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          getTranslation(context, 'add_vehicle.vehicle_number'),
          style: semibold16Grey,
        ),
        heightSpace,
        Container(
          width: double.maxFinite,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.0),
            color: whiteColor,
            boxShadow: [
              BoxShadow(
                color: blackColor.withOpacity(0.2),
                blurRadius: 6,
              )
            ],
          ),
          child: TextField(
            controller: registrationController,
            style: semibold15LightBlack,
            cursorColor: primaryColor,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(fixPadding * 1.5),
              hintText: getTranslation(context, 'add_vehicle.enter_vehical_number'),
            ),
          ),
        )
      ],
    );
  }

  vehicalName(Size size) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          getTranslation(context, 'add_vehicle.vehicle_name'),
          style: semibold16Grey,
        ),
        heightSpace,
        GestureDetector(
          onTap: () {
            vehicalNameBottomsheet(size);
          },
          child: Container(
            padding: const EdgeInsets.all(fixPadding * 1.5),
            width: double.maxFinite,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5.0),
              color: whiteColor,
              boxShadow: [
                BoxShadow(
                  color: blackColor.withOpacity(0.2),
                  blurRadius: 6,
                )
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    vehicalname.toString(),
                    style: semibold15LightBlack,
                  ),
                ),
                width5Space,
                const Icon(
                  Icons.arrow_drop_down,
                  color: blackColor,
                )
              ],
            ),
          ),
        )
      ],
    );
  }

  vehicalNameBottomsheet(Size size) {
    return showModalBottomSheet(
      backgroundColor: Colors.transparent,
      constraints: BoxConstraints(maxHeight: size.height * 0.9),
      isScrollControlled: true,
      context: context,
      builder: (context) {
        return Container(
          width: double.maxFinite,
          padding: const EdgeInsets.all(fixPadding * 2.0),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(20.0),
            ),
          ),
          child: Column(
            children: [
              Text(
                getTranslation(context, 'add_vehicle.vehicle_name'),
                style: bold16LightBlack,
                textAlign: TextAlign.center,
              ),
              heightSpace,
              height5Space,
              Container(
                width: double.maxFinite,
                decoration: BoxDecoration(
                  color: whiteColor,
                  boxShadow: [boxShadow],
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Theme(
                  data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                  child: TextField(
                    cursorColor: primaryColor,
                    decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                        border: InputBorder.none,
                        prefixIcon: const Icon(
                          Icons.search,
                          size: 20,
                        ),
                        hintText: getTranslation(context, 'add_vehicle.search_vehicle'),
                        hintStyle: bold16Grey),
                  ),
                ),
              ),
              heightSpace,
              Expanded(
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  padding: EdgeInsets.zero,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          vehicalname = vehicalNameList[index]['name'];
                        });

                        Navigator.pop(context);
                      },
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: fixPadding / 2),
                        padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 1.1),
                        decoration: vehicalname == vehicalNameList[index]['name']
                            ? BoxDecoration(color: const Color(0xFFFEF4DA), borderRadius: BorderRadius.circular(10.0), border: Border.all(color: primaryColor))
                            : const BoxDecoration(),
                        child: Row(
                          children: [
                            Image.asset(
                              vehicalNameList[index]['image'].toString(),
                              height: 26,
                              fit: BoxFit.cover,
                            ),
                            widthSpace,
                            Expanded(
                                child: Text(
                              vehicalNameList[index]['name'].toString(),
                              style: semibold14Black,
                            )),
                            widthSpace,
                            vehicalname == vehicalNameList[index]['name']
                                ? Container(
                                    height: 20,
                                    width: 20,
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: primaryColor,
                                    ),
                                    child: const Icon(
                                      Icons.done,
                                      color: whiteColor,
                                      size: 13,
                                    ),
                                  )
                                : const SizedBox(),
                          ],
                        ),
                      ),
                    );
                  },
                  itemCount: vehicalNameList.length,
                ),
              )
            ],
          ),
        );
      },
    );
  }

  vehicleTypeField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          getTranslation(context, 'add_vehicle.vehicle_type'),
          style: semibold16Grey,
        ),
        heightSpace,
        GestureDetector(
          onTap: () {
            vehicalTypeBottomSheet();
          },
          child: Container(
            padding: const EdgeInsets.all(fixPadding * 1.5),
            width: double.maxFinite,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5.0),
              color: whiteColor,
              boxShadow: [
                BoxShadow(
                  color: blackColor.withOpacity(0.2),
                  blurRadius: 6,
                )
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    vehicleType.toString(),
                    style: semibold15LightBlack,
                  ),
                ),
                width5Space,
                const Icon(
                  Icons.arrow_drop_down,
                  color: blackColor,
                )
              ],
            ),
          ),
        )
      ],
    );
  }

  vehicalTypeBottomSheet() {
    return showModalBottomSheet(
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      context: context,
      builder: (context) {
        return Container(
          width: double.maxFinite,
          padding: const EdgeInsets.all(fixPadding * 2.0),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(20.0),
            ),
          ),
          child: ListView(
            shrinkWrap: true,
            children: [
              Text(
                getTranslation(context, 'add_vehicle.vehicle_type'),
                style: bold16LightBlack,
                textAlign: TextAlign.center,
              ),
              heightSpace,
              height5Space,
              ColumnBuilder(
                itemCount: vehicleTypeList.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        vehicleType = vehicleTypeList[index];
                      });
                      Navigator.pop(context);
                    },
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: fixPadding / 2),
                      padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 1.1),
                      decoration: vehicleType == vehicleTypeList[index]
                          ? BoxDecoration(color: const Color(0xFFFEF4DA), borderRadius: BorderRadius.circular(10.0), border: Border.all(color: primaryColor))
                          : const BoxDecoration(),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              vehicleTypeList[index],
                              style: semibold14Black,
                            ),
                          ),
                          widthSpace,
                          vehicleType == vehicleTypeList[index]
                              ? Container(
                                  height: 20,
                                  width: 20,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: primaryColor,
                                  ),
                                  child: const Icon(
                                    Icons.done,
                                    color: whiteColor,
                                    size: 13,
                                  ),
                                )
                              : const SizedBox(),
                        ],
                      ),
                    ),
                  );
                },
              )
            ],
          ),
        );
      },
    );
  }

  Future<void> addVehicleToDataBase() async {
    hideKeyBoard(context);

    if (vehicleLicencePlateController.text.isEmpty) {
      Utils.errorToast("Please enter vehicle licence plate.");
    } else if (manufacturerController.text.isEmpty) {
      Utils.errorToast("Please enter vehicle manufactured type.");
    } else if (vehicleColorController.text.isEmpty) {
      Utils.errorToast("Please enter vehicle color");
    } else {
      showLoadingDialog(context);
      VehicleModel addVehicleModel = VehicleModel(
        createdAt: DateTime.now().millisecondsSinceEpoch,
        vehicleType: vehicleType,
        vehicleColor: vehicleColorController.text.trim(),
        vehicleLicencePlate: vehicleLicencePlateController.text.trim(),
        vehicleManufacturer: manufacturerController.text.trim(),
      );
      await ffstore
          .collection(collectionUsers) //
          .doc(auth.currentUser!.uid)
          .collection(collectionVehicles)
          .add(
            addVehicleModel.toJson(),
          );
      Navigator.of(context).pop();
      Utils.toast("Vehicle added successfully !");
      await Future.delayed(Duration(seconds: 1));
      Navigator.of(context).pop();
    }
  }
}
