import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/pages/paymentMethods/payment_methods.dart';
import 'package:parkingproject/provider/booking_provider.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:provider/provider.dart';

import '../../theme/theme.dart';

enum Status {
  booked,
  available,
}

class SelectSlotScreen extends StatefulWidget {
  final ParkingModel? parkingModel;

  const SelectSlotScreen({super.key, this.parkingModel});

  @override
  State<SelectSlotScreen> createState() => _SelectSlotScreenState();
}

class _SelectSlotScreenState extends State<SelectSlotScreen> {
  final List floor = ["1st Floor", "2nd Floor", "3th Floor", "4th Floor"];

  final List aSlotList = [
    {"name": "A0", "id": 0, "AlreadyBooking": true},
    {"name": "A1", "id": 1, "AlreadyBooking": true},
    {"name": "A2", "id": 2, "AlreadyBooking": false},
    {"name": "A3", "id": 3, "AlreadyBooking": true},
    {"name": "A4", "id": 4, "AlreadyBooking": true},
    {"name": "A5", "id": 5, "AlreadyBooking": false},
    {"name": "A6", "id": 6, "AlreadyBooking": true},
    {"name": "A7", "id": 7, "AlreadyBooking": true},
    {"name": "A8", "id": 8, "AlreadyBooking": false},
  ];

  final List bSlotList = [
    {"name": "B0", "id": 9, "AlreadyBooking": true},
    {"name": "B1", "id": 10, "AlreadyBooking": false},
    {"name": "B2", "id": 11, "AlreadyBooking": true},
    {"name": "B3", "id": 12, "AlreadyBooking": false},
    {"name": "B4", "id": 13, "AlreadyBooking": true},
    {"name": "B5", "id": 14, "AlreadyBooking": true},
    {"name": "B6", "id": 15, "AlreadyBooking": false},
    {"name": "B7", "id": 16, "AlreadyBooking": true},
    {"name": "B8", "id": 17, "AlreadyBooking": true},
  ];

  int selectedFloor = 0;

  @override
  Widget build(BuildContext context) {
    final bookingProvider = Provider.of<BookingProvider>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: scaffoldBgColor,
        titleSpacing: 0.0,
        shadowColor: shadowColor.withOpacity(0.25),
        foregroundColor: lightBlackColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
        title: Text(
          getTranslation(context, 'select_slot.select_slot'),
          style: bold18LightBlack,
        ),
      ),
      body: Column(
        children: [
          height5Space,
          //+Floor List
          SingleChildScrollView(
            padding: const EdgeInsets.all(fixPadding * 1.5),
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: List.generate(floor.length, (index) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedFloor = index;
                    });
                  },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: fixPadding / 2),
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 0.7),
                    decoration: BoxDecoration(
                        color: selectedFloor == index ? primaryColor : null,
                        borderRadius: BorderRadius.circular(5.0),
                        border: selectedFloor == index ? null : Border.all(color: primaryColor)),
                    child: Text(
                      floor[index],
                      style: bold14LightBlack,
                    ),
                  ),
                );
              }),
            ),
          ),
          heightSpace,
          Expanded(
            child: ListView(
              clipBehavior: Clip.antiAliasWithSaveLayer,
              shrinkWrap: true,
              padding: const EdgeInsets.only(left: fixPadding * 2.0, right: fixPadding * 2.0),
              physics: const BouncingScrollPhysics(),
              children: [
                Row(
                  children: [
                    Expanded(
                        flex: 2,
                        child: Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF6E3B3),
                                borderRadius: BorderRadius.circular(4.0),
                              ),
                              child: Text(
                                "A",
                                style: bold16LightBlack,
                              ),
                            ),
                            height5Space,
                            heightSpace,
                            divider(),

                            /*    StreamBuilder<QuerySnapshot>(
                              stream: ffstore.collection("Slots").snapshots(),
                              builder: (BuildContext context, AsyncSnapshot snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return const SizedBox();
                                } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
                                  if (snapshot.hasError) {
                                    return const Text('Error');
                                  } else if (snapshot.hasData && snapshot.data != null) {
                                    // log("snapshot.data!['images'].length   ${snapshot.data!['prohibitedWords'].length}");

                                    return ListView.builder(
                                      itemCount: 3,
                                      itemBuilder: (BuildContext context, int index) {
                                        Map<String, dynamic> data = Map<String, dynamic>.from(snapshot.data.docs[index].data());
                                        return Column(
                                          children: [
                                            Container(
                                              padding: const EdgeInsets.symmetric(vertical: fixPadding),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  data['AlreadyBooking'] == Status.booked
                                                      ? Image.asset(
                                                          "assets/selectVehical/vehical1.png",
                                                          height: 30,
                                                          width: 50,
                                                        )
                                                      : GestureDetector(
                                                          onTap: () {
                                                            setState(() {
                                                              selectedindex = aSlotList[index]['id'];
                                                            });
                                                          },
                                                          child: Container(
                                                            height: 30,
                                                            width: 50,
                                                            decoration: BoxDecoration(
                                                              color: selectedindex == aSlotList[index]['id'] ? primaryColor : whiteColor,
                                                              borderRadius: BorderRadius.circular(5.0),
                                                              border: Border.all(color: primaryColor),
                                                            ),
                                                          ),
                                                        ),
                                                  Text(
                                                    aSlotList[index]['name'],
                                                    style: bold15LightBlack,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            divider(),
                                          ],
                                        );
                                      },
                                    );

                                    return Column(
                                      children: List.generate(3, (index) {
                                        return Column(
                                          children: [
                                            Container(
                                              padding: const EdgeInsets.symmetric(vertical: fixPadding),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  aSlotList[index]['AlreadyBooking'] == true
                                                      ? Image.asset(
                                                          "assets/selectVehical/vehical1.png",
                                                          height: 30,
                                                          width: 50,
                                                        )
                                                      : GestureDetector(
                                                          onTap: () {
                                                            setState(() {
                                                              selectedindex = aSlotList[index]['id'];
                                                            });
                                                          },
                                                          child: Container(
                                                            height: 30,
                                                            width: 50,
                                                            decoration: BoxDecoration(
                                                              color: selectedindex == aSlotList[index]['id'] ? primaryColor : whiteColor,
                                                              borderRadius: BorderRadius.circular(5.0),
                                                              border: Border.all(color: primaryColor),
                                                            ),
                                                          ),
                                                        ),
                                                  Text(
                                                    aSlotList[index]['name'],
                                                    style: bold15LightBlack,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            divider(),
                                          ],
                                        );
                                      }),
                                    );
                                  } else {
                                    return Container();
                                  }
                                } else {
                                  return Text('State: ${snapshot.connectionState}');
                                }
                              },
                            ),*/

                            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                              stream: ffstore
                                  .collection("Slots") //
                                  .doc(widget.parkingModel?.documentID)
                                  .collection(widget.parkingModel?.documentID ?? "")
                                  .snapshots(),
                              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return const SizedBox();
                                } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
                                  if (snapshot.hasError) {
                                    return const Text('Error');
                                  } else if (snapshot.hasData && snapshot.data != null) {
                                    // log("snapshot.data!['images'].length   ${snapshot.data!['prohibitedWords'].length}");
                                    return Column(
                                      children: List.generate(snapshot.data!.docs.length, (index) {
                                        Map<String, dynamic> data = Map<String, dynamic>.from(snapshot.data!.docs[index].data() as Map<String, dynamic>);
                                        // log("Data is ${data}");
                                        log("data['status'] ${data['status']}");
                                        log("Enum Status  ${Status.booked.name}");
                                        log("${data['status'] == Status.booked.name}");
                                        return Column(
                                          children: [
                                            Container(
                                              padding: const EdgeInsets.symmetric(vertical: fixPadding),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  data['status'] == Status.booked.name
                                                      ? Image.asset(
                                                          "assets/selectVehical/vehical1.png",
                                                          height: 30,
                                                          width: 50,
                                                        )
                                                      : GestureDetector(
                                                          onTap: () {
                                                            bookingProvider.updateSelectedSlotNameAndIndex(snapshot.data!.docs[index]['slotName'], index);

                                                            /* setState(() {
                                                              bookingProvider.selectedNameForSlot = snapshot.data!.docs[index]['slotName'];
                                                            });*/
                                                          },
                                                          child: Consumer<BookingProvider>(
                                                            builder: (context, provider, child) {
                                                              return Container(
                                                                height: 30,
                                                                width: 50,
                                                                decoration: BoxDecoration(
                                                                  color: bookingProvider.selectedNameForSlot == snapshot.data!.docs[index]['slotName']
                                                                      ? primaryColor
                                                                      : whiteColor,
                                                                  borderRadius: BorderRadius.circular(5.0),
                                                                  border: Border.all(color: primaryColor),
                                                                ),
                                                              );
                                                            },
                                                          ),
                                                        ),
                                                  Text(
                                                    data['slotName'],
                                                    style: bold15LightBlack,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            divider(),
                                          ],
                                        );
                                      }),
                                    );
                                  } else {
                                    return Container();
                                  }
                                } else {
                                  return Text('State: ${snapshot.connectionState}');
                                }
                              },
                            ),

                            //+OLD ORIGINAL CODE
                            // ColumnBuilder(
                            //   itemCount: aSlotList.length,
                            //   itemBuilder: (context, index) {
                            //     return Column(
                            //       children: [
                            //         Container(
                            //           padding: const EdgeInsets.symmetric(vertical: fixPadding),
                            //           child: Row(
                            //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            //             children: [
                            //               aSlotList[index]['AlreadyBooking'] == true
                            //                   ? Image.asset(
                            //                 "assets/selectVehical/vehical1.png",
                            //                 height: 30,
                            //                 width: 50,
                            //               )
                            //                   : GestureDetector(
                            //                 onTap: () {
                            //                   setState(() {
                            //                     selectedindex = aSlotList[index]['id'];
                            //                   });
                            //                 },
                            //                 child: Container(
                            //                   height: 30,
                            //                   width: 50,
                            //                   decoration: BoxDecoration(
                            //                     color: selectedindex == aSlotList[index]['id'] ? primaryColor : whiteColor,
                            //                     borderRadius: BorderRadius.circular(5.0),
                            //                     border: Border.all(color: primaryColor),
                            //                   ),
                            //                 ),
                            //               ),
                            //               Text(
                            //                 aSlotList[index]['name'],
                            //                 style: bold15LightBlack,
                            //               ),
                            //             ],
                            //           ),
                            //         ),
                            //         divider(),
                            //       ],
                            //     );
                            //   },
                            //
                            // )
                          ],
                        )),
                    // aSlotListContent(),
                    // entryLine(),
                    // bSlotListContent(),
                  ],
                ),
                exitText(),
                heightSpace,
              ],
            ),
          ),
          //+Button
          Container(
            width: double.maxFinite,
            padding: const EdgeInsets.only(left: fixPadding * 2.0, right: fixPadding * 2.0, bottom: fixPadding * 2.0, top: fixPadding),
            child: GestureDetector(
              onTap: () {
                // Navigator.pushNamed(context, '/paymentMethods');
                pageNavigator(context, PaymentMethodsScreen());
              },
              child: Container(
                width: double.maxFinite,
                padding: const EdgeInsets.all(fixPadding * 1.4),
                decoration: BoxDecoration(
                  color: primaryColor,
                  borderRadius: BorderRadius.circular(10.0),
                  boxShadow: [buttonShadow],
                ),
                alignment: Alignment.center,
                child: Consumer<BookingProvider>(
                  builder: (context, provider, child) {
                    return Text(
                      // getTranslation(context, 'select_slot.proceed_slot'),
                      "Proceed With ( ${bookingProvider.selectedNameForSlot} )",
                      style: bold18LightBlack,
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  exitText() {
    return Row(
      children: [
        Expanded(child: Container()),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: DottedBorder(
                  padding: EdgeInsets.zero,
                  dashPattern: const [2, 5],
                  color: const Color(0xFF757897),
                  child: Container(),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding / 2),
                clipBehavior: Clip.none,
                decoration: BoxDecoration(
                  color: const Color(0xFFF6E3B3),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                alignment: Alignment.center,
                child: Text(
                  getTranslation(context, 'select_slot.exit'),
                  style: bold12LightBlack,
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  entryLine() {
    return Expanded(
      flex: 1,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding / 2),
            decoration: BoxDecoration(
              color: const Color(0xFFF6E3B3),
              borderRadius: BorderRadius.circular(5.0),
            ),
            child: Text(
              getTranslation(context, 'select_slot.entry'),
              style: bold12LightBlack,
            ),
          ),
          heightSpace,
          Container(
            height: 14,
            width: 14,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: primaryColor,
                width: 4,
              ),
            ),
          ),
          DottedBorder(
            padding: EdgeInsets.zero,
            dashPattern: const [2, 4],
            color: const Color(0xFF757897),
            child: const SizedBox(
              height: 500,
              width: 0,
            ),
          )
        ],
      ),
    );
  }

  //! COMMENTED ORIGINAL
  /* bSlotListContent() {
    return Expanded(
        flex: 2,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFF6E3B3),
                borderRadius: BorderRadius.circular(4.0),
              ),
              child: Text(
                "B",
                style: bold16LightBlack,
              ),
            ),
            height5Space,
            heightSpace,
            divider(),
            ColumnBuilder(
                itemBuilder: (context, index) {
                  return Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: fixPadding),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              bSlotList[index]['name'],
                              style: bold15LightBlack,
                            ),
                            bSlotList[index]['AlreadyBooking'] == true
                                ? Image.asset(
                                    "assets/selectVehical/vehical1.png",
                                    height: 30,
                                    width: 50,
                                  )
                                : GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        selectedindex = bSlotList[index]['id'];
                                      });
                                    },
                                    child: Container(
                                      height: 30,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        color: selectedindex == bSlotList[index]['id'] ? primaryColor : whiteColor,
                                        borderRadius: BorderRadius.circular(5.0),
                                        border: Border.all(color: primaryColor),
                                      ),
                                    ),
                                  ),
                          ],
                        ),
                      ),
                      divider(),
                    ],
                  );
                },
                itemCount: bSlotList.length)
          ],
        ));
  }

  aSlotListContent() {
    return Expanded(
        flex: 2,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFF6E3B3),
                borderRadius: BorderRadius.circular(4.0),
              ),
              child: Text(
                "A",
                style: bold16LightBlack,
              ),
            ),
            height5Space,
            heightSpace,
            divider(),
            ColumnBuilder(
              itemCount: aSlotList.length,
              itemBuilder: (context, index) {
                return Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: fixPadding),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          aSlotList[index]['AlreadyBooking'] == true
                              ? Image.asset(
                                  "assets/selectVehical/vehical1.png",
                                  height: 30,
                                  width: 50,
                                )
                              : GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      selectedindex = aSlotList[index]['id'];
                                    });
                                  },
                                  child: Container(
                                    height: 30,
                                    width: 50,
                                    decoration: BoxDecoration(
                                      color: selectedindex == aSlotList[index]['id'] ? primaryColor : whiteColor,
                                      borderRadius: BorderRadius.circular(5.0),
                                      border: Border.all(color: primaryColor),
                                    ),
                                  ),
                                ),
                          Text(
                            aSlotList[index]['name'],
                            style: bold15LightBlack,
                          ),
                        ],
                      ),
                    ),
                    divider(),
                  ],
                );
              },
            )
          ],
        ));
  }
  */

  divider() {
    return DottedBorder(
      padding: EdgeInsets.zero,
      dashPattern: const [2, 4],
      color: const Color(0xFF757897),
      child: Container(),
    );
  }
}
