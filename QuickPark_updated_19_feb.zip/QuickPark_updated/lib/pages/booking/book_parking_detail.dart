import 'dart:developer';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/pages/booking/select_slot.dart';
import 'package:parkingproject/pages/paymentMethods/payment_methods.dart';
import 'package:parkingproject/provider/booking_provider.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:provider/provider.dart';

import '../../theme/theme.dart';

class BookParkingDetailScreen extends StatefulWidget {
  final ParkingModel? parkingModel;

  const BookParkingDetailScreen({super.key, this.parkingModel});

  @override
  State<BookParkingDetailScreen> createState() => _BookParkingDetailScreenState();
}

class _BookParkingDetailScreenState extends State<BookParkingDetailScreen> {
  //

  @override
  void initState() {
    final bookingProvider = Provider.of<BookingProvider>(context, listen: false);

    Future.delayed(Duration.zero, () {
      bookingProvider.startParkingTimeController.text = DateFormat.jm().format(DateTime.now());
      bookingProvider.endParkingTimeController.text = DateFormat.jm().format(DateTime.now());
      // bookingProvider.endParkingTimeController.text = DateFormat.jm().format(DateTime.now().add(Duration(hours: 3)));
      // bookingProvider.endParkingTime =  DateTime.now().add(Duration(hours: 3));
      // ! OLD
      // bookingProvider.startHourController.text = TimeOfDay.now().format(context);
      // bookingProvider.endHourController.text = TimeOfDay.fromDateTime(DateTime.now().add(const Duration(hours: 2))).format(context);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final bookingProvider = Provider.of<BookingProvider>(context, listen: false);
    log("format date is : ${DateFormat.jm().format(DateTime.now())}");
    log("Simple DateTime now : ${DateTime.now()}");

    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: scaffoldBgColor,
        titleSpacing: 0.0,
        shadowColor: shadowColor.withOpacity(0.25),
        foregroundColor: lightBlackColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
        title: Text(
          getTranslation(context, 'book_parking_detail.book_parking_detail'),
          style: bold18LightBlack,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: fixPadding * 2.0),
        physics: const BouncingScrollPhysics(),
        children: [
          selectStartDateTitle(),
          heightSpace,
          //+Start Parking Date
          Container(
            height: 258,
            width: double.maxFinite,
            padding: const EdgeInsets.only(bottom: fixPadding),
            margin: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0),
              color: whiteColor,
              boxShadow: [boxShadow],
            ),
            child: Theme(
              data: Theme.of(context).copyWith(
                textTheme: const TextTheme(
                  bodySmall: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                colorScheme: const ColorScheme.light(
                  primary: primaryColor,
                  onPrimary: blackColor,
                  onSurface: Color(0xFF4A5660),
                ),
              ),
              child: Consumer<BookingProvider>(
                builder: (context, provider, child) {
                  return CalendarDatePicker(
                    currentDate: bookingProvider.startParkingDateTime,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 3650)),
                    onDateChanged: (DateTime dateTime) {
                      bookingProvider.updateStartParkingDate(dateTime);
                      // !COMMENTING
                      /*
                      if (bookingProvider.endParkingDateTime.isBefore(dateTime)) {
                        Utils.errorToast("You cannot select starting date greater than ending date");
                      } else {
                        bookingProvider.updateStartParkingDate(dateTime);
                      }*/
                    },
                  );
                },
              ),
            ),
          ),
          heightSpace,
          heightSpace,
          selectEndDateTitle(),
          heightSpace,
          //+End Parking Date

          Container(
            height: 258,
            width: double.maxFinite,
            padding: const EdgeInsets.only(bottom: fixPadding),
            margin: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0),
              color: whiteColor,
              boxShadow: [boxShadow],
            ),
            child: Theme(
              data: Theme.of(context).copyWith(
                textTheme: const TextTheme(
                  bodySmall: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                colorScheme: const ColorScheme.light(
                  primary: primaryColor,
                  onPrimary: blackColor,
                  onSurface: Color(0xFF4A5660),
                ),
              ),
              child: Consumer<BookingProvider>(
                builder: (context, provider, child) {
                  return CalendarDatePicker(
                    currentDate: bookingProvider.endParkingDateTime,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 3650)),
                    onDateChanged: (DateTime dateTime) {
                      log("******************************");
                      log("bookingProvider.startParkingDateTime ${bookingProvider.startParkingDateTime}");
                      log("Selected Date                        $dateTime");
                      log("******************************");

                      bookingProvider.updateRoughEndDate(dateTime);
                      bookingProvider.updateEndParkingDate(dateTime);
                      //+COMMENTING TAKE CARE LATER
                      // if (dateTime.isBefore(bookingProvider.startParkingDateTime)) {
                      //   Utils.errorToast("You cannot select end date before start date");
                      // } else {
                      //   bookingProvider.updateEndParkingDate(dateTime);
                      // }

                      // if (dateTime.isBefore(bookingProvider.endParkingDateTime)) {
                      //   Utils.errorToast("Ending date must be after Start Date");
                      // } else {
                      // }

                      // bookingProvider.updatePrice(bookingProvider.calculatePrice(widget.parkingModel?.price ?? 1));
                    },
                  );
                },
              ),
            ),
          ),

          heightSpace,
          heightSpace,
          divider(),
          heightSpace,
          heightSpace,
          //+ Start Hour  &&   End Hour
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
            child: Row(
              children: [
                // timePickerField(context, bookingProvider.startHourController, getTranslation(context, 'book_parking_detail.start_hour')),
                //+Start Time Ha
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        getTranslation(context, 'book_parking_detail.start_hour'),
                        style: bold15LightBlack,
                      ),
                      heightSpace,
                      Container(
                        width: double.maxFinite,
                        decoration: BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.circular(5.0),
                          boxShadow: [boxShadow],
                        ),
                        child: Consumer<BookingProvider>(
                          builder: (context, provider, child) {
                            return TextField(
                              style: bold14Grey,
                              controller: bookingProvider.startParkingTimeController,
                              readOnly: true,
                              decoration: const InputDecoration(
                                contentPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding * 1.4),
                                border: InputBorder.none,
                                suffixIcon: Icon(
                                  Icons.access_time_rounded,
                                  color: greyColor,
                                  size: 19,
                                ),
                              ),
                              onTap: () async {
                                final TimeOfDay? timeOfDay = await showTimePicker(
                                  context: context,
                                  initialTime: TimeOfDay.now(),
                                  builder: (context, child) {
                                    return Theme(
                                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                                      child: child!,
                                    );
                                  },
                                );
                                if (timeOfDay != null && timeOfDay != bookingProvider.startParkingDateTime) {
                                  final now = DateTime.now();
                                  bool check = bookingProvider.endParkingDateTime.isBefore(DateTime(now.year, now.month, now.day, timeOfDay.hour, timeOfDay.minute));
                                  log("check value $check");
                                  if (check) {
                                    Utils.errorToast("Start time must be before end time");
                                  } else {
                                    bookingProvider.updateStartParkingTime(timeOfDay);
                                  }
                                }
                              },
                            );
                          },
                        ),
                      )
                    ],
                  ),
                ),

                widthSpace,
                widthSpace,
                // timePickerField(context, bookingProvider.endHourController, getTranslation(context, 'book_parking_detail.end_hour')),
                //+END TIME HA
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        getTranslation(context, 'book_parking_detail.end_hour'),
                        style: bold15LightBlack,
                      ),
                      heightSpace,
                      Container(
                        width: double.maxFinite,
                        decoration: BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.circular(5.0),
                          boxShadow: [boxShadow],
                        ),
                        child: Consumer<BookingProvider>(
                          builder: (context, provider, child) {
                            return TextField(
                              style: bold14Grey,
                              controller: bookingProvider.endParkingTimeController,
                              readOnly: true,
                              decoration: const InputDecoration(
                                contentPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding * 1.4),
                                border: InputBorder.none,
                                suffixIcon: Icon(
                                  Icons.access_time_rounded,
                                  color: greyColor,
                                  size: 19,
                                ),
                              ),
                              onTap: () async {
                                final timeOfDay = await showTimePicker(
                                  context: context,
                                  initialTime: TimeOfDay.now(),
                                  builder: (context, child) {
                                    return Theme(
                                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                                      child: child!,
                                    );
                                  },
                                );
                                if (timeOfDay != null) {
                                  bookingProvider.updateEndParkingTime(timeOfDay);
                                }
                              },
                            );
                          },
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
          heightSpace,
          heightSpace,

          //+LIVE START AND END TIME

          /*Column(
            // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Consumer<BookingProvider>(
                builder: (context, provider, child) {
                  return Text(
                    bookingProvider.startParkingDateTime.toString(),
                    style: bold16LightBlack,
                  );
                },
              ),
              Consumer<BookingProvider>(
                builder: (context, provider, child) {
                  return Text(
                    bookingProvider.endParkingDateTime.toString(),
                    style: bold16LightBlack,
                  );
                },
              ),
            ],
          ),*/
          //+Duration SLider
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                child: Text(
                  getTranslation(context, 'book_parking_detail.duration'),
                  style: bold16LightBlack,
                ),
              ),
              heightSpace,
              heightSpace,
              Consumer<BookingProvider>(
                builder: (context, provider, child) {
                  log("duraton text value : ${bookingProvider.calculatedDuration}");
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                    child: Text(
                      // getTranslation(context, 'book_parking_detail.select_date'),
                      // bookingProvider.calculatedDuration,

                      bookingProvider.finalParkingDuration.inMinutes < 60
                          ? "${bookingProvider.finalParkingDuration.inMinutes} Minutes"
                          : bookingProvider.finalParkingDuration.inHours < 24
                              ? "${bookingProvider.finalParkingDuration.inHours} Hours"
                              : bookingProvider.finalParkingDuration.inDays == 1
                                  ? "${bookingProvider.finalParkingDuration.inDays} Day"
                                  : "${bookingProvider.finalParkingDuration.inDays} Days",

                      style: bold16LightBlack,
                    ),
                  );
                },
              ),
              heightSpace,
              height5Space,

              //+Slider Commenting
              // SfSliderTheme(
              //   data: SfSliderThemeData(
              //     thumbStrokeWidth: 1.5,
              //     thumbStrokeColor: whiteColor,
              //     tooltipBackgroundColor: primaryColor,
              //     tooltipTextStyle: bold14LightBlack,
              //   ),
              //   child: Consumer<BookingProvider>(
              //     builder: (context, provider, child) {
              //       return SfSlider(
              //         min: 0.0,
              //         max: 10.0,
              //         enableTooltip: true,
              //         activeColor: primaryColor,
              //         inactiveColor: const Color(0xFFE6E6E6),
              //         tooltipTextFormatterCallback: (dynamic actualValue, String formattedText) {
              //           return "${bookingProvider.durationHour.toInt()} ${getTranslation(context, 'confirmation.hours')}";
              //         },
              //         shouldAlwaysShowTooltip: true,
              //         interval: 1.0,
              //         onChanged: (value) {
              //           bookingProvider.changeDurationValue(value);
              //           bookingProvider.calculatePrice(widget.parkingModel?.price ?? 1);
              //           bookingProvider.updatePrice(bookingProvider.calculatePrice(widget.parkingModel?.price ?? 1));
              //
              //           log("Duration Hour : ${bookingProvider.durationHour.toInt()}");
              //         },
              //         value: bookingProvider.durationHour,
              //       );
              //     },
              //   ),
              // ),
            ],
          ),

          /*  startEndField(context),*/
          heightSpace,
          heightSpace,
          divider(),
          heightSpace,
          heightSpace,
          priceWidget(
            getTranslation(context, 'book_parking_detail.price'),
            "\$ ${widget.parkingModel?.priceHourly ?? 0}",
            "1 ${getTranslation(context, 'book_parking_detail.hours')}",
          ),
          heightSpace,
          height5Space,
          Consumer<BookingProvider>(
            builder: (context, provider, child) {
              return priceWidget(
                getTranslation(context, 'book_parking_detail.total_price'),
                "\$${provider.calculatedParkingPrice} ",
                " ${bookingProvider.finalParkingDuration.inHours} ${getTranslation(context, 'book_parking_detail.hours')}",
              );
            },
          ),
          heightSpace,
          heightSpace,
          heightSpace,
          heightSpace,
          continueButton(),
        ],
      ),
    );
  }

  continueButton() {
    return GestureDetector(
      onTap: () {
        final bookingProvider = Provider.of<BookingProvider>(context, listen: false);
        Duration duration = bookingProvider.endParkingDateTime.difference(bookingProvider.startParkingDateTime);

        log(" isBefore checking:   ${bookingProvider.roughEndDate.isBefore(bookingProvider.startParkingDateTime)}  ");

        /*if (bookingProvider.roughEndDate.isBefore(bookingProvider.startParkingDateTime)) {
          Utils.errorToast("You cannot select end date before start date");
        } else {
          if (bookingProvider.endParkingDateTime.isBefore(bookingProvider.startParkingDateTime)) {
            Utils.errorToast("You cannot select starting date greater than ending date");
          } else {
            log("inside else part");
            // pageNavigator(context, SelectSlotScreen());
          }
        }*/
        //+NOW FINAL HERE
        // if (bookingProvider.startParkingDateTime.isAtSameMomentAs(bookingProvider.endParkingDateTime)) {
        //   Utils.errorToast("Please select parking start and end date time.");
        // } else if (bookingProvider.startParkingDateTime.compareTo(bookingProvider.endParkingDateTime) == 0) {
        //   Utils.errorToast("Please select parking start and end date time.");
        // }
        // else

        // if (bookingProvider.startParkingDateTime == bookingProvider.endParkingDateTime) {
        //   Utils.errorToast("Please select parking start and end date time.");
        // }
        if (bookingProvider.startParkingDateTime.isAfter(bookingProvider.endParkingDateTime)) {
          Utils.errorToast("You cannot select start date after end date");
        } else if (bookingProvider.endParkingDateTime.isBefore(bookingProvider.startParkingDateTime)) {
          Utils.errorToast("You cannot select end date before start date");
        } else if (duration.inMinutes < 30) {
          Utils.errorToast("Please select parking time greater than 30 minutes");
        } else {
          pageNavigator(context, PaymentMethodsScreen());

          // pageNavigator(context, SelectSlotScreen(parkingModel: widget.parkingModel));
        }
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
        width: double.maxFinite,
        padding: const EdgeInsets.all(fixPadding * 1.4),
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [buttonShadow],
        ),
        alignment: Alignment.center,
        child: Text(
          getTranslation(context, 'book_parking_detail.continue'),
          style: bold18LightBlack,
        ),
      ),
    );
  }

  priceWidget(title, price, time) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: bold16LightBlack,
            ),
          ),
          Row(
            children: [Text(price, style: bold18TextColor), Text("/", style: bold14LightBlack), Text(time, style: semibold12LightBlack)],
          )
        ],
      ),
    );
  }

  startEndField(BuildContext context) {
    final bookingProvider = Provider.of<BookingProvider>(context, listen: false);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
      child: Row(
        children: [
          // timePickerField(context, bookingProvider.startHourController, getTranslation(context, 'book_parking_detail.start_hour')),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  getTranslation(context, 'book_parking_detail.start_hour'),
                  style: bold15LightBlack,
                ),
                heightSpace,
                Container(
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.circular(5.0),
                    boxShadow: [boxShadow],
                  ),
                  child: Consumer<BookingProvider>(
                    builder: (context, provider, child) {
                      return TextField(
                        onTap: () async {
                          final pickedTime = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.now(),
                            builder: (context, child) {
                              return Theme(
                                data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                                child: child!,
                              );
                            },
                          );
                          if (pickedTime != null) {
                            log("picked time $pickedTime");
                            bookingProvider.updateStartHourTime(pickedTime.format(context));

                            log("type is ${pickedTime.format(context).runtimeType}");
                          }
                        },
                        style: bold14Grey,
                        controller: bookingProvider.startParkingTimeController,
                        readOnly: true,
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding * 1.4),
                          border: InputBorder.none,
                          suffixIcon: Icon(
                            Icons.access_time_rounded,
                            color: greyColor,
                            size: 19,
                          ),
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),

          widthSpace,
          widthSpace,
          // timePickerField(context, bookingProvider.endHourController, getTranslation(context, 'book_parking_detail.end_hour')),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  getTranslation(context, 'book_parking_detail.end_hour'),
                  style: bold15LightBlack,
                ),
                heightSpace,
                Container(
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.circular(5.0),
                    boxShadow: [boxShadow],
                  ),
                  child: TextField(
                    onTap: () async {
                      final pickedTime = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.now(),
                        builder: (context, child) {
                          return Theme(
                            data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                            child: child!,
                          );
                        },
                      );
                      if (pickedTime != null) {
                        setState(() {
                          bookingProvider.endParkingTimeController.text = pickedTime.format(context);
                        });
                      }
                    },
                    style: bold14Grey,
                    controller: bookingProvider.endParkingTimeController,
                    readOnly: true,
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding * 1.4),
                      border: InputBorder.none,
                      suffixIcon: Icon(
                        Icons.access_time_rounded,
                        color: greyColor,
                        size: 19,
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

/*
  timePickerField(BuildContext context, controller, title) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: bold15LightBlack,
          ),
          heightSpace,
          Container(
            width: double.maxFinite,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(5.0),
              boxShadow: [boxShadow],
            ),
            child: TextField(
              onTap: () async {
                final pickedTime = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                  builder: (context, child) {
                    return Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: child!,
                    );
                  },
                );
                if (pickedTime != null) {


                  setState(() {
                    controller.text = pickedTime.format(context);
                  });
                }
              },
              style: bold14Grey,
              controller: controller,
              readOnly: true,
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding * 1.4),
                border: InputBorder.none,
                suffixIcon: Icon(
                  Icons.access_time_rounded,
                  color: greyColor,
                  size: 19,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }*/

  divider() {
    return DottedBorder(
      padding: EdgeInsets.zero,
      color: greyColor,
      dashPattern: const [2, 5],
      child: Container(),
    );
  }

  selectStartDateTitle() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
      child: Text(
        // getTranslation(context, 'book_parking_detail.select_date'),
        "Select Start Date",
        style: bold16LightBlack,
      ),
    );
  }

  selectEndDateTitle() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
      child: Text(
        "Select End Date",
        style: bold16LightBlack,
      ),
    );
  }
}
