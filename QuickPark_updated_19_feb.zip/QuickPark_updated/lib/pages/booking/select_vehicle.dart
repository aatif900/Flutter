import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/add_vehicle_model.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/pages/addVehicle/add_vehicle.dart';
import 'package:parkingproject/pages/booking/book_parking_detail.dart';
import 'package:parkingproject/provider/booking_provider.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:provider/provider.dart';

import '../../theme/theme.dart';

class SelectVehicleScreen extends StatefulWidget {
  final ParkingModel? parkingModel;

  const SelectVehicleScreen({super.key, required this.parkingModel});

  @override
  State<SelectVehicleScreen> createState() => _SelectVehicleScreenState();
}

class _SelectVehicleScreenState extends State<SelectVehicleScreen> {
  BookingProvider? bookingProvider;

  @override
  void initState() {
    bookingProvider = Provider.of<BookingProvider>(context, listen: false);
    super.initState();
  }

  @override
  void dispose() {
    bookingProvider?.selectedIndex = null;
    bookingProvider?.selectedVehicleModel = null;
    log("After disposing value is : ${bookingProvider?.selectedIndex}");
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bookingProvider = Provider.of<BookingProvider>(context, listen: false);
    final size = MediaQuery.sizeOf(context);

    log("bookingProvider.selectedIndex ${bookingProvider.selectedIndex}");
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: scaffoldBgColor,
        titleSpacing: 0.0,
        shadowColor: shadowColor.withOpacity(0.25),
        foregroundColor: lightBlackColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
        title: Text(
          getTranslation(context, 'select_vehicle.select_vehicle'),
          style: bold18LightBlack,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: fixPadding, bottom: fixPadding * 2.0),
        children: [
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).collection(collectionVehicles).snapshots(),
            builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return loading();
              } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
                if (snapshot.hasError) {
                  return const Text('Error');
                } else if (snapshot.hasData) {
                  log("snapshot hasData and length :  ${snapshot.data!.docs.length}");
                  if (snapshot.data!.docs.isNotEmpty) {
                    return SizedBox(
                      height: MediaQuery.sizeOf(context).height - 280,
                      child: ListView.builder(
                        itemCount: snapshot.data!.docs.length,
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(15, 15, 15, 100),
                        itemBuilder: (context, index) {
                          DocumentSnapshot documentSnapShot = snapshot.data!.docs[index];
                          VehicleModel vehicleModel = VehicleModel.fromJson(documentSnapShot.data() as Map<String, dynamic>);
                          String documentId = snapshot.data!.docs[index].id;
                          log(" vehicleModel.vehicleName  ${vehicleModel.vehicleType}");
                          return Slidable(
                            key: UniqueKey(),
                            endActionPane: ActionPane(
                              motion: const ScrollMotion(),
                              extentRatio: 0.14,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).collection(collectionVehicles).doc(documentId).delete();
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        backgroundColor: blackColor,
                                        duration: const Duration(milliseconds: 1500),
                                        behavior: SnackBarBehavior.floating,
                                        content: Text(
                                          "Deleted Successfully !",
                                          style: bold15White,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(vertical: fixPadding),
                                    width: size.width * 0.10,
                                    decoration: BoxDecoration(
                                      color: redColor,
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                    alignment: Alignment.center,
                                    child: const Icon(
                                      CupertinoIcons.trash_fill,
                                      color: whiteColor,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            child: GestureDetector(
                              onTap: () {
                                bookingProvider.selectVehicle(index, vehicleModel);
                              },
                              child: Container(
                                width: double.maxFinite,
                                padding: const EdgeInsets.symmetric(vertical: fixPadding, horizontal: fixPadding * 1.5),
                                margin: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding),
                                decoration: BoxDecoration(
                                  color: whiteColor,
                                  boxShadow: [boxShadow],
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Row(
                                  children: [
                                    Image.asset(
                                      "assets/selectVehical/vehical1.png",
                                      height: 30,
                                    ),
                                    widthSpace,
                                    width5Space,
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            vehicleModel.vehicleType.toString(),
                                            style: bold15LightBlack,
                                          ),
                                          height5Space,
                                          Text(
                                            vehicleModel.vehicleLicencePlate.toString(),
                                            style: semibold14Grey,
                                          )
                                        ],
                                      ),
                                    ),
                                    Consumer<BookingProvider>(
                                      builder: (context, provider, child) {
                                        return Container(
                                          height: 22,
                                          width: 22,
                                          decoration: BoxDecoration(
                                            color: whiteColor,
                                            shape: BoxShape.circle,
                                            boxShadow: [boxShadow],
                                            border: bookingProvider.selectedIndex == index ? Border.all(color: primaryColor, width: 7) : null,
                                          ),
                                        );
                                      },
                                    )
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  } else {
                    return Center(
                      child: Text(
                        'No Vehicles',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: bold18LightBlack,
                      ),
                    );
                  }
                } else {
                  return Container();
                }
              } else {
                log("in last else of ConnectionState.done and: ${snapshot.connectionState}");
                return Container();
              }
            },
          ),
          heightSpace,
          heightSpace,
          heightSpace,
          GestureDetector(
            onTap: () {
              pageNavigator(context, const AddVehicleScreen());
            },
            child: Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(fixPadding * 1.4),
              margin: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    blurRadius: 6,
                    color: shadowColor.withOpacity(0.1),
                  ),
                  buttonShadow,
                ],
              ),
              alignment: Alignment.center,
              child: Text(
                getTranslation(context, 'select_vehicle.add_vehicle'),
                style: bold18TextColor,
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          width: double.maxFinite,
          padding: const EdgeInsets.all(fixPadding * 2.0),
          child: GestureDetector(
            onTap: () {
              log("Button pressed");
              final bookingProvider = Provider.of<BookingProvider>(context, listen: false);
              log("model value ${bookingProvider.selectedVehicleModel?.toJson()}");

              if (bookingProvider.selectedVehicleModel == null) {
                Utils.errorToast("Please select a vehicle");
              } else {
                pageNavigator(context, BookParkingDetailScreen(parkingModel: widget.parkingModel));
              }
            },
            child: Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(fixPadding * 1.4),
              decoration: BoxDecoration(
                color: primaryColor,
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [buttonShadow],
              ),
              child: Text(
                getTranslation(context, 'select_vehicle.continue'),
                style: bold18LightBlack,
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
