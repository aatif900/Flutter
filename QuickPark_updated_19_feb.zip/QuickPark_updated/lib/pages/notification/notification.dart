import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';
import 'package:intl/intl.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/notification_model.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/loading_dialog.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  //

  ScrollController scrollController = ScrollController();
  List<String> monthsList = [
    'january',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  // GroupedItemScrollController groupedItemScrollController = GroupedItemScrollController();
  // ItemPositionsListener itemPositionsListener = ItemPositionsListener.create();
  final List todayList = [
    {"title": "Payment successful", "description": "Your payment \$50 successfully paid", "time": "10.30am", "type": "Payment Success"},
    {"title": "Parking booking canceled", "description": "Your DCM parking booking payment failed.", "time": "11.30am", "type": "Booking Cancel"},
  ];

  final List yesterdayList = [
    {"title": "Parking booking success", "description": "Your payment \$50 successfully paid", "time": "09.30am", "type": "Parking Booking"},
    {"title": "Payment successful", "description": "Your payment \$50 successfully paid", "time": "11.30am", "type": "Payment Success"},
    {"title": "Parking booking success", "description": "Your payment \$50 successfully paid", "time": "10.00am", "type": "Parking Booking"},
    {"title": "Parking booking canceled", "description": "Your DCM parking booking payment failed.", "time": "10.30am", "type": "Booking Cancel"}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: scaffoldBgColor,
        titleSpacing: 0.0,
        shadowColor: shadowColor.withOpacity(0.25),
        foregroundColor: lightBlackColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
        title: Text(
          getTranslation(context, 'notification.notification'),
          style: bold18LightBlack,
        ),
      ),
    

      // (todayList.isEmpty && yesterdayList.isEmpty) ? emptyListContent(context) : notificationListContent(),
    );
  }

  emptyListContent(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            "assets/notification/no_notificationn.png",
            height: 40,
            width: 40,
            color: greyColor,
          ),
          heightSpace,
          height5Space,
          Text(
            getTranslation(context, 'notification.no_notification'),
            style: bold16Grey,
          )
        ],
      ),
    );
  }

  paymentSuccessIcon() {
    return Container(
      height: 47,
      width: 47,
      padding: const EdgeInsets.all(fixPadding / 2),
      decoration: const BoxDecoration(
        color: Color(0xFFB7EBB2),
        shape: BoxShape.circle,
      ),
      child: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF71BD6A),
          shape: BoxShape.circle,
        ),
        child: const Icon(
          Icons.done,
          color: whiteColor,
          size: 22,
        ),
      ),
    );
  }

  parkingBookingIcon() {
    return Container(
      height: 47,
      width: 47,
      padding: const EdgeInsets.all(fixPadding / 2),
      decoration: const BoxDecoration(
        color: Color(0xFFF4E5CF),
        shape: BoxShape.circle,
      ),
      child: Container(
        decoration: const BoxDecoration(
          color: textColor,
          shape: BoxShape.circle,
        ),
        child: const Icon(
          Icons.local_parking,
          color: whiteColor,
          size: 22,
        ),
      ),
    );
  }

  bookingCancelIcon() {
    return Container(
      height: 47,
      width: 47,
      padding: const EdgeInsets.all(fixPadding / 2),
      decoration: const BoxDecoration(
        color: Color(0xFFFFDFE5),
        shape: BoxShape.circle,
      ),
      child: Container(
        decoration: const BoxDecoration(
          color: Color(0xFFEF8989),
          shape: BoxShape.circle,
        ),
        child: const Icon(
          Icons.close,
          color: whiteColor,
          size: 22,
        ),
      ),
    );
  }
}

class NotificationTiles extends StatelessWidget {
  final String? documentId;
  final NotificationModel? notificationModel;

  const NotificationTiles({super.key, this.documentId, this.notificationModel});

  paymentSuccessIcon() {
    return Container(
      height: 47,
      width: 47,
      padding: const EdgeInsets.all(fixPadding / 2),
      decoration: const BoxDecoration(
        color: Color(0xFFB7EBB2),
        shape: BoxShape.circle,
      ),
      child: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF71BD6A),
          shape: BoxShape.circle,
        ),
        child: const Icon(
          Icons.done,
          color: whiteColor,
          size: 22,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        /* Padding(
          padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
          child: Text(
            getTranslation(context, 'notification.today'),
            style: bold16LightBlack,
          ),
        ),*/
        height5Space,
        Dismissible(
          key: UniqueKey(),
          onDismissed: (direction) {
            /*  setState(() {
                  listname.removeAt(index);
                });*/
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                backgroundColor: blackColor,
                duration: const Duration(milliseconds: 1500),
                behavior: SnackBarBehavior.floating,
                content: Text(
                  getTranslation(context, 'notification.removed_notification'),
                  style: bold15White,
                ),
              ),
            );
          },
          background: Container(
            margin: const EdgeInsets.symmetric(vertical: fixPadding),
            color: redColor,
          ),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 6.0, horizontal: fixPadding),
            margin: const EdgeInsets.symmetric(vertical: fixPadding, horizontal: fixPadding * 2.0),
            width: double.maxFinite,
            decoration: BoxDecoration(
              color: whiteColor,
              boxShadow: [boxShadow],
              borderRadius: BorderRadius.circular(10.0),
            ),
            child: Row(
              children: [
                paymentSuccessIcon(),
                /*  if (listname[index]['type'] == "Payment Success") ,
                    if (listname[index]['type'] == "Booking Cancel") bookingCancelIcon(),
                    if (listname[index]['type'] == "Parking Booking") parkingBookingIcon(),*/
                widthSpace,
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        notificationModel?.title ?? "",
                        style: bold16LightBlack,
                      ),
                      height5Space,
                      Text(
                        notificationModel?.description ?? "",
                        style: bold14Grey,
                      ),
                      height5Space,
                      Text(
                        DateFormat.jm().format(DateTime.fromMillisecondsSinceEpoch(notificationModel?.createdAt ?? DateTime.now().millisecondsSinceEpoch)),
                        style: bold12Grey,
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
        // heightSpace,
      ],
    );
  }
}
