import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:provider/provider.dart';

class BookMarkScreen extends StatefulWidget {
  const BookMarkScreen({super.key});

  @override
  State<BookMarkScreen> createState() => _BookMarkScreenState();
}

class _BookMarkScreenState extends State<BookMarkScreen> {
  final bookmarkList = [
    {
      "image": "assets/myBooking/image1.png",
      "parkingName": "Hapton holies parking",
      "adress": "1024 Botanic garden road,new york",
      "price": "\$3",
      "distance": 3,
      "slot": 25,
      "rate": 2.5,
    },
    {
      "image": "assets/myBooking/image6.png",
      "parkingName": "DMC parking spot",
      "adress": "1024 Botanic garden road,new york",
      "price": "\$15",
      "distance": 4,
      "slot": 15,
      "rate": 3.5,
    },
    {
      "image": "assets/myBooking/image2.png",
      "parkingName": "Leed parking space",
      "adress": "1024 Botanic garden road,new york",
      "price": "\$3",
      "distance": 10,
      "slot": 30,
      "rate": 4.5,
    },
    {
      "image": "assets/myBooking/image4.png",
      "parkingName": "EME temple parking",
      "adress": "1024 Botanic garden road,new york",
      "price": "\$2",
      "distance": 12,
      "slot": 10,
      "rate": 2.5,
    },
    {
      "image": "assets/myBooking/image1.png",
      "parkingName": "Parking dowuntoen",
      "adress": "1024 Botanic garden road,new york",
      "price": "\$5",
      "distance": 10,
      "slot": 25,
      "rate": 5.0,
    }
  ];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: scaffoldBgColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: scaffoldBgColor,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          getTranslation(context, 'bookmark.my_bookmark'),
          style: bold20LightBlack,
        ),
      ),
      body: bookmarkList.isEmpty ? emptyListContent() : bookmarkListContent(size),
    );
  }

  emptyListContent() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            "assets/bookmark/empty-bookmark.png",
            height: 35,
            width: 35,
          ),
          heightSpace,
          Text(
            getTranslation(context, 'bookmark.no_bookmark_here'),
            style: bold16Grey,
          )
        ],
      ),
    );
  }

  bookmarkListContent(Size size) {
    final AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
    log("authProvider.userModel.uid ${authProvider.userModel.uid}");
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: ffstore.collection(collectionUsers).doc(authProvider.userModel.uid).collection(collectionFavourite).snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: const CircularProgressIndicator());
        } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasError) {
            return const Text('Error');
          } else if (snapshot.hasData && snapshot.data != null) {
            log("snapshot.hasData ${snapshot.hasData}");
            log("snapshot.data!.docs.length ${snapshot.data!.docs.length}");

            if (snapshot.data!.docs.isNotEmpty) {
              return ListView.builder(
                padding: const EdgeInsets.only(bottom: fixPadding),
                physics: const BouncingScrollPhysics(),
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (context, index) {
                  ParkingModel parkingModel = ParkingModel.fromJson(snapshot.data!.docs[index].data() as Map<String, dynamic>);
                  // log("parkingModel .toJson ${parkingModel.toJson()}");
                  return Slidable(
                    key: UniqueKey(),
                    endActionPane: ActionPane(
                      motion: const ScrollMotion(),
                      extentRatio: 0.14,
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              bookmarkList.removeAt(index);
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                backgroundColor: blackColor,
                                duration: const Duration(milliseconds: 1500),
                                behavior: SnackBarBehavior.floating,
                                content: Text(
                                  getTranslation(context, 'bookmark.removed_from_bookmark'),
                                  style: bold15White,
                                ),
                              ),
                            );
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: fixPadding),
                            width: size.width * 0.14,
                            decoration: BoxDecoration(
                              color: redColor,
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            alignment: Alignment.center,
                            child: const Icon(
                              CupertinoIcons.trash_fill,
                              color: whiteColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, '/detail');
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: fixPadding),
                        margin: const EdgeInsets.symmetric(horizontal: fixPadding * 2, vertical: fixPadding),
                        decoration: BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.circular(10.0),
                          boxShadow: [buttonShadow],
                        ),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                              child: Row(
                                children: [
                                  Container(
                                    height: size.width * 0.2,
                                    width: size.width * 0.2,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5.0),
                                      boxShadow: [boxShadow],
                                      image: DecorationImage(
                                        image: NetworkImage(parkingModel.image.toString()),
                                        fit: BoxFit.cover,
                                      ),
                                      // image: DecorationImage(
                                      //   image: AssetImage(
                                      //     bookmarkList[index]['image'].toString(),
                                      //   ),
                                      //   fit: BoxFit.cover,
                                      // ),
                                    ),
                                    alignment: Alignment.bottomRight,
                                    child: Container(
                                      padding: const EdgeInsets.all(3.0),
                                      decoration: const BoxDecoration(
                                        color: whiteColor,
                                        borderRadius: BorderRadius.only(
                                          bottomRight: Radius.circular(5.0),
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Icon(
                                            Icons.star,
                                            color: textColor,
                                            size: 16,
                                          ),
                                          widthBox(3.0),
                                          Text(
                                            bookmarkList[index]['rate'].toString(),
                                            style: semibold14LightBlack,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  widthSpace,
                                  width5Space,
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          bookmarkList[index]['parkingName'].toString(),
                                          style: semibold18LightBlack,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        heightBox(3.0),
                                        Text(
                                          bookmarkList[index]['adress'].toString(),
                                          style: semibold14Grey,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        heightBox(3.0),
                                        Text.rich(
                                          TextSpan(
                                            text: "${bookmarkList[index]['price']}/",
                                            style: semibold16LightBlack,
                                            children: [
                                              TextSpan(
                                                text: getTranslation(context, 'bookmark.per_hour'),
                                                style: semibold15Grey,
                                              )
                                            ],
                                          ),
                                          style: semibold14Grey,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                            heightSpace,
                            DottedBorder(
                              padding: EdgeInsets.zero,
                              color: greyD4Color,
                              dashPattern: const [3],
                              child: Container(),
                            ),
                            heightSpace,
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text.rich(
                                          TextSpan(text: "${getTranslation(context, 'bookmark.distance_value')} : ", style: medium14LightBlack, children: [
                                            TextSpan(
                                                text: "${bookmarkList[index]['distance']} ${getTranslation(context, 'bookmark.min_walk')}", style: semibold14LightBlack)
                                          ]),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        Text.rich(
                                          TextSpan(text: "${getTranslation(context, "bookmark.slot_available")} : ", style: medium14LightBlack, children: [
                                            TextSpan(
                                              text: "${bookmarkList[index]['slot']} ${getTranslation(context, 'bookmark.slot')}".toString(),
                                              style: semibold14LightBlack,
                                            )
                                          ]),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  ),
                                  width5Space,
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.pushNamed(context, '/detail');
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: fixPadding, horizontal: fixPadding * 1.8),
                                      decoration: BoxDecoration(
                                        color: primaryColor,
                                        borderRadius: BorderRadius.circular(5.0),
                                        boxShadow: [buttonShadow],
                                      ),
                                      child: Text(
                                        getTranslation(context, 'bookmark.book_now'),
                                        style: bold16LightBlack,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            } else {
              return emptyListContent();
            }
          } else {
            return Center(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      "assets/bookmark/empty-bookmark.png",
                      height: 35,
                      width: 35,
                    ),
                    heightSpace,
                    Text(
                      getTranslation(context, 'bookmark.no_bookmark_here'),
                      style: bold16Grey,
                    )
                  ],
                ),
              ),
            );
          }
        } else {
          return Text('State: ${snapshot.connectionState}');
        }
      },
    );
  }

  bookMarkListContent(Size size) {
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: fixPadding),
      physics: const BouncingScrollPhysics(),
      itemCount: bookmarkList.length,
      itemBuilder: (context, index) {
        return Slidable(
          key: UniqueKey(),
          endActionPane: ActionPane(
            motion: const ScrollMotion(),
            extentRatio: 0.14,
            children: [
              GestureDetector(
                onTap: () {
                  setState(() {
                    bookmarkList.removeAt(index);
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      backgroundColor: blackColor,
                      duration: const Duration(milliseconds: 1500),
                      behavior: SnackBarBehavior.floating,
                      content: Text(
                        getTranslation(context, 'bookmark.removed_from_bookmark'),
                        style: bold15White,
                      ),
                    ),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: fixPadding),
                  width: size.width * 0.14,
                  decoration: BoxDecoration(
                    color: redColor,
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  alignment: Alignment.center,
                  child: const Icon(
                    CupertinoIcons.trash_fill,
                    color: whiteColor,
                  ),
                ),
              ),
            ],
          ),
          child: GestureDetector(
            onTap: () {
              Navigator.pushNamed(context, '/detail');
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: fixPadding),
              margin: const EdgeInsets.symmetric(horizontal: fixPadding * 2, vertical: fixPadding),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [buttonShadow],
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                    child: Row(
                      children: [
                        Container(
                          height: size.width * 0.2,
                          width: size.width * 0.2,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            boxShadow: [boxShadow],
                            image: DecorationImage(
                              image: AssetImage(
                                bookmarkList[index]['image'].toString(),
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                          alignment: Alignment.bottomRight,
                          child: Container(
                            padding: const EdgeInsets.all(3.0),
                            decoration: const BoxDecoration(
                              color: whiteColor,
                              borderRadius: BorderRadius.only(
                                bottomRight: Radius.circular(5.0),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.star,
                                  color: textColor,
                                  size: 16,
                                ),
                                widthBox(3.0),
                                Text(
                                  bookmarkList[index]['rate'].toString(),
                                  style: semibold14LightBlack,
                                ),
                              ],
                            ),
                          ),
                        ),
                        widthSpace,
                        width5Space,
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                bookmarkList[index]['parkingName'].toString(),
                                style: semibold18LightBlack,
                                overflow: TextOverflow.ellipsis,
                              ),
                              heightBox(3.0),
                              Text(
                                bookmarkList[index]['adress'].toString(),
                                style: semibold14Grey,
                                overflow: TextOverflow.ellipsis,
                              ),
                              heightBox(3.0),
                              Text.rich(
                                TextSpan(
                                  text: "${bookmarkList[index]['price']}/",
                                  style: semibold16LightBlack,
                                  children: [
                                    TextSpan(
                                      text: getTranslation(context, 'bookmark.per_hour'),
                                      style: semibold15Grey,
                                    )
                                  ],
                                ),
                                style: semibold14Grey,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  heightSpace,
                  DottedBorder(
                    padding: EdgeInsets.zero,
                    color: greyD4Color,
                    dashPattern: const [3],
                    child: Container(),
                  ),
                  heightSpace,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text.rich(
                                TextSpan(text: "${getTranslation(context, 'bookmark.distance_value')} : ", style: medium14LightBlack, children: [
                                  TextSpan(text: "${bookmarkList[index]['distance']} ${getTranslation(context, 'bookmark.min_walk')}", style: semibold14LightBlack)
                                ]),
                                overflow: TextOverflow.ellipsis,
                              ),
                              Text.rich(
                                TextSpan(text: "${getTranslation(context, "bookmark.slot_available")} : ", style: medium14LightBlack, children: [
                                  TextSpan(
                                    text: "${bookmarkList[index]['slot']} ${getTranslation(context, 'bookmark.slot')}".toString(),
                                    style: semibold14LightBlack,
                                  )
                                ]),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        width5Space,
                        GestureDetector(
                          onTap: () {
                            Navigator.pushNamed(context, '/detail');
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: fixPadding, horizontal: fixPadding * 1.8),
                            decoration: BoxDecoration(
                              color: primaryColor,
                              borderRadius: BorderRadius.circular(5.0),
                              boxShadow: [buttonShadow],
                            ),
                            child: Text(
                              getTranslation(context, 'bookmark.book_now'),
                              style: bold16LightBlack,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
