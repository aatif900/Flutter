// ignore_for_file: avoid_print

import 'dart:developer';
import 'dart:io';

import 'package:country_picker/country_picker.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:multi_select_flutter/dialog/multi_select_dialog_field.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/generated/assets.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/pages/auth/complete_profile_page.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/provider/parking_provider.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:parkingproject/widget/column_builder.dart';
import 'package:parkingproject/widget/common_image_view.dart';
import 'package:parkingproject/widget/my_drop_down_form_field.dart';
import 'package:parkingproject/widget/select_image_bottom_sheet.dart';
import 'package:provider/provider.dart';

import '../../theme/theme.dart';
import '../profile/languages.dart';

class Animal {
  final int? id;
  final String? name;

  Animal({
    this.id,
    this.name,
  });
}

class OfferParkingScreen extends StatefulWidget {
  const OfferParkingScreen({super.key});

  @override
  State<OfferParkingScreen> createState() => _OfferParkingScreenState();
}

class _OfferParkingScreenState extends State<OfferParkingScreen> {
  final _formKey = GlobalKey<FormState>();
  static final List<Animal> _animals = [
    Animal(id: 1, name: "Motorcycle"),
    Animal(id: 2, name: "Car"),
    Animal(id: 3, name: "SUV"),
    Animal(id: 5, name: "Camper"),
  ];

  static final List<String> vehicleTypeList = [
    "Motorcycle",
    "Car",
    "SUV",
    "Camper",
  ];

  final _items = vehicleTypeList.map((animal) => MultiSelectItem<String>(animal, animal)).toList();

  @override
  Widget build(BuildContext context) {
    ParkingProvider parkingProvider = Provider.of<ParkingProvider>(context, listen: false);
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: scaffoldBgColor,
        titleSpacing: 0.0,
        shadowColor: shadowColor.withOpacity(0.25),
        foregroundColor: lightBlackColor,
        title: Text(
          "Add New Parking",
          style: bold18LightBlack,
        ),
      ),
      body: Column(
        children: [
          // topCarImage(size),
          Expanded(
            child: Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(fixPadding * 2.0),
                physics: const BouncingScrollPhysics(),
                children: [
                  heightSpace,
                  heightSpace,
                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        controller: parkingProvider.titleController,
                        keyboardType: TextInputType.name,
                        validator: (val) {},
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,

                            // hintText: getTranslation(context, 'register.user_name'),
                            hintText: "Parking Name",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),
                  heightSpace,

                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        maxLines: 3,
                        cursorColor: primaryColor,
                        controller: parkingProvider.descriptionController,
                        keyboardType: TextInputType.name,
                        validator: (val) {},
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            hintText: "Description",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),
                  heightSpace,

                  Container(
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: MultiSelectDialogField(
                      items: _items,
                      title: Text("Vehicle Types"),
                      selectedColor: Colors.black,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(0)),
                        border: Border.all(
                          color: Colors.white,
                          width: 2,
                        ),
                      ),
                      buttonIcon: Icon(
                        Icons.arrow_circle_up_sharp,
                        color: Colors.black,
                      ),
                      buttonText: Text(
                        "Vehicle Types",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                        ),
                      ),
                      onConfirm: (results) {
                        setState(() {
                          parkingProvider.selectedVehicle = results;
                        });

                        log("results is $results");
                        log(" parkingProvider.selectedVehicle  ${parkingProvider.selectedVehicle}");
                      },
                    ),
                  ),
                  heightSpace,

              /*    Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onTap: () {
                          vehicalTypeBottomSheet();
                        },
                        child: Container(
                          padding: const EdgeInsets.all(fixPadding * 1.5),
                          width: double.maxFinite,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            color: whiteColor,
                            boxShadow: [
                              BoxShadow(
                                color: blackColor.withOpacity(0.2),
                                blurRadius: 6,
                              )
                            ],
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  parkingProvider.vehicleType.toString(),
                                  style: semibold15LightBlack,
                                ),
                              ),
                              width5Space,
                            ],
                          ),
                        ),
                      )
                    ],
                  ),*/

                  heightSpace,
                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        readOnly: false,
                        cursorColor: primaryColor,
                        controller: parkingProvider.addressController,
                        keyboardType: TextInputType.name,
                        validator: (val) {},
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            // prefixIcon: const Icon(
                            //   Icons.person_outline_rounded,
                            //   size: 20,
                            // ),
                            suffixIcon: GestureDetector(
                              onTap: () async {
                                log("Button Pressed");
                                HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

                                /*
                                  //! FIRST METHOD
                                 final LocatitonGeocoder geocoder = LocatitonGeocoder(googleMapApiKey);
                                  final address = await geocoder.findAddressesFromCoordinates(Coordinates(position.latitude, position.longitude));
                                  log(" Address only  : $address");
                                  // log(" Address : ${address.first.addressLine}");

                                  //! SECOND METHOD
                                  GeoData data = await Geocoder2.getDataFromCoordinates(
                                    latitude: position.latitude,
                                    longitude: position.longitude,
                                    googleMapApiKey: googleMapApiKey,
                                  );
                                  print(  "data ${data.address}");*/
                                //! THIRD METHOD
                                showCircularLoadingDialog(context);

                                double? latitude = 30.158487589998334;
                                double? longitude = 71.52212769572769;
                                if (homeProvider.currentLocation != null) {
                                  setState(() {
                                    latitude = homeProvider.currentLocation?.latitude;
                                    longitude = homeProvider.currentLocation?.longitude;
                                  });
                                } else {
                                  bool permission = await Utils.requestLocationPermission();
                                  if (permission) {
                                    Position position = await Geolocator.getCurrentPosition();

                                    setState(() {
                                      latitude = position.latitude;
                                      longitude = position.longitude;
                                    });
                                  } else {
                                    Utils.errorToast("Permission are denied unable to get current location");
                                  }
                                }
                                log("OutSide first IF");
                                log("Latitude Value $latitude");
                                log("longitude Value $longitude");

                                List<Placemark> newPlace = await placemarkFromCoordinates(
                                  latitude ?? 30.158487589998334,
                                  longitude ?? 71.52212769572769,
                                );
                                Placemark placeMark = newPlace[0];
                                log(" \n $placeMark \n ");
                                String name = placeMark.name.toString();
                                String subLocality = placeMark.subLocality.toString();
                                String locality = placeMark.locality.toString();
                                String administrativeArea = placeMark.administrativeArea.toString();
                                String postalCode = placeMark.postalCode.toString();
                                String country = placeMark.country.toString();
                                String address = "$name $subLocality $locality $administrativeArea $postalCode $country";
                                log("Address is : $address ");
                                parkingProvider.addressController.text = address;
                                Navigator.of(context).pop();
                              },
                              child: const Icon(Icons.my_location_rounded),
                            ),
                            // hintText: getTranslation(context, 'register.user_name'),
                            hintText: "Address",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),
                  heightSpace,
                  /* Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        controller: parkingProvider.numberOfSlotsController,
                        keyboardType: TextInputType.name,
                        validator: (val) {},
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            // prefixIcon: const Icon(
                            //   Icons.person_outline_rounded,
                            //   size: 20,
                            // ),
                            // hintText: getTranslation(context, 'register.user_name'),
                            hintText: "Number of slots",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),*/
                  // heightSpace,
                  // phoneField(context),
                  //+Price Fields :
                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        controller: parkingProvider.priceHourlyController,
                        keyboardType: TextInputType.number,
                        validator: (val) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            // prefixIcon: const Icon(
                            //   Icons.email_outlined,
                            //   size: 20,
                            // ),
                            hintText: "Price Hourly",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),
                  heightSpace,
                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        controller: parkingProvider.priceDailyController,
                        keyboardType: TextInputType.number,
                        validator: (val) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            // prefixIcon: const Icon(
                            //   Icons.email_outlined,
                            //   size: 20,
                            // ),
                            hintText: "Price Daily",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),

                  heightSpace,
                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        controller: parkingProvider.priceWeeklyController,
                        keyboardType: TextInputType.number,
                        validator: (val) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            // prefixIcon: const Icon(
                            //   Icons.email_outlined,
                            //   size: 20,
                            // ),
                            hintText: "Price Weekly",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),

                  heightSpace,
                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        controller: parkingProvider.priceMonthlyController,
                        keyboardType: TextInputType.number,
                        validator: (val) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            // prefixIcon: const Icon(
                            //   Icons.email_outlined,
                            //   size: 20,
                            // ),
                            hintText: "Price Monthly",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),

                  heightSpace,

                  Consumer<ParkingProvider>(
                    builder: (context, provider, child) {
                      return MyDropDownFormField(
                        list: parkingProvider.providerTypes,
                        initialValue: parkingProvider.selectedProviderType,
                        validator: (value) => () {},
                        dropDownText: "Select Provider",
                        hintText: "a",
                        onChange: (value) {
                          parkingProvider.updateProviderTypeValue(value);
                        },
                      );
                    },
                  ),
                  heightSpace,
                  heightSpace,

                  Consumer<ParkingProvider>(
                    builder: (context, provider, child) {
                      return CheckboxListTile(
                        contentPadding: const EdgeInsets.only(left: 5),
                        title: Text('Video surveillance', style: semibold18LightBlack),
                        autofocus: false,
                        activeColor: primaryColor,
                        checkColor: Colors.white,
                        selected: parkingProvider.videoSurveillanceValue,
                        value: parkingProvider.videoSurveillanceValue,
                        onChanged: (value) => parkingProvider.updateVideoSurveillanceValue(value ?? false),
                      );
                    },
                  ), //

                  Consumer<ParkingProvider>(
                    builder: (context, provider, child) {
                      return CheckboxListTile(
                        contentPadding: const EdgeInsets.only(left: 5),
                        title: Text('24 hour access', style: semibold18LightBlack),
                        autofocus: false,
                        activeColor: primaryColor,
                        checkColor: Colors.white,
                        selected: parkingProvider.fullHoursAccessValue,
                        value: parkingProvider.fullHoursAccessValue,
                        onChanged: (value) => parkingProvider.updateFullHoursAccessValue(value ?? false),
                      );
                    },
                  ),

                  Consumer<ParkingProvider>(
                    builder: (context, provider, child) {
                      return CheckboxListTile(
                        contentPadding: const EdgeInsets.only(left: 5),
                        title: Text('Locked', style: semibold18LightBlack),
                        autofocus: false,
                        activeColor: primaryColor,
                        checkColor: Colors.white,
                        selected: parkingProvider.lockedValue,
                        value: parkingProvider.lockedValue,
                        onChanged: (value) => parkingProvider.updateLockedValue(value ?? false),
                      );
                    },
                  ),

                  Consumer<ParkingProvider>(
                    builder: (context, provider, child) {
                      return CheckboxListTile(
                        contentPadding: const EdgeInsets.only(left: 5),
                        title: Text('Covered', style: semibold18LightBlack),
                        autofocus: false,
                        activeColor: primaryColor,
                        checkColor: Colors.white,
                        selected: parkingProvider.coveredValue,
                        value: parkingProvider.coveredValue,
                        onChanged: (value) => parkingProvider.updateCoverValue(value ?? false),
                      );
                    },
                  ),
                  Consumer<ParkingProvider>(
                    builder: (context, provider, child) {
                      return CheckboxListTile(
                        contentPadding: const EdgeInsets.only(left: 5),
                        title: Text('Monthly Rent', style: semibold18LightBlack),
                        autofocus: false,
                        activeColor: primaryColor,
                        checkColor: Colors.white,
                        selected: parkingProvider.monthlyRentValue,
                        value: parkingProvider.monthlyRentValue,
                        onChanged: (value) {
                          parkingProvider.updateMonthlyRentValue(value ?? false);
                          // parkingProvider.showResults();
                        },
                      );
                    },
                  ),

                  heightSpace,

                  /*  MaterialButton(
                    color: Colors.green,
                    onPressed: () async {
                      List<DateTime>? dateTimeList = await showOmniDateTimeRangePicker(
                        context: context,
                        startInitialDate: DateTime.now(),
                        startFirstDate: DateTime(1600).subtract(const Duration(days: 3652)),
                        startLastDate: DateTime.now().add(const Duration(days: 3652)),
                        endInitialDate: DateTime.now(),
                        endFirstDate: DateTime(1600).subtract(const Duration(days: 3652)),
                        endLastDate: DateTime.now().add(const Duration(days: 3652)),
                        is24HourMode: false,
                        isShowSeconds: false,
                        minutesInterval: 1,
                        secondsInterval: 1,
                        borderRadius: const BorderRadius.all(Radius.circular(16)),
                        constraints: const BoxConstraints(maxWidth: 350, maxHeight: 650),
                        transitionBuilder: (context, anim1, anim2, child) {
                          return FadeTransition(
                            opacity: anim1.drive(Tween(begin: 0, end: 1)),
                            child: child,
                          );
                        },
                        transitionDuration: const Duration(milliseconds: 200),
                        barrierDismissible: true,
                        selectableDayPredicate: (dateTime) {
                          // Disable 25th Feb 2023
                          if (dateTime == DateTime(2023, 2, 25)) {
                            return false;
                          } else {
                            return true;
                          }
                        },
                      );
                      DateTime? startDate = DateTime.now();
                      log("Before value is $startDate");
                      startDate = dateTimeList?.first;
                      setState(() {});
                      log("startDate Value after = $startDate");

                      log("dateTimeList ${dateTimeList}");
                    },
                    child: Text("Date Time "),
                  ),*/

                  // heightSpace,
                  // heightSpace,
                  // heightSpace,
                  heightSpace,
                  heightSpace,

                  /*  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        keyboardType: TextInputType.name,
                        controller: authProvider.passwordController,
                        validator: (val) {},
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            prefixIcon: const Icon(
                              Icons.lock_outline_sharp,
                              size: 20,
                            ),
                            hintText: getTranslation(context, 'register.password'),
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),
                  heightSpace,
                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        keyboardType: TextInputType.name,
                        controller: authProvider.passwordConfirmController,
                        validator: (val) {},
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                            border: InputBorder.none,
                            prefixIcon: const Icon(
                              Icons.lock_outline_sharp,
                              size: 20,
                            ),
                            hintText: "Confirm Password",
                            hintStyle: bold16Grey),
                      ),
                    ),
                  ),*/
                  heightSpace,
                  heightSpace,

                  /*Obx(() {
                    if (parkingProvider.pickedImages.isEmpty) {
                      return const SizedBox();
                    } else {
                      return Padding(
                        padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                        child: CommonImageView(
                          height: 190,
                          width: Get.width,
                          radius: 10,
                          file: File(parkingProvider.pickedImages[0].path),
                        ),
                      );
                    }
                  }),
*/
                  // parkingProvider.pickedImages.isEmpty
                  //     ? SizedBox()
                  //     :
                  Consumer<ParkingProvider>(
                    builder: (context, provider, child) {
                      if (parkingProvider.pickedImages.isEmpty) {
                        return const SizedBox();
                      }

                      return Padding(
                        padding: const EdgeInsets.fromLTRB(5, 0, 5, 0),
                        child: CommonImageView(
                          height: 190,
                          width: Get.width,
                          radius: 10,
                          file: File(parkingProvider.pickedImages[0].path),
                        ),
                      );
                    },
                  ),
                  heightSpace,
                  heightSpace,

                  Consumer<ParkingProvider>(
                    builder: (context, provider, child) {
                      return GridView.builder(
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          mainAxisSpacing: 14,
                          crossAxisSpacing: 15,
                          mainAxisExtent: 80,
                        ),
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(0),
                        physics: const BouncingScrollPhysics(),
                        itemCount: parkingProvider.pickedImages.isNotEmpty ? 6 : 6,
                        itemBuilder: (context, index) {
                          if (index == 0 && parkingProvider.pickedImages.isEmpty) {
                            return GestureDetector(
                              onTap: () {
                                changePhotoBottomSheet(size, context, () async {
                                  Navigator.of(context).pop();
                                  await parkingProvider.pickFromCamera(context);
                                }, () async {
                                  Navigator.of(context).pop();

                                  await parkingProvider.pickFromGallery(context);
                                });
                              },
                              child: Image.asset(
                                Assets.assetsAddPhoto,
                                height: Get.height,
                                width: Get.width,
                                color: kSecondaryColor,
                              ),
                            );
                          } else if (index < parkingProvider.pickedImages.length) {
                            return Stack(
                              clipBehavior: Clip.none,
                              children: [
                                CommonImageView(
                                  height: Get.height,
                                  width: Get.width,
                                  radius: 0.0,
                                  file: File(parkingProvider.pickedImages[index].path),
                                ),
                                Positioned(
                                  top: -5,
                                  right: -5,
                                  child: GestureDetector(
                                    onTap: () => parkingProvider.removePickedImage(index),
                                    child: Image.asset(
                                      Assets.assetsRemove,
                                      height: 16,
                                      width: 16,
                                    ),
                                  ),
                                ),
                              ],
                            );
                          } else {
                            if (parkingProvider.pickedImages.isNotEmpty && index == 5) {
                              return GestureDetector(
                                // onTap: () => openImagePickerBottomSheet(context),

                                child: Image.asset(
                                  Assets.assetsAddPhoto,
                                  height: Get.height,
                                  width: Get.width,
                                  color: kSecondaryColor,
                                ),
                              );
                            }
                            return Image.asset(
                              Assets.assetsPhotoPlaceHolder,
                              height: Get.height,
                              width: Get.width,
                            );
                          }
                        },
                      );
                    },
                  ),
                  heightSpace,
                  heightSpace,
                  //+Submit Button
                  GestureDetector(
                    onTap: () async {
                      AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
                      ParkingProvider parkingProvider = Provider.of<ParkingProvider>(context, listen: false);

                      auth.User? currentUser = auth.FirebaseAuth.instance.currentUser;
                      log("current user $currentUser");

                      if (currentUser == null) {
                        Utils.errorToast("Please login first for uploading parking");
                      } else {
                        parkingProvider.uploadParkingDataToDataBase(context);

                        /*await ffstore.collection(collectionUsers).doc(currentUser.uid).get().then((value) {
                          if (value.exists) {
                            UserModel userModel = UserModel.fromJson(value.data() as Map<String, dynamic>);

                            if (userModel.isProfileComplete == true) {
                              parkingProvider.uploadParkingDataToDataBase(context);
                            } else {
                              pageNavigator(context, CompleteProfile());
                            }
                          }
                        });*/
                      }
                    },
                    child: Container(
                      width: double.maxFinite,
                      padding: const EdgeInsets.all(fixPadding * 1.4),
                      decoration: BoxDecoration(
                        color: primaryColor,
                        borderRadius: BorderRadius.circular(10.0),
                        boxShadow: [buttonShadow],
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        "Submit",
                        style: bold18LightBlack,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  vehicleTypeField() {
    ParkingProvider parkingProvider = Provider.of<ParkingProvider>(context, listen: false);

    return;
  }

  vehicalTypeBottomSheet() {
    ParkingProvider parkingProvider = Provider.of<ParkingProvider>(context, listen: false);

    return showModalBottomSheet(
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      context: context,
      builder: (context) {
        return Container(
          width: double.maxFinite,
          padding: const EdgeInsets.all(fixPadding * 2.0),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(20.0),
            ),
          ),
          child: ListView(
            shrinkWrap: true,
            children: [
              Text(
                getTranslation(context, 'add_vehicle.vehicle_type'),
                style: bold16LightBlack,
                textAlign: TextAlign.center,
              ),
              heightSpace,
              height5Space,
              ColumnBuilder(
                itemCount: parkingProvider.vehicleTypeList.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        parkingProvider.vehicleType = parkingProvider.vehicleTypeList[index];
                      });
                      Navigator.pop(context);
                      hideKeyBoard(context);
                    },
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: fixPadding / 2),
                      padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 1.1),
                      decoration: parkingProvider.vehicleType == parkingProvider.vehicleTypeList[index]
                          ? BoxDecoration(color: const Color(0xFFFEF4DA), borderRadius: BorderRadius.circular(10.0), border: Border.all(color: primaryColor))
                          : const BoxDecoration(),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              parkingProvider.vehicleTypeList[index],
                              style: semibold14Black,
                            ),
                          ),
                          widthSpace,
                          parkingProvider.vehicleType == parkingProvider.vehicleTypeList[index]
                              ? Container(
                                  height: 20,
                                  width: 20,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: primaryColor,
                                  ),
                                  child: const Icon(
                                    Icons.done,
                                    color: whiteColor,
                                    size: 13,
                                  ),
                                )
                              : const SizedBox(),
                        ],
                      ),
                    ),
                  );
                },
              )
            ],
          ),
        );
      },
    );
  }

  phoneField(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Container(
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [boxShadow],
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
        child: Row(
          children: [
            // SizedBox(width: 10),
            // Container(
            //   // width: double.maxFinite,
            //   decoration: BoxDecoration(
            //     color: whiteColor,
            //     boxShadow: [boxShadow],
            //     borderRadius: BorderRadius.circular(10.0),
            //   ),
            //   child: Theme(
            //     data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
            //     child: const Icon(
            //       Icons.phone_android_outlined,
            //       size: 20,
            //     ),
            //   ),
            // ),

            GestureDetector(
              onTap: () {
                showCountryPicker(
                  context: context,
                  exclude: <String>['KN', 'MF'],
                  showPhoneCode: true,
                  onSelect: (Country country) {
                    authProvider.getCountryCodeAndPhone(
                      country.flagEmoji,
                      country.phoneCode,
                    );
                  },
                  countryListTheme: CountryListThemeData(
                    searchTextStyle: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      // color: whiteColor,
                    ),
                    bottomSheetHeight: MediaQuery.sizeOf(context).height * 0.7,
                    textStyle: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      // color: whiteColor,

                      // color: kBlackColor,
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16.0),
                      topRight: Radius.circular(16.0),
                    ),
                    // Optional. Styles the search field.
                    inputDecoration: InputDecoration(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 15),
                      hintText: 'Search...',
                      hintStyle: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        // color: kSecondaryColor,
                      ),
                      // fillColor: kPrimaryColor,
                      filled: true,
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(
                          // color: Colors.red,
                          width: 1.0,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(
                          // color: kBorderColor,
                          width: 1.0,
                        ),
                      ),
                    ),
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 0),
                width: 90,
                height: 45,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                  color: whiteColor,
                  boxShadow: const [
                    BoxShadow(
                        // color: kSecondaryColor.withOpacity(0.05),
                        // blurRadius: 2,
                        // offset: const Offset(0, 1),
                        ),
                  ],
                ),
                child: Center(
                  child: Consumer<AuthProvider>(
                    builder: (context, authProvider, child) {
                      return Text(
                        '${authProvider.countryFlag}  +${authProvider.countryCode.toString()}',
                        style: semibold14Grey.copyWith(
                          color: const Color(0xFF8E8E8E),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            // const SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                cursorColor: primaryColor,
                keyboardType: TextInputType.phone,
                controller: authProvider.phoneNumberController,
                validator: (val) {
                  if (val?.isEmpty ?? false) {
                    return 'Please enter phone number';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                  border: InputBorder.none,
                  prefixIcon: const Icon(
                    Icons.phone_android_outlined,
                    size: 20,
                  ),
                  hintText: getTranslation(context, 'register.phone_number'),
                  hintStyle: bold16Grey,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  registerText() {
    return Text(
      getTranslation(context, 'register.user_name'),
      style: bold20LightBlack,
      textAlign: TextAlign.center,
    );
  }

  pleaseText() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2),
      child: Text(
        getTranslation(context, 'register.please_text'),
        textAlign: TextAlign.center,
        style: bold14Grey,
      ),
    );
  }

  topCarImage(Size size) {
    return Container(
      height: size.height * 0.25,
      width: double.maxFinite,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage(
            "assets/auth/car.png",
          ),
          fit: BoxFit.fill,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: const [0.85, 1.0],
            colors: [
              whiteColor.withOpacity(0),
              greyA1Color,
            ],
          ),
        ),
        alignment: languageValue == 4 ? Alignment.topRight : Alignment.topLeft,
        child: IconButton(
          padding: const EdgeInsets.only(top: fixPadding * 3.5, left: fixPadding * 2.0, right: fixPadding * 2.0, bottom: fixPadding * 2.0),
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: lightBlackColor,
          ),
        ),
      ),
    );
  }
}
