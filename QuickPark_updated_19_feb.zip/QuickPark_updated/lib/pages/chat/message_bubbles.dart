import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/generated/assets.dart';
import 'package:parkingproject/pages/chat/view_image.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:parkingproject/widget/common_image_view.dart';
import 'package:parkingproject/widget/my_text.dart';
import 'package:provider/provider.dart';

class LeftMessageBubble extends StatelessWidget {
  LeftMessageBubble({Key? key, this.id, this.msg, this.thumbnail = "", this.time, this.receiveImage, this.type}) : super(key: key);

  String? id, msg, time, receiveImage, type, thumbnail;

  RxBool isSelected = false.obs;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (chatController.isDeleting.value) {
          if (type == "video" && msg == "Video being uploaded") {
            log("in cannot interrupt else");
            Utils.errorToast("You cannot interrupt an uploading video. You may choose to delete it for everyone, after it is uploaded.");
          } else {
            if (!isSelected.value) {
              isSelected.value = true;
              chatController.deleteMsgIdList.add(id);
              chatController.deleteLeftMsgIdList.add(id);
              if ((type == "image" || type == "video") && !chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                chatController.deleteImageLinksList.add(msg);
                chatController.deleteImageIdsList.add(id);
              }
              log("inside chatController.isDeleting.value being true. and now selected this onTap "
                  "and id is: ${id} and  list: ${chatController.deleteMsgIdList} "
                  "\n chatController.deleteMsgIdList.asMap().containsValue(id): "
                  "${chatController.deleteMsgIdList.asMap().containsValue(id)} ");
            } else {
              isSelected.value = false;
              log(" in on onTap contains before deletion \n "
                  " chatController.deleteMsgIdList.asMap().containsValue(id): "
                  " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
              chatController.deleteMsgIdList.remove(id);
              chatController.deleteLeftMsgIdList.remove(id);
              if ((type == "image" || type == "video") && chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                chatController.deleteImageLinksList.remove(msg);
                chatController.deleteImageIdsList.remove(id);
              }
              if (chatController.deleteMsgIdList.isEmpty && chatController.deleteAudioIdList.isEmpty) {
                chatController.isDeleting.value = false;
              }
              log("deleting the id ${id} from list and list is: ${chatController.deleteMsgIdList}");
              log("checking in onTap contains after deletion \n "
                  " chatController.deleteMsgIdList.asMap().containsValue(id): "
                  " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
            }
          }
        } else {
          log("not deleting right now so tap is not gonna work");
        }
      },
      onLongPress: () {
        if (type == "video" && msg == "Video being uploaded") {
          log("in cannot interrupt else");
          Utils.errorToast("You cannot interrupt an uploading video. You may choose to delete it for everyone, after it is uploaded.");
        } else {
          if (!chatController.isDeleting.value) {
            isSelected.value = true;
            chatController.isDeleting.value = true;
            chatController.deleteMsgIdList.add(id);
            chatController.deleteLeftMsgIdList.add(id);
            if ((type == "image" || type == "video") && !chatController.deleteImageLinksList.asMap().containsValue(msg)) {
              chatController.deleteImageLinksList.add(msg);
              chatController.deleteImageIdsList.add(id);
            }
            log("inside chatController.isDeleting.value being false. and now selected this onLongPress"
                "and id is: ${id} and list is: ${chatController.deleteMsgIdList} and "
                "\n chatController.deleteMsgIdList.asMap().containsValue(id): "
                "${chatController.deleteMsgIdList.asMap().containsValue(id)}");
          } else {
            if (!isSelected.value) {
              isSelected.value = true;
              log("inside  on LongPress chatController.isDeleting.value being true. and now selected this onTap "
                  "and id is: ${id} and  list: ${chatController.deleteMsgIdList} and "
                  "\n chatController.deleteMsgIdList.asMap().containsValue(id):"
                  " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
              chatController.deleteMsgIdList.add(id);
              chatController.deleteLeftMsgIdList.add(id);
              if ((type == "image" || type == "video") && !chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                chatController.deleteImageLinksList.add(msg);
                chatController.deleteImageIdsList.add(id);
              }
            } else {
              isSelected.value = false;
              log("checking contains before deletion \n "
                  " chatController.deleteMsgIdList.asMap().containsValue(id): "
                  " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
              chatController.deleteMsgIdList.remove(id);
              chatController.deleteLeftMsgIdList.remove(id);
              if ((type == "image" || type == "video") && chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                chatController.deleteImageLinksList.remove(msg);
                chatController.deleteImageIdsList.remove(id);
              }
              if (chatController.deleteMsgIdList.isEmpty && chatController.deleteAudioIdList.isEmpty && chatController.deleteAudioIdList.isEmpty) {
                chatController.isDeleting.value = false;
              }
              log("deleting the id on LongPress from list and list is: ${chatController.deleteMsgIdList}");
              log("checking contains after deletion \n "
                  " chatController.deleteMsgIdList.asMap().containsValue(id): "
                  " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
            }
            log("deleting on LongPress right now so onLongPress is  is not gonna work");
          }
        }
      },
      child: Obx(() {
        return Container(
          color: isSelected.value && chatController.deleteMsgIdList.asMap().containsValue(id) ? Colors.blue.withOpacity(0.2) : Colors.transparent,
          child: type == 'image'
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Hero(
                      tag: 'imagePreviewChatMedia',
                      transitionOnUserGestures: true,
                      child: GestureDetector(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ImagePreview(imageUrl: msg),
                          ),
                        ),
                        child: Stack(
                          children: [
                            Container(
                              margin: EdgeInsets.only(bottom: 15),
                              height: 150,
                              width: 150,
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                color: kPrimaryColor,
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: [
                                  BoxShadow(
                                    color: kBlackColor.withOpacity(0.16),
                                    blurRadius: 6,
                                    offset: Offset(0, 0),
                                  ),
                                ],
                              ),
                              child: Center(
                                child: CommonImageView(
                                  height: 150,
                                  width: 150,
                                  url: '$msg',
                                  radius: 6.0,
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 2,
                              left: 20,
                              child: Container(
                                width: 150,
                                height: 10,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    MyText(
                                      paddingLeft: 30,
                                      paddingRight: 15,
                                      text: '$time',
                                      paddingTop: 15,
                                      align: TextAlign.end,
                                      size: 10,
                                      color: kSecondaryColor,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                )
              : type == 'video'
                  ? msg == "Video being uploaded"
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Hero(
                              tag: 'videoPreviewChatMedia',
                              transitionOnUserGestures: true,
                              child: GestureDetector(
                                onTap: () {
                                  Utils.errorToast("Can't do that. This Video is still uploading");
                                },
                                child: Container(
                                  margin: EdgeInsets.only(bottom: 15),
                                  height: 50,
                                  width: 250,
                                  padding: EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                    color: kPrimaryColor,
                                    borderRadius: BorderRadius.circular(8),
                                    boxShadow: [
                                      BoxShadow(
                                        color: kBlackColor.withOpacity(0.16),
                                        blurRadius: 6,
                                        offset: Offset(0, 0),
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(6),
                                      child: Container(
                                        height: 150,
                                        width: 250,
                                        child: Row(
                                          children: [
                                            SizedBox(width: 5),
                                            Icon(Icons.cloud_upload_outlined),
                                            SizedBox(width: 10),
                                            Text(msg ?? "Video being uploaded"),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Hero(
                              tag: 'uploadedVideoPreviewChatMedia',
                              transitionOnUserGestures: true,
                              child: GestureDetector(
                                /* onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => VideoPreview(
                                      videoUrl: msg,
                                    ),
                                  ),
                                ),*/
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(
                                        bottom: 15,
                                      ),
                                      height: 150,
                                      width: 150,
                                      padding: EdgeInsets.all(5),
                                      decoration: BoxDecoration(
                                        color: kPrimaryColor,
                                        borderRadius: BorderRadius.circular(8),
                                        boxShadow: [
                                          BoxShadow(
                                            color: kBlackColor.withOpacity(0.16),
                                            blurRadius: 6,
                                            offset: Offset(0, 0),
                                          ),
                                        ],
                                      ),
                                      child: Center(
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(6),
                                          child: Image.network(
                                            '$thumbnail',
                                            height: 150,
                                            width: 150,
                                            fit: BoxFit.cover,
                                            errorBuilder: (
                                              BuildContext context,
                                              Object exception,
                                              StackTrace? stackTrace,
                                            ) {
                                              return const Text(' ');
                                            },
                                            loadingBuilder: (context, child, loadingProgress) {
                                              if (loadingProgress == null) {
                                                return child;
                                              } else {
                                                return circularProgress();
                                              }
                                            },
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: 40,
                                      width: 40,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: kBlackColor.withOpacity(0.5),
                                      ),
                                      child: Center(
                                        child: Image.asset(
                                          "assets/images/play.png",
                                          height: 18,
                                          color: kPrimaryColor,
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 2,
                                      left: 20,
                                      child: Container(
                                        width: 150,
                                        height: 10,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.end,
                                          children: [
                                            MyText(
                                              paddingLeft: 30,
                                              paddingRight: 15,
                                              text: '$time',
                                              paddingTop: 15,
                                              align: TextAlign.end,
                                              size: 10,
                                              color: kSecondaryColor,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        )
                  : Padding(
                      padding: EdgeInsets.only(
                        bottom: 45,
                      ),
                      child: IntrinsicHeight(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(bottom: 15),
                              child: CommonImageView(
                                height: 35,
                                width: 35,
                                url: receiveImage,
                                radius: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 15,
                                      vertical: 10,
                                    ),
                                    decoration: BoxDecoration(
                                      color: kSeoulColor2,
                                      borderRadius: BorderRadius.circular(50.0),
                                    ),
                                    child: MyText(
                                      text: '$msg',
                                      color: kSecondaryColor,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Wrap(
                                    alignment: WrapAlignment.start,
                                    spacing: 6,
                                    crossAxisAlignment: WrapCrossAlignment.center,
                                    children: [
                                      MyText(
                                        text: '$time',
                                        align: TextAlign.end,
                                        size: 8,
                                        color: kSecondaryColor.withOpacity(0.6),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
        );
      }),
    );
  }
}

class RightMessageBubble extends StatelessWidget {
  RightMessageBubble(
      {Key? key, this.id, this.msg, this.thumbnail = "", this.sendByMe = true, this.time, this.receiveImage, this.type, this.isRead = false, this.isReceived = false})
      : super(key: key);

  String? id, msg, time, receiveImage, type, thumbnail;
  bool sendByMe, isRead = false, isReceived = false;
  RxBool isSelected = false.obs;

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    return GestureDetector(
      onTap: sendByMe
          ? () {
              if (chatController.isDeleting.value) {
                if (type == "video" && msg == "Video being uploaded") {
                  log("in cannot interrupt else");
                  Utils.errorToast("You cannot interrupt an uploading video. You may choose to delete it for everyone, after it is uploaded.");
                } else {
                  if (!isSelected.value) {
                    isSelected.value = true;
                    chatController.deleteMsgIdList.add(id);
                    if ((type == "image" || type == "video") && !chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                      chatController.deleteImageLinksList.add(msg);
                      chatController.deleteImageIdsList.add(id);
                    }
                    log("inside chatController.isDeleting.value being true. and now selected this onTap "
                        "and id is: $id and  list: ${chatController.deleteMsgIdList} "
                        "\n chatController.deleteMsgIdList.asMap().containsValue(id): "
                        "${chatController.deleteMsgIdList.asMap().containsValue(id)} ");
                  } else {
                    isSelected.value = false;
                    log(" in on onTap contains before deletion \n "
                        " chatController.deleteMsgIdList.asMap().containsValue(id): "
                        " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
                    chatController.deleteMsgIdList.remove(id);
                    if ((type == "image" || type == "video") && chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                      chatController.deleteImageLinksList.remove(msg);
                      chatController.deleteImageIdsList.remove(id);
                    }
                    if (chatController.deleteMsgIdList.isEmpty && chatController.deleteAudioIdList.isEmpty) {
                      chatController.isDeleting.value = false;
                    }
                    log("deleting the id $id from list and list is: ${chatController.deleteMsgIdList}");
                    log("checking in onTap contains after deletion \n "
                        " chatController.deleteMsgIdList.asMap().containsValue(id): "
                        " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
                  }
                }
              } else {
                log("not deleting right now so tap is not gonna work");
              }
            }
          : null,
      onLongPress: sendByMe
          ? () {
              if (type == "video" && msg == "Video being uploaded") {
                log("in cannot interrupt else");
                Utils.errorToast("You cannot interrupt an uploading video. You may choose to delete it for everyone, after it is uploaded.");
              } else {
                if (!chatController.isDeleting.value) {
                  isSelected.value = true;
                  chatController.isDeleting.value = true;
                  if (!chatController.deleteMsgIdList.asMap().containsValue(id)) chatController.deleteMsgIdList.add(id);
                  if ((type == "image" || type == "video") && !chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                    chatController.deleteImageLinksList.add(msg);
                    chatController.deleteImageIdsList.add(id);
                  }
                  log("inside chatController.isDeleting.value being false. and now selected this onLongPress"
                      "and id is: $id and list is: ${chatController.deleteMsgIdList} and "
                      "\n chatController.deleteMsgIdList.asMap().containsValue(id): "
                      "${chatController.deleteMsgIdList.asMap().containsValue(id)}");
                } else {
                  if (!isSelected.value) {
                    isSelected.value = true;
                    log("inside  on LongPress chatController.isDeleting.value being true. and now selected this onTap "
                        "and id is: $id and  list: ${chatController.deleteMsgIdList} and "
                        "\n chatController.deleteMsgIdList.asMap().containsValue(id):"
                        " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
                    if (!chatController.deleteMsgIdList.asMap().containsValue(id)) chatController.deleteMsgIdList.add(id);
                    if ((type == "image" || type == "video") && !chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                      chatController.deleteImageLinksList.add(msg);
                      chatController.deleteImageIdsList.add(id);
                    }
                  } else {
                    isSelected.value = false;
                    log("checking contains before deletion \n "
                        " chatController.deleteMsgIdList.asMap().containsValue(id): "
                        " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
                    chatController.deleteMsgIdList.remove(id);
                    if ((type == "image" || type == "video") && chatController.deleteImageLinksList.asMap().containsValue(msg)) {
                      chatController.deleteImageLinksList.remove(msg);
                      chatController.deleteImageIdsList.remove(id);
                    }
                    if (chatController.deleteMsgIdList.isEmpty && chatController.deleteAudioIdList.isEmpty && chatController.deleteAudioIdList.isEmpty) {
                      chatController.isDeleting.value = false;
                    }
                    log("deleting the id on LongPress from list and list is: ${chatController.deleteMsgIdList}");
                    log("checking contains after deletion \n "
                        " chatController.deleteMsgIdList.asMap().containsValue(id): "
                        " ${chatController.deleteMsgIdList.asMap().containsValue(id)}");
                  }
                  log("deleting on LongPress right now so onLongPress is  is not gonna work");
                }
              }
            }
          : null,
      child: Obx(() {
        return Container(
          color: isSelected.value && chatController.deleteMsgIdList.asMap().containsValue(id) ? Colors.blue.withOpacity(0.2) : Colors.transparent,
          child: type == 'image'
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Hero(
                      tag: 'rightImagePreviewChatMedia',
                      transitionOnUserGestures: true,
                      child: GestureDetector(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ImagePreview(
                              imageUrl: msg,
                            ),
                          ),
                        ),
                        child: Stack(
                          children: [
                            Container(
                              margin: EdgeInsets.only(
                                bottom: 5,
                              ),
                              height: 150,
                              width: 150,
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                color: kPrimaryColor,
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: [
                                  BoxShadow(
                                    color: kBlackColor.withOpacity(0.16),
                                    blurRadius: 6,
                                    offset: Offset(0, 0),
                                  ),
                                ],
                              ),
                              child: Center(
                                child: CommonImageView(
                                  height: 150,
                                  width: 150,
                                  url: '$msg',
                                  radius: 6.0,
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 12,
                              right: 3,
                              child: Container(
                                width: 150,
                                height: 10,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    MyText(
                                      paddingLeft: 10,
                                      paddingRight: 5,
                                      text: '$time',
                                      paddingTop: 15,
                                      align: TextAlign.end,
                                      size: 10,
                                      color: kPrimaryColor,
                                    ),
                                    (!isRead && !isReceived)
                                        ? Padding(
                                            padding: const EdgeInsets.only(left: 4.0, right: 10),
                                            child: Image.asset(
                                              Assets.imageTick,

                                              width: 14,
                                              height: 10,
                                              color: Colors.grey,
                                            ),
                                          )
                                        : Padding(
                                            padding: const EdgeInsets.only(left: 4.0, right: 10),
                                            child: Image.asset(
                                              Assets.imageRead,

                                              width: 14,
                                              height: 14,
                                              color: (isReceived && !isRead) ? Colors.grey : Colors.blue,
                                            ),
                                          )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                )
              : type == 'video'
                  ? msg == "Video being uploaded"
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Hero(
                              tag: 'rightVideoPreviewChatMedia',
                              transitionOnUserGestures: true,
                              child: GestureDetector(
                                onTap: () {
                                  Utils.errorToast("Can't do that. This Video is still uploading");
                                },
                                child: Container(
                                  margin: EdgeInsets.only(
                                    bottom: 15,
                                  ),
                                  height: 50,
                                  width: 250,
                                  padding: EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                    color: kPrimaryColor,
                                    borderRadius: BorderRadius.circular(8),
                                    boxShadow: [
                                      BoxShadow(
                                        color: kBlackColor.withOpacity(0.16),
                                        blurRadius: 6,
                                        offset: Offset(0, 0),
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(6),
                                      child: Container(
                                        height: 150,
                                        width: 250,
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Icon(Icons.cloud_upload_outlined),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(msg ?? "Video being uploaded"),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Hero(
                              tag: 'rightUploadVideoPreviewChatMedia',
                              transitionOnUserGestures: true,
                              child: GestureDetector(
                                /* onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => VideoPreview(
                                      videoUrl: msg,
                                    ),
                                  ),
                                ),*/

                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(
                                        bottom: 5,
                                      ),
                                      height: 150,
                                      width: 150,
                                      padding: EdgeInsets.all(5),
                                      decoration: BoxDecoration(
                                        color: kPrimaryColor,
                                        borderRadius: BorderRadius.circular(8),
                                        boxShadow: [
                                          BoxShadow(
                                            color: kBlackColor.withOpacity(0.16),
                                            blurRadius: 6,
                                            offset: Offset(0, 0),
                                          ),
                                        ],
                                      ),
                                      child: Center(
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(6),
                                          child: Image.network(
                                            '$thumbnail',
                                            height: 150,
                                            width: 150,
                                            fit: BoxFit.cover,
                                            errorBuilder: (
                                              BuildContext context,
                                              Object exception,
                                              StackTrace? stackTrace,
                                            ) {
                                              return const Text(' ');
                                            },
                                            loadingBuilder: (context, child, loadingProgress) {
                                              if (loadingProgress == null) {
                                                return child;
                                              } else {
                                                return loading();
                                              }
                                            },
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: 40,
                                      width: 40,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: kBlackColor.withOpacity(0.5),
                                      ),
                                      child: Center(
                                        child: Image.asset(
                                          'assets/images/play.png',
                                          height: 18,
                                          color: kPrimaryColor,
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 12,
                                      right: 3,
                                      child: Container(
                                        width: 150,
                                        height: 10,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.end,
                                          children: [
                                            MyText(
                                              paddingLeft: 10,
                                              paddingRight: 5,
                                              text: '$time',
                                              paddingTop: 15,
                                              align: TextAlign.end,
                                              size: 10,
                                              color: kPrimaryColor,
                                            ),
                                            (!isRead && !isReceived)
                                                ? Padding(
                                                    padding: const EdgeInsets.only(left: 4.0, right: 10),
                                                    child: Image.asset(
                                                      Assets.imageTick,
                                                      width: 14,
                                                      height: 10,
                                                      color: Colors.grey,
                                                    ),
                                                  )
                                                : Padding(
                                                    padding: const EdgeInsets.only(left: 4.0, right: 10),
                                                    child: Image.asset(
                                                      Assets.imageRead,
                                                      width: 14,
                                                      height: 14,
                                                      color: (isReceived && !isRead) ? Colors.grey : Colors.blue,
                                                    ),
                                                  )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        )
                  : Padding(
                      padding: EdgeInsets.only(
                        bottom: 45,
                      ),
                      child: IntrinsicHeight(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 15,
                                      vertical: 10,
                                    ),
                                    decoration: BoxDecoration(
                                      color: kSecondaryColor,
                                      borderRadius: BorderRadius.circular(50.0),
                                    ),
                                    child: MyText(
                                      text: '$msg',
                                      color: kPrimaryColor,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Wrap(
                                      alignment: WrapAlignment.start,
                                      spacing: 6,
                                      crossAxisAlignment: WrapCrossAlignment.center,
                                      children: [
                                        MyText(
                                          text: '$time',
                                          align: TextAlign.end,
                                          size: 8,
                                          color: kSecondaryColor.withOpacity(0.6),
                                        ),
                                        (!isRead && !isReceived)
                                            ? Image.asset(
                                                Assets.imageTick,
                                                color: kSecondaryColor.withOpacity(0.5),
                                                height: 12,
                                              )
                                            : Image.asset(
                                                Assets.imageRead,
                                                color: (isReceived && !isRead) ? kSecondaryColor.withOpacity(0.5) : kSecondaryColor,
                                                height: 12,
                                              ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 15),
                              child: CommonImageView(
                                height: 35,
                                width: 35,
                                url: authProvider.userModel.profileImgUrl,
                                radius: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
        );
      }),
    );
  }
}

Widget profileImage(BuildContext context, {String? profileImage, double? size = 44.45}) {
  return Container(
    height: size,
    width: size,
    padding: EdgeInsets.all(3),
    decoration: BoxDecoration(
      color: kPrimaryColor,
      shape: BoxShape.circle,
      boxShadow: [
        BoxShadow(
          color: kBlackColor.withOpacity(0.16),
          blurRadius: 6,
          offset: Offset(0, 0),
        ),
      ],
    ),
    child: Center(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(100),
        child: Image.network(
          profileImage ?? "",
          fit: BoxFit.cover,
          errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
            return const Text(' ');
          },
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) {
              return child;
            } else {
              return loading();
            }
          },
        ),
      ),
    ),
  );
}
