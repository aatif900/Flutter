import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/generated/assets.dart';
import 'package:parkingproject/models/chat_models/chat_room_model.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/pages/chat/message_bubbles.dart';
import 'package:parkingproject/pages/chat/upload_image.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/widget/common_image_view.dart';
import 'package:parkingproject/widget/my_text.dart';
import 'package:provider/provider.dart';

class ChatScreen extends StatefulWidget {
  var receiveImage, receiveName;
  Map<String, dynamic>? docs;
  bool? isArchived;

  ChatScreen({Key? key, this.receiveImage, this.receiveName, this.docs, this.isArchived = false}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  Rx<ChatRoomModel> crm = ChatRoomModel().obs;
  Rx<UserModel> anotherUserModel = UserModel().obs;

  Rx<TextEditingController> messageEditingController = TextEditingController().obs;
  ScrollController scrollController = ScrollController();

  String chatRoomID = "";
  String userID = "";
  String userName = "";
  String anotherUserID = "";
  String anotherUserName = "";
  String anotherUserImage = "";
  String imageUrl = '';
  RxString lastMessage = "".obs;

  RxInt lastMessageAt = 0.obs;

  bool isOpenedUp = true;

  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? otherUserListener;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? chatRoomListener;

  getRoomId() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    userID = authProvider.userModel.uid ?? "";
    log("userID: $userID");
    if (authProvider.userModel.uid! != widget.docs!['user2Model']['uid']) {
      anotherUserID = widget.docs!['user2Model']['uid'];
      anotherUserName = widget.docs!['user2Model']['firstName'];
      anotherUserImage = widget.docs!['user2Model']['profileImgUrl'];
    } else {
      anotherUserID = widget.docs!['user1Model']['uid'];
      anotherUserName = widget.docs!['user1Model']['firstName'];
      anotherUserImage = widget.docs!['user1Model']['profileImgUrl'];
    }
    log("anotherUserID: $anotherUserID");
    log("anotherUserName: $anotherUserName");
    log("anotherUserImage: $anotherUserImage");

    chatRoomID = chatController.getChatRoomId(userID, anotherUserID);
    otherUserListener = ffstore.collection(collectionUsers).doc(anotherUserID).snapshots().listen((event) {
      log("updating anotherUserModel");
      anotherUserModel.value = UserModel.fromJson(event.data() ?? {});
    });
  }

  getChatRoomStream() async {
    chatRoomListener = await ffstore.collection("ChatRoom").doc(widget.docs!['chatRoomId']).snapshots().listen((event) {
      lastMessageAt.value = event['lastMessageAt'];
      lastMessage.value = event['lastMessage'];
      crm.value = ChatRoomModel.fromDocumentSnapshot(event);

      log("\n\n\n getChatRoomStream called and lastMessageAt: $lastMessageAt"
          " lastMessage: $lastMessage \n\n\n");
    });
  }

  sendMessage([String? imageUrl]) async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    var messageText = messageEditingController.value.text;
    if (messageEditingController.value.text.isNotEmpty) {
      messageEditingController.value.text = "";

      print("inside the text part");
      var time = DateTime.now().millisecondsSinceEpoch;
      Map<String, dynamic> messageMap = {
        "sendById": authProvider.userModel.uid,
        "sendByName": authProvider.userModel.firstName,
        "sendByImage": authProvider.userModel.profileImgUrl,
        "receivedById": anotherUserID,
        "receivedByName": anotherUserName,
        "message": messageText,
        "type": "text",
        'time': time,
        'isDeletedFor': [],
        "isRead": false,
        "isReceived": false,
        "chatRoomID": chatRoomID,
      };
      bool isDeletedFor = crm.value.notDeletedFor?.asMap().containsValue(anotherUserID) ?? false;
      if (!isDeletedFor) {
        ffstore.collection("ChatRoom").doc(chatRoomID).update({
          "notDeletedFor": FieldValue.arrayUnion([anotherUserID])
        });
      }
      chatController.addConversationMessage(chatRoomID, time, "text", messageMap, messageText);
    } else if (imageFile != null && (imageUrl != null || imageUrl != "")) {
      var time = DateTime.now().millisecondsSinceEpoch;

      Map<String, dynamic> messageMap = {
        "sendById": authProvider.userModel.uid,
        "sendByName": authProvider.userModel.firstName,
        "sendByImage": authProvider.userModel.profileImgUrl,
        "receivedById": anotherUserID,
        "receivedByName": anotherUserName,
        "message": imageUrl,
        "type": "image",
        'time': time,
        'isDeletedFor': [],
        "isRead": false,
        "isReceived": false,
        "chatRoomID": chatRoomID,
      };
      bool isDeletedFor = crm.value.notDeletedFor?.asMap().containsValue(anotherUserID) ?? false;

      if (!isDeletedFor) {
        ffstore.collection("ChatRoom").doc(chatRoomID).update({
          "notDeletedFor": FieldValue.arrayUnion([anotherUserID]),
        });
      }
      chatController.addConversationMessage(chatRoomID, time, "image", messageMap, imageUrl!);

      messageEditingController.value.text = "";

      imageUrl = "";
    }
    chatController.messageControllerText.value = "";
  }

  String? path;
  File? imageFile;

  Future getImageFromCamera() async {
    ImagePicker _picker = ImagePicker();
    await _picker.pickImage(source: ImageSource.camera, imageQuality: 50).then((xFile) {
      if (xFile != null) {
        imageFile = File(xFile.path);
        path = xFile.path;

        Get.to(
          () => UploadImageScreen(
            imagePath: path,
            anotherUserId: anotherUserID,
            anotherUserName: anotherUserName,
            chatRoomId: crm.value.chatRoomId,
            userId: userID,
          ),
        );
      }
    });
  }

  Future getImageFromGallery() async {
    ImagePicker _picker = ImagePicker();
    await _picker.pickImage(source: ImageSource.gallery, imageQuality: 50).then((xFile) {
      if (xFile != null) {
        imageFile = File(xFile.path);
        path = xFile.path;

        Get.to(
          () => UploadImageScreen(
            imagePath: path,
            anotherUserId: anotherUserID,
            anotherUserName: anotherUserName,
            chatRoomId: crm.value.chatRoomId,
            userId: userID,
          ),
        );
      }
    });
  }

  File? videoFile;
  String? videoPath;

  /* Future getVideoFromGallery() async {
    log("in getVideoFromGallery");
    await ImagePicker().pickVideo(source: ImageSource.gallery).then((xFile) {
      if (xFile != null) {
        videoFile = File(xFile.path);
        videoPath = xFile.path;

        Get.to(
          () => UploadVideoScreen(
            videoPath: videoPath,
            anotherUserId: anotherUserID,
            anotherUserName: anotherUserName,
            chatRoomId: crm.value.chatRoomId,
            userId: userID,
          ),
        );
      }
    });
  }*/

  @override
  void initState() {
    log("passwd doc is: ${widget.docs}");
    isOpenedUp = true;
    getRoomId();
    getChatRoomStream();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Scaffold(
      backgroundColor: scaffoldBgColor,
      appBar: AppBar(
        // backgroundColor: scaffoldBgColor,

        toolbarHeight: 60,
        backgroundColor: kWhiteColor,
        // automaticallyImplyLeading: false,
        elevation: 0,
        leadingWidth: 90,
        leading: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
            ),
            /* Padding(
              padding: const EdgeInsets.only(left: 15),
              child: GestureDetector(
                onTap: () => Get.back(),
                child: Image.asset(
                  "Assets.imagesArrowBack",
                  height: 14,
                ),
              ),
            ),*/
            CommonImageView(
              height: 40,
              width: 40,
              radius: 100.0,
              url: anotherUserImage + "",
            ),
          ],
        ),
        title: MyText(
          text: anotherUserName,
          size: 17,
          weight: FontWeight.w600,
        ),
      ),
      body: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: ffstore.collection(chatRoomCollection).doc(chatRoomID).collection(messagesCollection).orderBy('time').snapshots(),
            builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasData) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (scrollController.hasClients) {
                    scrollController.animateTo(scrollController.position.maxScrollExtent, duration: Duration(seconds: 1), curve: Curves.easeOut);
                  }
                });

                return ListView.builder(
                  physics: BouncingScrollPhysics(),
                  padding: const EdgeInsets.only(top: 20, bottom: 80, left: 15, right: 15),
                  controller: scrollController,
                  itemCount: snapshot.data?.docs.length,
                  itemBuilder: (context, index) {
                    Map<String, dynamic> data = snapshot.data?.docs[index].data() as Map<String, dynamic>;
                    print("snapshot.data.docs[index].data()[type] is: ${data["type"]}");

                    String type = data["type"];
                    String message = data["message"] ?? "what is this?";
                    bool sendByMe = authProvider.userModel.uid == data["sendById"];
                    bool isDeletedForMe = data["isDeletedFor"].contains(authProvider.userModel.uid);

                    String time = data["time"].toString();
                    var day = DateTime.fromMillisecondsSinceEpoch(int.parse(time)).day.toString();
                    var month = DateTime.fromMillisecondsSinceEpoch(int.parse(time)).month.toString();
                    var year = DateTime.fromMillisecondsSinceEpoch(int.parse(time)).year.toString().substring(2);
                    var hour = DateTime.fromMillisecondsSinceEpoch(int.parse(time)).hour;
                    var min = DateTime.fromMillisecondsSinceEpoch(int.parse(time)).minute;
                    String ampm;
                    if (hour > 12) {
                      hour = hour % 12;
                      ampm = 'pm';
                    } else if (hour == 12) {
                      ampm = 'pm';
                    } else if (hour == 0) {
                      hour = 12;
                      ampm = 'am';
                    } else {
                      ampm = 'am';
                    }
                    if (!isDeletedForMe) {
                      if (!sendByMe) {
                        snapshot.data?.docs[index].reference.update({'isRead': true});
                        return LeftMessageBubble(
                          id: snapshot.data?.docs[index].id,
                          receiveImage: anotherUserImage,
                          msg: message,
                          time: "${hour.toString()}:"
                              "${(min.toString().length < 2) ? "0${min.toString()}" : min.toString()} "
                              "${ampm}",
                          type: type,
                          thumbnail: type == "video" ? data["thumbnail"] : "",
                        );
                      } else {
                        return RightMessageBubble(
                          receiveImage: anotherUserImage,
                          id: snapshot.data?.docs[index].id,
                          msg: message,
                          time: "${hour.toString()}:"
                              "${(min.toString().length < 2) ? "0${min.toString()}" : min.toString()} "
                              "${ampm}",
                          type: type,
                          thumbnail: type == "video" ? data["thumbnail"] : "",
                          sendByMe: true,
                          isRead: data['isRead'],
                          isReceived: data['isReceived'],
                        );
                      }
                    } else {
                      return SizedBox();
                    }
                  },
                );
              } else {
                //! LOADING HERE LOADING HERE
                return Container();
              }
            },
          ),
          Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(left: 10, right: 5, bottom: 5),
                  child: Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      boxShadow: [boxShadow],
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                      child: TextFormField(
                        cursorColor: primaryColor,
                        controller: messageEditingController.value,
                        keyboardType: TextInputType.name,
                        validator: (val) {},
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 1.2),
                          border: InputBorder.none,
                          /* suffixIcon: GestureDetector(
                            onTap: () async {
                              sendMessage();
                            },
                            child: const Icon(Icons.my_location_rounded),
                          ),*/
                          hintText: "Write Something",
                          hintStyle: bold16Grey,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // SizedBox(width: 20),
              Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: GestureDetector(
                  onTap: () {
                    sendMessage();
                  },
                  child: Container(
                    height: 45,
                    width: 45,
                    decoration: BoxDecoration(color: primaryColor, shape: BoxShape.circle),
                    child: Center(
                      child: Image.asset(
                        Assets.imageSend,
                        height: 20,
                        width: 20,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 10),
            ],
          ),

          /* SendField(
            controller: messageEditingController.value,
            onChanged: (value) {},
            sendMsg: () => sendMessage(),
            pickGelleryImg: () {
              log("pick video");
              // getVideoFromGallery();
            },
            pickCameraImg: () {
              getImageFromGallery();
            },
          ),*/
        ],
      ),
    );
  }
}
