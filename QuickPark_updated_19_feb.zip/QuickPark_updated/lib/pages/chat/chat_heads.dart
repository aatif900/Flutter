import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:keyboard_dismisser/keyboard_dismisser.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/models/chat_models/chat_head_model.dart';
import 'package:parkingproject/pages/chat/chat_screen.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/widget/common_image_view.dart';
import 'package:parkingproject/widget/my_text.dart';
import 'package:provider/provider.dart';

class ChatHeads extends StatelessWidget {
  TextEditingController searchController = TextEditingController();
  RxString searchText = "".obs;

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: KeyboardDismisser(
        gestures: const [
          GestureType.onTap,
          GestureType.onPanUpdateDownDirection,
        ],
        child: Scaffold(
          backgroundColor: scaffoldBgColor,
          appBar: AppBar(
            centerTitle: false,
            backgroundColor: scaffoldBgColor,
            titleSpacing: 0.0,
            shadowColor: shadowColor.withOpacity(0.25),
            foregroundColor: lightBlackColor,
            leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.arrow_back,
              ),
            ),
            title: Text(
              "Chats",
              style: bold18LightBlack,
            ),
          ),
          body: Obx(() {
            if (searchText.value != "") {
              return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: ffstore.collection(chatRoomCollection).where("searchParameters", arrayContains: searchText.value).snapshots(),
                builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    log("inside stream-builder in waiting state");
                    //! noMessageEmptyState noMessageEmptyState noMessageEmptyState noMessageEmptyState noMessageEmptyState noMessageEmptyState
                    return Container();
                  } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
                    if (snapshot.hasError) {
                      return Center(child: const Text('Some unknown error occurred'));
                    } else if (snapshot.hasData) {
                      if (snapshot.data!.docs.isNotEmpty) {
                        return ListView.builder(
                          shrinkWrap: true,
                          padding: EdgeInsets.symmetric(
                            horizontal: 15,
                            vertical: 20,
                          ),
                          physics: BouncingScrollPhysics(),
                          itemCount: snapshot.data!.docs.length,
                          itemBuilder: (context, index) {
                            ChatHeadModel data = ChatHeadModel();
                            data = ChatHeadModel.fromDocumentSnapshot(snapshot.data!.docs[index]);
                            return chatHeadTiles(
                              context,
                              profileImage: data.user1Id != authProvider.userModel.uid ? data.user1Model!.profileImgUrl : data.user2Model!.profileImgUrl,
                              name: data.user1Id != authProvider.userModel.uid ? data.user1Model!.firstName : data.user2Model!.firstName,
                              status: data.user1Id != authProvider.userModel.uid ? data.user1Model!.emailAddress : data.user2Model!.emailAddress,
                              msg: data.lastMessage,
                              time: data.lastMessageAt,
                              docs: snapshot.data!.docs[index].data() as Map<String, dynamic>,
                              chatRoomId: data.chatRoomId,
                              type: data.lastMessageType,
                            );
                          },
                        );
                      } else {
                        //noResultEmptyState noResultEmptyStatenoResultEmptyStatenoResultEmptyStatenoResultEmptyStatenoResultEmptyState
                        return Container();
                      }
                    } else {
                      log("in else of hasData done and: ${snapshot.connectionState} and"
                          " snapshot.hasData: ${snapshot.hasData}");
                      return SizedBox();
                    }
                  } else {
                    log("in last else of ConnectionState.done and: ${snapshot.connectionState}");
                    return SizedBox();
                  }
                },
              );
            } else {
              return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: ffstore
                    .collection(chatRoomCollection)
                    .where("notDeletedFor", arrayContains: authProvider.userModel.uid)
                    .orderBy('lastMessageAt', descending: true)
                    .snapshots(),
                builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    log("inside stream-builder in waiting state");
                    return SizedBox();
                  } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
                    if (snapshot.hasError) {
                      return const Text('Some unknown error occurred');
                    } else if (snapshot.hasData) {
                      if (snapshot.data!.docs.isNotEmpty) {
                        return ListView.builder(
                          shrinkWrap: true,
                          padding: EdgeInsets.fromLTRB(0, 0, 0, 30),
                          physics: BouncingScrollPhysics(),
                          itemCount: snapshot.data!.docs.length,
                          itemBuilder: (context, index) {
                            ChatHeadModel data = ChatHeadModel();
                            data = ChatHeadModel.fromDocumentSnapshot(snapshot.data!.docs[index]);

                            return chatHeadTiles(
                              context,
                              profileImage: data.user1Id != authProvider.userModel.uid ? data.user1Model!.profileImgUrl : data.user2Model!.profileImgUrl,
                              name: data.user1Id != authProvider.userModel.uid ? data.user1Model!.firstName : data.user2Model!.firstName,
                              status: data.user1Id != authProvider.userModel.uid ? data.user1Model!.emailAddress : data.user2Model!.emailAddress,
                              msg: data.lastMessage,
                              time: data.lastMessageAt,
                              docs: snapshot.data!.docs[index].data() as Map<String, dynamic>,
                              chatRoomId: data.chatRoomId,
                              type: data.lastMessageType,
                              haveUnreadMsg: true,
                            );
                          },
                        );
                      } else {
                        //! noMessageEmptyState noMessageEmptyState noMessageEmptyState noMessageEmptyState noMessageEmptyState noMessageEmptyState noMessageEmptyState
                        return Container();
                      }
                    } else {
                      log("in else of hasData done and: ${snapshot.connectionState} and"
                          " snapshot.hasData: ${snapshot.hasData}");
                      return SizedBox();
                    }
                  } else {
                    log("in last else of ConnectionState.done and: ${snapshot.connectionState}");
                    return SizedBox();
                  }
                },
              );
            }
          }),
        ),
      ),
    );
  }

  Widget chatHeadTiles(
    context, {
    String? profileImage,
    name,
    msg,
    time,
    type,
    chatRoomId,
    status,
    Map<String, dynamic>? docs,
    bool haveUnreadMsg = false,
  }) {
    log("type: $type");
    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Container(
        // color: kPrimaryColor,
        width: double.maxFinite,
        padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
        margin: const EdgeInsets.symmetric(vertical: 5),
        decoration: BoxDecoration(
          color: whiteColor,
          boxShadow: [boxShadow],
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Material(
          color: Colors.transparent,
          child: Theme(
            data: Theme.of(context).copyWith(
              splashColor: kSecondaryColor.withOpacity(0.01),
              highlightColor: kSecondaryColor.withOpacity(0.01),
            ),
            child: ListTile(
              onTap: () => Get.to(() => ChatScreen(receiveImage: profileImage, receiveName: name, docs: docs)),
              // leading: Stack(
              //   children: [
              //     Container(
              //       height: 56.4,
              //       width: 56.4,
              //       padding: EdgeInsets.all(5),
              //       decoration: BoxDecoration(
              //         color: kPrimaryColor,
              //         shape: BoxShape.circle,
              //         boxShadow: [
              //           BoxShadow(
              //             color: kBlackColor.withOpacity(0.16),
              //             blurRadius: 6,
              //             offset: Offset(0, 0),
              //           ),
              //         ],
              //       ),
              //       child: Center(
              //         child: ClipRRect(
              //           borderRadius: BorderRadius.circular(100),
              //           child: Image.network(
              //             '$profileImage',
              //             //+SET HEIGHT WIDTH
              //             fit: BoxFit.cover,
              //             errorBuilder: (
              //               BuildContext context,
              //               Object exception,
              //               StackTrace? stackTrace,
              //             ) {
              //               return const Text(' ');
              //             },
              //             loadingBuilder: (context, child, loadingProgress) {
              //               if (loadingProgress == null) {
              //                 return child;
              //               } else {
              //                 return loading();
              //               }
              //             },
              //           ),
              //         ),
              //       ),
              //     ),
              //     (status ?? "0") == "1"
              //         ? Positioned(
              //             bottom: 5,
              //             right: 0,
              //             child: Image.asset(
              //               "assets/images/verified.png",
              //               height: 15,
              //               width: 15,
              //             ),
              //           )
              //         : SizedBox(),
              //   ],
              // ),
              leading: CommonImageView(
                height: 50,
                width: 50,
                url: profileImage,
                fit: BoxFit.cover,
                radius: 100,
              ),
              title: Text(
                "$name".capitalizeFirst.toString(),
                style: bold18LightBlack,
              ),

              subtitle: type == "image" || type == "video"
                  ? Row(
                      children: [
                        type == "video"
                            ? Icon(
                                Icons.slow_motion_video_outlined,
                                size: 14,
                              )
                            : Icon(
                                Icons.image,
                                size: 14,
                              ),
                        MyText(
                          paddingLeft: 5,
                          text: type == "video" ? "Video" : 'Image',
                          size: 12,
                          weight: FontWeight.w300,
                          color: kSecondaryColor.withOpacity(0.5),
                          maxLines: 1,
                          overFlow: TextOverflow.ellipsis,
                        ),
                      ],
                    )
                  : MyText(
                      text: msg,
                      size: haveUnreadMsg ? 14 : 12,
                      weight: haveUnreadMsg ? FontWeight.w600 : FontWeight.w400,
                      color: haveUnreadMsg ? kSecondaryColor : kSecondaryColor.withOpacity(0.5),
                    ),
              trailing: MyText(
                text: "${DateTime.fromMillisecondsSinceEpoch(time).toString().split(" ")[1].split(":")[0]}"
                    ":"
                    "${DateTime.fromMillisecondsSinceEpoch(time).toString().split(" ")[1].split(":")[1]}",
                size: 12,
                color: kSecondaryColor.withOpacity(0.3),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
