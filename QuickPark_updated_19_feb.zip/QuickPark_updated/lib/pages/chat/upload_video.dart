// import 'dart:async';
// import 'dart:developer';
// import 'dart:io';
//
// import 'package:car_peak/constant/collection_references.dart';
// import 'package:car_peak/constant/color.dart';
// import 'package:car_peak/constant/instance.dart';
// import 'package:car_peak/utils/loading.dart';
// import 'package:car_peak/utils/snack_bar.dart';
// import 'package:car_peak/view/widget/simple_app_bar.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_uploader/flutter_uploader.dart';
// import 'package:get/get.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:uuid/uuid.dart';
// import 'package:video_player/video_player.dart';
// import 'package:video_thumbnail/video_thumbnail.dart';
//
// class UploadVideoScreen extends StatefulWidget {
//   final String? videoPath;
//   final String? userId;
//   final String? anotherUserId;
//   final String? anotherUserName;
//   final String? chatRoomId;
//
//   const UploadVideoScreen({Key? key, this.videoPath, this.anotherUserId, this.anotherUserName, this.userId, this.chatRoomId})
//       : super(key: key);
//
//   @override
//   _UploadVideoScreenState createState() => _UploadVideoScreenState();
// }
//
// class _UploadVideoScreenState extends State<UploadVideoScreen> {
//   String videoUrl = '';
//   RxDouble uploadPercentageValue = 0.0.obs;
//
//   File? _video;
//   VideoPlayerController? _videoPlayerController;
//
//   @override
//   void initState() {
//     _video = File(widget.videoPath ?? "");
//     _videoPlayerController = VideoPlayerController.file(_video!)
//       ..initialize().then((_) {
//         setState(() {});
//       });
//     super.initState();
//   }
//
//   @override
//   void dispose() {
//     if (_videoPlayerController != null) _videoPlayerController?.dispose();
//     super.dispose();
//   }
//
//   void playPause() {
//     setState(() {
//       isPlaying = !isPlaying;
//       isPlaying ? _videoPlayerController!.pause() : _videoPlayerController!.play();
//       isPlaying ? opacity = 1.0 : opacity = 0.0;
//     });
//   }
//
//   bool isPlaying = false;
//
//   double opacity = 1.0;
//
//   @override
//   Widget build(BuildContext context) {
//     log('${widget.videoPath} in preview');
//     return WillPopScope(
//       onWillPop: () async {
//         _videoPlayerController?.pause();
//         return true;
//       },
//       child: Scaffold(
//         extendBodyBehindAppBar: true,
//         appBar: simpleAppBar(
//             title: "",
//             onBackTap: () {
//               _videoPlayerController?.pause();
//               Get.back();
//             }),
//         body: Container(
//           height: Get.height,
//           width: Get.width,
//           child: Stack(
//             alignment: Alignment.center,
//             children: [
//               AspectRatio(
//                 aspectRatio: _videoPlayerController!.value.aspectRatio,
//                 child: VideoPlayer(_videoPlayerController!),
//               ),
//               AnimatedOpacity(
//                 opacity: opacity,
//                 duration: Duration(
//                   milliseconds: 500,
//                 ),
//                 child: Container(
//                   height: 55,
//                   width: 55,
//                   decoration: BoxDecoration(
//                     shape: BoxShape.circle,
//                     color: kBlackColor.withOpacity(0.5),
//                   ),
//                   child: Material(
//                     color: Colors.transparent,
//                     child: InkWell(
//                       onTap: playPause,
//                       borderRadius: BorderRadius.circular(100),
//                       splashColor: kPrimaryColor.withOpacity(0.1),
//                       highlightColor: kPrimaryColor.withOpacity(0.1),
//                       child: Center(
//                         child: Image.asset(
//                           isPlaying ? 'assets/images/pause.png' : 'assets/images/play.png',
//                           height: 23,
//                           color: kPrimaryColor,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//         floatingActionButton: FloatingActionButton.extended(
//           heroTag: "sendButton",
//           backgroundColor: kSecondaryColor,
//           onPressed: () {
//             uploadVideo();
//           },
//           label: Text(
//             "Send",
//             style: TextStyle(
//               color: Colors.white,
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   uploadVideo() async {
//     _videoPlayerController?.pause();
//     String videoDocId = Uuid().v1();
//     String thumbnailFileName = videoDocId;
//
//     // String fileName = videoDocId;
//     // var ref = FirebaseStorage.instance.ref().child("chatRooms/${widget.chatRoomId!}/videos").child("$fileName.mp4");
//     var thumbnailRef =
//         FirebaseStorage.instance.ref().child("chatRooms/${widget.chatRoomId!}/thumbnails").child("$thumbnailFileName.jpg");
//     try {
//       showDialog(
//         context: context,
//         builder: (context) {
//           return loading();
//         },
//       );
//       Directory tempDirectory = await getTemporaryDirectory();
//       String path = tempDirectory.path;
//
//       final thumbnailFile = await VideoThumbnail.thumbnailFile(
//         video: widget.videoPath ?? "",
//         thumbnailPath: path,
//         imageFormat: ImageFormat.JPEG,
//         maxHeight: 0,
//         maxWidth: 0,
//         quality: 100,
//       );
//       print("thumbnailFile path in chat video preview screen is: ${thumbnailFile}");
//       if (Platform.isIOS) {
//         print("in isIOS thumbnailFile path in chat video preview screen is: ${thumbnailFile}");
//         thumbnailRef
//             .putFile(
//           File(thumbnailFile ?? ""),
//           SettableMetadata(customMetadata: {
//             "imageId": thumbnailFileName,
//             "messageDocId": videoDocId,
//             "chatroomId": widget.chatRoomId!,
//             "type": "chatVideoThumbnail",
//             "isIOS": "true",
//           }),
//         )
//             .then((p0) {
//           print("in then of putFile and ${p0.bytesTransferred}");
//           print("in then of putFile and ${p0.state.toString()}");
//           if (File(thumbnailFile!).existsSync()) {
//             File(thumbnailFile).delete(recursive: true);
//           }
//         });
//         print("in isIOS after the putFile part thumbnailFile path in chat video preview screen is: ${thumbnailFile}");
//
//         var time = DateTime.now().millisecondsSinceEpoch;
//         Map<String, dynamic> messageMap = {
//           "sendById": userModel.value.currentuserid,
//           "sendByName": userModel.value.firstname,
//           "sendByImage": userModel.value.imgurl,
//           "receivedById": widget.anotherUserId,
//           "receivedByName": widget.anotherUserName,
//           "message": "Video being uploaded",
//           "thumbnail": "",
//           "type": "video",
//           'time': time,
//           'isDeletedFor': [],
//           'isRead': false,
//           "isReceived": false,
//         };
//         await FirebaseFirestore.instance
//             .collection(chatRoomCollection)
//             .doc(widget.chatRoomId!)
//             .collection(messagesCollection)
//             .doc(videoDocId)
//             .set(messageMap)
//             .then((value) async {
//           await FirebaseFirestore.instance.collection(chatRoomCollection).doc(widget.chatRoomId!).update({
//             'lastMessageAt': time,
//             'lastMessage': "Video being uploaded",
//             'lastMessageType': "video",
//           }).catchError((e) {
//             log('\n\n\n\n error in updating last message and last message time ${e.toString()}');
//           });
//         });
//       } else {
//         await thumbnailRef
//             .putFile(
//           File(thumbnailFile ?? ""),
//           SettableMetadata(
//             customMetadata: {
//               "imageId": thumbnailFileName,
//               "messageDocId": videoDocId,
//               "chatroomId": widget.chatRoomId!,
//               "type": "chatVideoThumbnail",
//               "isIOS": "false",
//             },
//           ),
//         )
//             .then((p0) async {
//           if (p0.state == TaskState.success) {
//             await p0.ref.getDownloadURL().then((value) async {
//               var time = DateTime.now().millisecondsSinceEpoch;
//               Map<String, dynamic> messageMap = {
//                 "sendById": userModel.value.currentuserid,
//                 "sendByName": userModel.value.firstname,
//                 "sendByImage": userModel.value.imgurl,
//                 "receivedById": widget.anotherUserId,
//                 "receivedByName": widget.anotherUserName,
//                 "message": "Video being uploaded",
//                 "thumbnail": value,
//                 "type": "video",
//                 'time': time,
//                 'isDeletedFor': [],
//                 'isRead': false,
//                 "isReceived": false,
//               };
//               await FirebaseFirestore.instance
//                   .collection(chatRoomCollection)
//                   .doc(widget.chatRoomId!)
//                   .collection(messagesCollection)
//                   .doc(videoDocId)
//                   .set(messageMap)
//                   .then((value) async {
//                 if (File(thumbnailFile!).existsSync()) {
//                   File(thumbnailFile).delete(recursive: true);
//                 }
//                 await FirebaseFirestore.instance.collection(chatRoomCollection).doc(widget.chatRoomId!).update({
//                   'lastMessageAt': time,
//                   'lastMessage': "Video being uploaded",
//                   'lastMessageType': "video",
//                 }).catchError((e) {
//                   log('\n\n\n\n error in updating last message and last message time ${e.toString()}');
//                 });
//               }).catchError((e) {
//                 log('\n\n\n\n error in adding video mid message ${e.toString()}');
//               });
//             });
//           }
//         });
//       }
//
//       StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? videoDocStream;
//       videoDocStream = ffstore
//           .collection(chatRoomCollection)
//           .doc(widget.chatRoomId)
//           .collection(messagesCollection)
//           .doc(videoDocId)
//           .snapshots()
//           .listen((event) async {
//         log("inside the videoDocId stream");
//         bool containsUploadUrl = event.data()?.containsKey("uploadUrl") ?? false;
//         if (containsUploadUrl) {
//           log("inside containsUploadUrl");
//
//           await FlutterUploader().enqueue(
//             RawUpload(
//               url: event.data()?['uploadUrl'] ?? "",
//               path: widget.videoPath,
//               method: UploadMethod.PUT,
//               tag: 'chat video uploading',
//             ),
//           );
//           if (videoDocStream != null) videoDocStream.cancel();
//         }
//       });
//
//       Get.back();
//       Get.back();
//     } on FirebaseException catch (e) {
//       log("error in sending image is: $e");
//
//       showMsg(
//         msg: 'Storage Error!',
//         context: context,
//         bgColor: Colors.red,
//       );
//     }
//
//     log('this is status 1');
//     print(videoUrl);
//   }
// }
