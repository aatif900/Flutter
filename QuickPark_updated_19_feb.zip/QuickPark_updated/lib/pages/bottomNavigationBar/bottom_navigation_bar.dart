import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/pages/offer%20Parking/offer_parking_page.dart';
import 'package:parkingproject/theme/theme.dart';

import '../screens.dart';

class BottomBar extends StatefulWidget {
  const BottomBar({super.key});

  @override
  State<BottomBar> createState() => _BottomBarState();
}

class _BottomBarState extends State<BottomBar> {
  int selectedIndex = 0;

  DateTime? currentBackPressTime = DateTime.now();

  Future<bool> onWillPop() {
    DateTime now = DateTime.now();
    if (now.difference(currentBackPressTime!) > const Duration(seconds: 3)) {
      currentBackPressTime = now;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: blackColor,
          content: Text(
            getTranslation(context, 'app_exit.exit_text'),
            style: bold15White,
          ),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(milliseconds: 1500),
        ),
      );
      return Future.value(false);
    } else {
      return Future.value(true);
    }
  }

  subscribeToNotification() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await FirebaseMessaging.instance.subscribeToTopic(user.uid).catchError((err) {
        print('ERROR SUBSCRIBING NOTIFICATION' + err.toString());
      });
    }
  }

  @override
  void initState() {
    subscribeToNotification();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    User? user = FirebaseAuth.instance.currentUser;

    List<StatefulWidget> pages = [];
    List<BottomNavigationBarItem> items = [];
    pages.add(HomeScreen());
    user != null ? pages.add(MyBookingScreen()) : null;
    user != null ? pages.add(BookMarkScreen()) : null;
    user != null ? pages.add(OfferParkingScreen()) : null;
    pages.add(ProfileScreen());

    items.add(BottomNavigationBarItem(icon: const Icon(CupertinoIcons.placemark), label: getTranslation(context, 'bottomBar.near_by')));
    user != null ? items.add(BottomNavigationBarItem(icon: const Icon(CupertinoIcons.ticket), label: getTranslation(context, 'bottomBar.booking'))) : null;
    user != null ? items.add(BottomNavigationBarItem(icon: const Icon(Icons.bookmark_border_rounded), label: getTranslation(context, 'bottomBar.saved'))) : null;
    user != null ? items.add(BottomNavigationBarItem(icon: Icon(CupertinoIcons.add), label: "Offer")) : null;
    // items.add(BottomNavigationBarItem(icon: const Icon(Icons.person_outline), label: getTranslation(context, 'bottomBar.pofile')));
    items.add(BottomNavigationBarItem(icon: const Icon(Icons.settings), label: "Setting"));

    return WillPopScope(
      onWillPop: onWillPop,
      child: Scaffold(
        backgroundColor: scaffoldBgColor,
        body: pages.elementAt(selectedIndex),
        bottomNavigationBar: BottomNavigationBar(
            onTap: (index) {
              setState(() {
                selectedIndex = index;
              });
            },
            type: BottomNavigationBarType.fixed,
            backgroundColor: whiteColor,
            currentIndex: selectedIndex,
            selectedItemColor: lightBlackColor,
            showSelectedLabels: true,
            showUnselectedLabels: true,
            selectedLabelStyle: bold14LightBlack,
            unselectedLabelStyle: bold14Grey,
            unselectedItemColor: greyColor,
            items: items

            /* [
            BottomNavigationBarItem(icon: const Icon(CupertinoIcons.placemark), label: getTranslation(context, 'bottomBar.near_by')),
            BottomNavigationBarItem(icon: const Icon(CupertinoIcons.ticket), label: getTranslation(context, 'bottomBar.booking')),
            BottomNavigationBarItem(icon: const Icon(Icons.bookmark_border_rounded), label: getTranslation(context, 'bottomBar.saved')),
            const BottomNavigationBarItem(icon: Icon(CupertinoIcons.add), label: "Offer"),
            BottomNavigationBarItem(icon: const Icon(Icons.person_outline), label: getTranslation(context, 'bottomBar.pofile'))
          ],*/

            ),
      ),
    );
  }
}
