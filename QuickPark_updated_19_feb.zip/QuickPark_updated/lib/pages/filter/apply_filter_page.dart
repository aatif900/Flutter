// ignore_for_file: unused_local_variable

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/pages/filter/filter_result_page.dart';
import 'package:parkingproject/provider/filter_provider.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/widget/my_custom_button.dart';
import 'package:parkingproject/widget/my_drop_down_form_field.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_core/theme.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';

class ApplyFilterPage extends StatefulWidget {
  const ApplyFilterPage({super.key});

  @override
  State<ApplyFilterPage> createState() => _ApplyFilterPageState();
}

class _ApplyFilterPageState extends State<ApplyFilterPage> {
  @override
  Widget build(BuildContext context) {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    FilterProvider filterProvider = Provider.of<FilterProvider>(context, listen: false);
    /* filterProvider.filteredDataList.clear();
    filterProvider.tempList.clear();*/

    return Scaffold(
      appBar: AppBar(
        backgroundColor: scaffoldBgColor,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          getTranslation(context, 'extend_parking_time.filter'),
          style: bold20LightBlack,
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.zero,
        children: [
          StatefulBuilder(builder: (context, state) {
            return Container(
              width: double.maxFinite,
              decoration: const BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
              ),
              child: ListView(
                shrinkWrap: true,
                padding: const EdgeInsets.symmetric(vertical: fixPadding * 2.0),
                physics: const BouncingScrollPhysics(),
                children: [
                  heightSpace,
                  heightSpace,
                  //+DISTANCE
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                        child: Text(
                          getTranslation(context, 'extend_parking_time.distance'),
                          style: bold16LightBlack,
                        ),
                      ),
                      heightSpace,
                      heightSpace,
                      SfSliderTheme(
                        data: SfSliderThemeData(
                          thumbStrokeWidth: 1.5,
                          thumbStrokeColor: whiteColor,
                          tooltipBackgroundColor: primaryColor,
                          tooltipTextStyle: bold14LightBlack,
                        ),
                        child: SfSlider(
                          min: 0.0,
                          max: 300.0,
                          enableTooltip: true,
                          activeColor: primaryColor,
                          inactiveColor: const Color(0xFFE6E6E6),
                          tooltipTextFormatterCallback: (dynamic actualValue, String formattedText) {
                            return "${filterProvider.selectedFilterDistance.toStringAsFixed(2)} km";
                          },
                          shouldAlwaysShowTooltip: true,
                          interval: 1.0,
                          onChanged: (value) {
                            state(() {
                              setState(() {
                                filterProvider.selectedFilterDistance = value;
                                log("selectedFilterDistance ${filterProvider.selectedFilterDistance}");
                              });
                            });
                            // filterProvider.showResults(context);
                          },
                          value: filterProvider.selectedFilterDistance,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "0.00km",
                              style: bold14Grey,
                            ),
                            Consumer<FilterProvider>(
                              builder: (context, provider, child) {
                                return Text(
                                  "${filterProvider.selectedFilterDistance.toStringAsFixed(2)} km",
                                  style: bold14Grey,
                                );
                              },
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  heightSpace,
                  heightSpace,
                  //+PRICE

                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                        child: Text(
                          getTranslation(context, 'extend_parking_time.price'),
                          style: bold16LightBlack,
                        ),
                      ),
                      heightSpace,
                      heightSpace,
                      SfSliderTheme(
                        data: SfSliderThemeData(
                          thumbStrokeWidth: 1.5,
                          thumbStrokeColor: whiteColor,
                          tooltipBackgroundColor: primaryColor,
                          tooltipTextStyle: bold14LightBlack,
                        ),
                        child: SfSlider(
                          min: 2.0,
                          max: 200.0,
                          enableTooltip: true,
                          shouldAlwaysShowTooltip: true,
                          activeColor: primaryColor,
                          inactiveColor: const Color(0xFFE6E6E6),
                          tooltipTextFormatterCallback: (dynamic actualValue, String formattedText) {
                            return "\$${filterProvider.selectedFilterPrice.toInt()} +";
                          },
                          interval: 1.0,
                          onChanged: (value) {
                            state(() {
                              setState(() {
                                filterProvider.selectedFilterPrice = value;
                                log("selectedFilterPrice ${filterProvider.selectedFilterPrice}");
                                log("selectedFilterPrice ${filterProvider.selectedFilterPrice.toInt()}");
                                // filterProvider.showResults(context);
                              });
                            });
                          },
                          value: filterProvider.selectedFilterPrice,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "\$2.00/${getTranslation(context, 'extend_parking_time.per_hour')}",
                              style: bold14Grey,
                            ),
                            Text(
                              "\$200.00/${getTranslation(context, 'extend_parking_time.per_hour')}",
                              style: bold14Grey,
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                  heightSpace,
                  heightSpace,

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Consumer<FilterProvider>(
                      builder: (context, homeProviderName, child) {
                        return MyDropDownFormField(
                          list: filterProvider.vehicleTypesList,
                          initialValue: filterProvider.selectedVehicleType,
                          validator: (value) => () {},
                          dropDownText: "Select vehicle type",
                          hintText: "a",
                          onChange: (value) {
                            filterProvider.updateSelectedVehicleValue(value);
                            // filterProvider.showResults(context);
                          },
                        );
                      },
                    ),
                  ),

                  heightSpace,

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding),
                    child: Column(
                      children: [
                        Consumer<FilterProvider>(
                          builder: (context, provider, child) {
                            return CheckboxListTile(
                              contentPadding: const EdgeInsets.only(left: 5),
                              title: Text('Video surveillance', style: semibold18LightBlack),
                              autofocus: false,
                              activeColor: primaryColor,
                              checkColor: Colors.white,
                              selected: filterProvider.videoSurveillanceValue,
                              value: filterProvider.videoSurveillanceValue,
                              onChanged: (value) {
                                filterProvider.updateVideoSurveillanceValue(value ?? false);
                                // filterProvider.showResults(context);
                              },
                            );
                          },
                        ), //

                        Consumer<FilterProvider>(
                          builder: (context, provider, child) {
                            return CheckboxListTile(
                              contentPadding: const EdgeInsets.only(left: 5),
                              title: Text('24 hour access', style: semibold18LightBlack),
                              autofocus: false,
                              activeColor: primaryColor,
                              checkColor: Colors.white,
                              selected: filterProvider.fullHoursAccessValue,
                              value: filterProvider.fullHoursAccessValue,
                              onChanged: (value) {
                                filterProvider.updateFullHoursAccessValue(value ?? false);
                                // filterProvider.showResults(context);
                              },
                            );
                          },
                        ),

                        Consumer<FilterProvider>(
                          builder: (context, provider, child) {
                            return CheckboxListTile(
                              contentPadding: const EdgeInsets.only(left: 5),
                              title: Text('Locked', style: semibold18LightBlack),
                              autofocus: false,
                              activeColor: primaryColor,
                              checkColor: Colors.white,
                              selected: filterProvider.lockedValue,
                              value: filterProvider.lockedValue,
                              onChanged: (value) {
                                filterProvider.updateLockedValue(value ?? false);
                                // filterProvider.showResults(context);
                              },
                            );
                          },
                        ),

                        Consumer<FilterProvider>(
                          builder: (context, provider, child) {
                            return CheckboxListTile(
                              contentPadding: const EdgeInsets.only(left: 5),
                              title: Text('Covered', style: semibold18LightBlack),
                              autofocus: false,
                              activeColor: primaryColor,
                              checkColor: Colors.white,
                              selected: filterProvider.coveredValue,
                              value: filterProvider.coveredValue,
                              onChanged: (value) {
                                filterProvider.updateCoverValue(value ?? false);
                                // filterProvider.showResults(context);
                              },
                            );
                          },
                        ),
                        //+
                        Consumer<FilterProvider>(
                          builder: (context, provider, child) {
                            return CheckboxListTile(
                              contentPadding: const EdgeInsets.only(left: 5),
                              title: Text('Monthly Rent', style: semibold18LightBlack),
                              autofocus: false,
                              activeColor: primaryColor,
                              checkColor: Colors.white,
                              selected: filterProvider.monthlyRentValue,
                              value: filterProvider.monthlyRentValue,
                              onChanged: (value) {
                                filterProvider.updateMonthlyRentValue(value ?? false);
                                // filterProvider.showResults(context);
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  heightSpace,
                  //+RATING
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          getTranslation(context, 'extend_parking_time.rating'),
                          style: bold16LightBlack,
                        ),
                        heightSpace,
                        height5Space,
                        Wrap(
                          spacing: fixPadding,
                          runSpacing: fixPadding,
                          children: [
                            for (int index = 0; index <= 5; index++)
                              GestureDetector(
                                onTap: index == 0
                                    ? () {
                                        state(() {
                                          setState(() {
                                            filterProvider.selectedFilterRating = index;
                                            log("selectedFilterRating ${filterProvider.selectedFilterRating}");
                                            log("selectedFilterRating ${filterProvider.selectedFilterRating.toDouble()}");
                                          });
                                        });
                                      }
                                    : () {
                                        state(() {
                                          setState(() {
                                            filterProvider.selectedFilterRating = index;
                                            log("selectedFilterRating ${filterProvider.selectedFilterRating}");
                                            log("selectedFilterRating toDouble ${filterProvider.selectedFilterRating.toDouble()}");

                                            // filterProvider.showResults(context);
                                          });
                                        });
                                      },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding / 2),
                                  decoration: BoxDecoration(
                                    color: whiteColor,
                                    borderRadius: BorderRadius.circular(5.0),
                                    border: Border.all(
                                      color: filterProvider.selectedFilterRating == index ? primaryColor : const Color(0xFFE6E6E6),
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        index.toString(),
                                        style: filterProvider.selectedFilterRating == index ? bold14TextColor : bold14Grey,
                                      ),
                                      widthBox(2),
                                      Icon(
                                        Icons.star,
                                        size: 15,
                                        color: filterProvider.selectedFilterRating == index ? textColor : greyColor,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                          ],
                        )
                      ],
                    ),
                  ),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  /* Padding(
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: buttonWidget(
                            getTranslation(context, 'extend_parking_time.clear_all'),
                            () async {
                              final homProvider = Provider.of<FilterProvider>(context, listen: false);
                              await homProvider.getDataFromFirebase();
                              homProvider.changeBoolValue(false);
                              log("new applyFilter value ${homProvider.applyFilter}");

                              Navigator.pop(context);
                            },
                            whiteColor,
                            textColor,
                          ),
                        ),
                        widthSpace,
                        widthSpace,
                        Expanded(
                          child: buttonWidget(
                            getTranslation(context, 'extend_parking_time.apply'),
                            () async {
                              final homProvider = Provider.of<FilterProvider>(context, listen: false);
                              await homProvider.getFilterDataFromFirebase();
                              homProvider.changeBoolValue(true);
                              // Navigator.of(context).pop();
                              log("new applyFilter value ${homProvider.applyFilter}");
                              // Navigator.pop(context);
                            },
                            primaryColor,
                            lightBlackColor,
                          ),
                        ),
                      ],
                    ),
                  ),*/

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                    child: Consumer<FilterProvider>(
                      builder: (context, provider, child) {
                        return MyButton(
                          onTap: () async {
                            await provider.showResults(context).then((value) {
                              pageNavigator(context, FilterResultPage());
                            });
                            // await Future.delayed(Duration(seconds: 1));
                          },
                          buttonText: filterProvider.isSearching ? "Searching please wait ....." : "Search Parking"

                          /* filterProvider.isSearching
                              ? "Searching please wait ....."
                              : filterProvider.filteredDataList.isEmpty
                                  ? "No Parking"
                                  : "Show ${filterProvider.filteredDataList.length} Result"*/

                          ,
                        );
                      },
                    ),
                  ),
                  heightSpace,

                  heightSpace,
                ],
              ),
            );
          })
        ],
      ),
    );
  }
}
