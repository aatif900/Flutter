import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/pages/profile/languages.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:parkingproject/widget/my_custom_button.dart';
import 'package:parkingproject/widget/my_custom_text_form_field.dart';
import 'package:provider/provider.dart';

import '../../theme/theme.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  TextEditingController userNameController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  getDta() async {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    await ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).get().then((value) {
      authProvider.userModel = UserModel.fromJson(value.data() as Map<String, dynamic>);
    });
  }

  @override
  void initState() {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    authProvider.userNameController.text = authProvider.userModel.userName ?? "";
    authProvider.firstNameController.text = authProvider.userModel.firstName ?? "";
    authProvider.lastNameController.text = authProvider.userModel.lastName ?? "";
    authProvider.phoneNumberController.text = authProvider.userModel.phoneNumber ?? "";
    authProvider.emailAddressController.text = authProvider.userModel.emailAddress ?? "";
    authProvider.addressController.text = authProvider.userModel.address ?? "";
    authProvider.houseNumberController.text = authProvider.userModel.houseNumber ?? "";
    authProvider.zipCodeController.text = authProvider.userModel.zipCode ?? "";
    authProvider.cityController.text = authProvider.userModel.city ?? "";
    authProvider.countryController.text = authProvider.userModel.country ?? "";
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: scaffoldBgColor,
        titleSpacing: 0.0,
        shadowColor: shadowColor.withOpacity(0.25),
        foregroundColor: lightBlackColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
        title: Text(
          getTranslation(context, 'edit_profile.edit_profile'),
          style: bold18LightBlack,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(fixPadding * 2.0),
        physics: const BouncingScrollPhysics(),
        children: [
          userProfileImage(size),
          heightSpace,
          heightSpace,
          heightSpace,
          // MyTextFormField(
          //   hintText: getTranslation(context, 'edit_profile.email_address'),
          //   controller: authProvider.emailAddressController,
          // ),
          nameField(context),
          // heightSpace,
          heightSpace,
          MyTextFormField(
            topText: "First Name",
            hintText: "First Name",
            controller: authProvider.firstNameController,
          ),
          heightSpace,

          MyTextFormField(
            topText: "Last Name",
            hintText: "Last Name",
            controller: authProvider.lastNameController,
          ),
          heightSpace,

          MyTextFormField(
            topText: "Address",
            hintText: "Address",
            controller: authProvider.addressController,
          ),
          heightSpace,

          MyTextFormField(
            topText: "House Number",
            hintText: "House Number",
            controller: authProvider.houseNumberController,
          ),
          heightSpace,

          MyTextFormField(
            keyboardType: TextInputType.number,
            topText: "Zip Code",
            hintText: "Zip Code",
            controller: authProvider.zipCodeController,
          ),
          heightSpace,

          MyTextFormField(
            topText: "City",
            hintText: "City",
            controller: authProvider.cityController,
          ),
          heightSpace,

          MyTextFormField(
            topText: "Country",
            hintText: "Country",
            controller: authProvider.countryController,
          ),
          // heightSpace,
          heightSpace,
          mobileField(context),
          // heightSpace,
          heightSpace,
          emailField(context),
          heightSpace,
          heightSpace,
          heightSpace,
          heightSpace,
          MyButton(
            buttonText: getTranslation(context, 'edit_profile.update'),
            onTap: () {
              if (auth.currentUser != null) {
                AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
                authProvider.updateProfile(context);
              } else {
                Utils.showCustomSnackBar(context, "Please login first for updating profile");
              }
            },
          ),
          heightSpace,

          // updateButton(context),
        ],
      ),
    );
  }

  updateButton(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (auth.currentUser != null) {
          AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
          authProvider.updateProfile(context);
        } else {
          Utils.showCustomSnackBar(context, "Please login first for updating profile");
        }

        // Navigator.pop(context);
      },
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.all(fixPadding * 1.4),
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [buttonShadow],
        ),
        alignment: Alignment.center,
        child: Text(
          getTranslation(context, 'edit_profile.update'),
          style: bold18LightBlack,
        ),
      ),
    );
  }

  emailField(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          getTranslation(context, 'edit_profile.email_address'),
          style: semibold16LightBlack,
        ),
        heightSpace,
        Container(
          width: double.maxFinite,
          decoration: BoxDecoration(
            color: whiteColor,
            boxShadow: [boxShadow],
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Theme(
            data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
            child: TextFormField(
              readOnly: true,
              controller: authProvider.emailAddressController,
              cursorColor: primaryColor,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 2),
                border: InputBorder.none,
                hintText: getTranslation(context, 'edit_profile.enter_email_address'),
                hintStyle: semibold15Grey,
              ),
            ),
          ),
        ),
      ],
    );
  }

  nameField(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          // getTranslation(context, 'edit_profile.name'),
          "User Name",
          style: semibold16LightBlack,
        ),
        heightSpace,
        Container(
          width: double.maxFinite,
          decoration: BoxDecoration(
            color: whiteColor,
            boxShadow: [boxShadow],
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Theme(
            data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
            child: TextFormField(
              controller: authProvider.userNameController,
              cursorColor: primaryColor,
              keyboardType: TextInputType.name,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 2),
                border: InputBorder.none,
                hintText: getTranslation(context, 'edit_profile.enter_name'),
                hintStyle: semibold15Grey,
              ),
            ),
          ),
        ),
      ],
    );
  }

  mobileField(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          getTranslation(context, 'edit_profile.mobile_number'),
          style: semibold16LightBlack,
        ),
        heightSpace,
        Container(
          width: double.maxFinite,
          decoration: BoxDecoration(
            color: whiteColor,
            boxShadow: [boxShadow],
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Theme(
            data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
            child: TextFormField(
              readOnly: true,
              controller: authProvider.phoneNumberController,
              cursorColor: primaryColor,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(vertical: fixPadding * 1.5, horizontal: fixPadding * 2),
                border: InputBorder.none,
                hintText: getTranslation(context, 'edit_profile.enter_mobile_number'),
                hintStyle: semibold15Grey,
              ),
            ),
          ),
        ),
      ],
    );
  }

  userProfileImage(Size size) {
    return Center(
      child: SizedBox(
        height: size.height * 0.155,
        width: size.height * 0.15,
        child: Stack(
          children: [
            Consumer<AuthProvider>(
              builder: (context, authProvider, child) {
                if (authProvider.pickedImagePath == "") {
                  return Container(
                    height: size.height * 0.15,
                    width: size.height * 0.15,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                        image: NetworkImage((authProvider.userModel.profileImgUrl != null && authProvider.userModel.profileImgUrl != "")
                            ? authProvider.userModel.profileImgUrl ?? ""
                            : "https://media.istockphoto.com/id/1300845620/vector/user-icon-flat-isolated-on-white-background-user-symbol-vector-illustration.jpg?s=612x612&w=0&k=20&c=yBeyba0hUkh14_jgv1OKqIH0CCSWU_4ckRkAoy2p73o="),
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                } else {
                  return Container(
                    height: size.height * 0.15,
                    width: size.height * 0.15,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(100),
                      child: Image.file(
                        File(authProvider.pickedImagePath ?? ""),
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                }
              },
            ),
            languageValue == 4
                ? Positioned(
                    bottom: 0,
                    left: 0,
                    child: GestureDetector(
                      onTap: () {
                        changePhotoBottomSheet(size);
                      },
                      child: Container(
                        height: size.height * 0.045,
                        width: size.height * 0.045,
                        decoration: BoxDecoration(
                          color: whiteColor,
                          shape: BoxShape.circle,
                          boxShadow: [boxShadow],
                        ),
                        alignment: Alignment.center,
                        child: const Icon(
                          Icons.camera_alt_outlined,
                          size: 18,
                          color: lightBlackColor,
                        ),
                      ),
                    ),
                  )
                : Positioned(
                    bottom: 0,
                    right: 0,
                    child: GestureDetector(
                      onTap: () {
                        changePhotoBottomSheet(size);
                      },
                      child: Container(
                        height: size.height * 0.045,
                        width: size.height * 0.045,
                        decoration: BoxDecoration(
                          color: whiteColor,
                          shape: BoxShape.circle,
                          boxShadow: [boxShadow],
                        ),
                        alignment: Alignment.center,
                        child: const Icon(
                          Icons.camera_alt_outlined,
                          size: 18,
                          color: lightBlackColor,
                        ),
                      ),
                    ),
                  )
          ],
        ),
      ),
    );
  }

  changePhotoBottomSheet(Size size) {
    return showModalBottomSheet(
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      context: context,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(fixPadding * 2.0),
          decoration: const BoxDecoration(
            color: whiteColor,
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(40.0),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                getTranslation(context, 'edit_profile.change_photo'),
                style: bold18LightBlack,
              ),
              heightSpace,
              heightSpace,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  imageChangeOption(context, size, Icons.camera_alt, getTranslation(context, 'edit_profile.camera'), const Color(0xFF1E4799), () {
                    Navigator.of(context).pop();

                    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
                    authProvider.pickImageForProfile(context, ImageSource.camera);
                  }),
                  imageChangeOption(context, size, Icons.photo, getTranslation(context, 'edit_profile.gallery'), const Color(0xFF1E996D), () {
                    Navigator.of(context).pop();
                    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
                    authProvider.pickImageForProfile(context, ImageSource.gallery);
                  }),
                  imageChangeOption(context, size, CupertinoIcons.delete_solid, getTranslation(context, 'edit_profile.remove_image'), const Color(0xFFEF1717), () {
                    Navigator.of(context).pop();
                  }),
                ],
              )
            ],
          ),
        );
      },
    );
  }

  imageChangeOption(BuildContext context, Size size, icon, title, color, Function() onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            height: size.height * 0.07,
            width: size.height * 0.07,
            decoration: BoxDecoration(
              color: whiteColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: blackColor.withOpacity(0.25),
                  blurRadius: 6,
                )
              ],
            ),
            alignment: Alignment.center,
            child: Icon(
              icon,
              color: color,
            ),
          ),
          heightSpace,
          Text(
            title,
            style: medium15LightBlack,
            overflow: TextOverflow.ellipsis,
          )
        ],
      ),
    );
  }
}
