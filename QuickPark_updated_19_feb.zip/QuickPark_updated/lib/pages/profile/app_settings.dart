import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart' as auth_package;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/app_setting_model.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/my_logger.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:provider/provider.dart';

import '../../theme/theme.dart';

class AppSettingsScreen extends StatefulWidget {
  const AppSettingsScreen({super.key});

  @override
  State<AppSettingsScreen> createState() => _AppSettingsScreenState();
}

class _AppSettingsScreenState extends State<AppSettingsScreen> {
  @override
  void initState() {
    // loadAppSetting();
    super.initState();
  }

  loadAppSetting() async {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
    setState(() {
      isLoading = true;
    });
    await ffstore
        .collection(collectionUsers) //
        .doc(authProvider.userModel.uid)
        .collection(collectionAppSetting)
        .doc(collectionAppSetting)
        .get()
        .then((value) {
      if (value.exists) {
        AppSettingModel appSettingModel = AppSettingModel.fromJson(value.data() as Map<String, dynamic>);
        setState(() {
          notificationValue = appSettingModel.notification ?? true;
          isLoading = false;
        });
      } else {
        errorLog("Something Wrong HA");
      }
    });
  }

  bool isLoading = false;
  bool notificationValue = true;
  bool locationValue = true;
  bool updateValue = true;
  bool themeValue = false;

  @override
  Widget build(BuildContext context) {
    auth_package.User? user = auth_package.FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: scaffoldBgColor,
        titleSpacing: 0.0,
        shadowColor: shadowColor.withOpacity(0.25),
        foregroundColor: lightBlackColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
        title: Text(
          getTranslation(context, 'app_settings.app_settings'),
          style: bold18LightBlack,
        ),
      ),
      body: isLoading == true
          ? circularProgress()
          : ListView(
              padding: const EdgeInsets.all(fixPadding * 2.0),
              physics: const BouncingScrollPhysics(),
              children: [
                /*settingWidget(
                  getTranslation(context, 'app_settings.notification'),
                  notificationValue,
                  (value) async {
                    setState(() {
                      notificationValue = !notificationValue!;
                    });

                    await ffstore.collection(collectionUsers).doc().collection("AppSetting").doc("").update({});
                  },
                ),*/

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            getTranslation(context, 'app_settings.notification'),
                            style: semibold16Black,
                          ),
                        ),
                        CupertinoSwitch(
                            activeColor: primaryColor,
                            trackColor: const Color(0xFFB7B7B7),
                            value: notificationValue,
                            onChanged: (value) {
                              notificationValue = value;
                              setState(() {});
                            }
                            /*user != null
                              ? (value) async {
                                  setState(() {
                                    notificationValue = !notificationValue;
                                  });
                                  AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
                                  await ffstore
                                      .collection(collectionUsers)
                                      .doc(authProvider.userModel.uid)
                                      .collection(collectionAppSetting)
                                      .doc(collectionAppSetting)
                                      .update({
                                    "notification": notificationValue,
                                    "createdAt": DateTime.now().millisecondsSinceEpoch,
                                  });

                                  String? token = await fcm.getToken();
                                  String? apnsToken = await fcm.getAPNSToken();
                                  if (notificationValue == true) {
                                    await ffstore.collection(collectionUsers).doc(authProvider.userModel.uid).update(
                                      {
                                        "fcmToken": Platform.isAndroid ? token : apnsToken,
                                        "deviceType": Platform.isAndroid ? "android" : "ios",
                                      },
                                    );
                                  } else {
                                    await ffstore.collection(collectionUsers).doc(authProvider.userModel.uid).update(
                                      {
                                        "fcmToken": "",
                                        "deviceType": Platform.isAndroid ? "android" : "ios",
                                      },
                                    );
                                  }
                                }
                              : (value) {
                                  Utils.errorToast("Please login for updating notification setting");
                                },*/

                            )
                      ],
                    ),
                    height5Space,
                    Text(
                      "Notification setting",
                      style: semibold14Grey,
                    )
                  ],
                ),
                heightSpace,
                heightSpace,
                /* settingWidget(
          getTranslation(context, 'app_settings.location'),
          locationValue,
          (value) {
            setState(() {
              locationValue = !locationValue;
            });
          },
        ),
        heightSpace,
        heightSpace,
        settingWidget(
          getTranslation(context, 'app_settings.application_update'),
          updateValue,
          (value) {
            setState(() {
              updateValue = !updateValue;
            });
          },
        ),
        heightSpace,
        heightSpace,
        settingWidget(
          getTranslation(context, 'app_settings.dark_mode'),
          themeValue,
          (value) {
            setState(() {
              themeValue = !themeValue;
            });
          },
        ),*/
              ],
            ),
    );
  }

  settingWidget(title, switchvalue, Function(bool) onChange) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: semibold16Black,
              ),
            ),
            CupertinoSwitch(
              activeColor: primaryColor,
              trackColor: const Color(0xFFB7B7B7),
              value: switchvalue,
              onChanged: onChange,
            )
          ],
        ),
        height5Space,
        Text(
          "Lorem ipsum dolor sit amet, consectetur adipiscing Senectus pellentesque justo, quis varius dictumst ",
          style: semibold14Grey,
        )
      ],
    );
  }
}
