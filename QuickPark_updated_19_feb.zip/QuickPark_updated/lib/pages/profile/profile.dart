import 'package:firebase_auth/firebase_auth.dart' as auth_package;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/pages/auth/login.dart';
import 'package:parkingproject/pages/chat/chat_heads.dart';
import 'package:parkingproject/pages/profile/app_settings.dart';
import 'package:parkingproject/pages/profile/my_vehicle.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:provider/provider.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    auth_package.User? user = auth_package.FirebaseAuth.instance.currentUser;
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: scaffoldBgColor,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          getTranslation(context, 'profile.profile'),
          style: bold20LightBlack,
        ),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.zero,
        children: [
          Container(
            color: const Color(0xFFE8E6E6),
            padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding * 1.4),
            width: double.maxFinite,
            child: Row(
              children: [
                Consumer<AuthProvider>(
                  builder: (context, authProvider, child) {
                    return Container(
                      height: size.height * 0.13,
                      width: size.height * 0.13,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          image: NetworkImage((authProvider.userModel.profileImgUrl != null && authProvider.userModel.profileImgUrl != "")
                              ? authProvider.userModel.profileImgUrl ?? ""
                              : "https://media.istockphoto.com/id/1300845620/vector/user-icon-flat-isolated-on-white-background-user-symbol-vector-illustration.jpg?s=612x612&w=0&k=20&c=yBeyba0hUkh14_jgv1OKqIH0CCSWU_4ckRkAoy2p73o="),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                ),
                widthSpace,
                widthSpace,
                user != null
                    ? Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Consumer<AuthProvider>(
                              builder: (context, provider, child) {
                                return Text(
                                  provider.userModel.userName ?? "User not logged in",
                                  style: bold16LightBlack,
                                );
                              },
                            ),
                            height5Space,
                            Consumer<AuthProvider>(
                              builder: (context, provider, child) {
                                return Text(
                                  provider.userModel.emailAddress ?? " ",
                                  style: bold14Grey,
                                );
                              },
                            ),
                            height5Space,
                            GestureDetector(
                              onTap: () {
                                auth_package.User? user = auth_package.FirebaseAuth.instance.currentUser;
                                if (user != null) {
                                  Navigator.pushNamed(context, '/editProfile');
                                } else {
                                  Utils.errorToast("Please login first for editing profile !");
                                }
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: fixPadding * 0.7, horizontal: fixPadding * 2.0),
                                decoration: BoxDecoration(
                                  color: primaryColor,
                                  borderRadius: BorderRadius.circular(5.0),
                                ),
                                child: Text(
                                  getTranslation(context, 'profile.edit_profile'),
                                  style: bold16LightBlack,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    : Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Consumer<AuthProvider>(
                              builder: (context, provider, child) {
                                return Text(
                                  "User not logged in",
                                  style: bold16LightBlack,
                                );
                              },
                            ),
                          ],
                        ),
                      )
              ],
            ),
          ),
          heightSpace,

          /* ElevatedButton(
            onPressed: () {
              // pageNavigator(context, AllParkingPage());
            },
            child: Text("All Parking Stream "),
          ),*/

          /* ElevatedButton(
            onPressed: () async {
              String documentID = const Uuid().v4();

              await ffstore.collection(collectionSlots).doc(documentID).set({"totalSlots": 10});

              for (int index = 1; index <= 10; index++) {
                await ffstore
                    .collection(collectionSlots) //
                    .doc(documentID)
                    .collection(documentID)
                    .doc("Slot$index")
                    .set({
                  "slotName": "Slot $index",
                  "status": "available",
                });
              }
            },
            child: Text("Testing"),
          ),*/

          ///
          /*
          ElevatedButton(
              onPressed: () async {
                AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);

                String id = Uuid().v4();

                NotificationModel notificationModel = NotificationModel(
                  createdAt: DateTime.now().millisecondsSinceEpoch,
                  title: "Booked Parking",
                  description: "Someone booked parking",
                  userName: "${authProvider.userModel.firstName} ${authProvider.userModel.lastName}",
                  type: "BookingCancel",
                  userId: authProvider.userModel.uid,
                  toSendID: authProvider.userModel.uid,
                  notificationType: NotificationType.bookedParking.name,
                  parkingStartDateTime: DateTime.now().millisecondsSinceEpoch,
                  isSentStartNotification: false,
                  isSentEndNotification: false,
                  parkingEndDateTime: DateTime.now().add(Duration(days: 5)).millisecondsSinceEpoch,
                );
                await ffstore.collection(collectionNotifications).doc(id).set(notificationModel.toJson());
              },
              child: Text("Send Notification ")),
          ElevatedButton(
              onPressed: () {
                // pageNavigator(context, LoginScreen());

                print(NotificationType.bookedParking.name);
              },
              child: Text("login page ha")),
          ElevatedButton(
              onPressed: () {
                // Get the user's local time zone offset
                DateTime currentDatTme = DateTime.now();
                log("currentDatTme $currentDatTme");
                log("currentDatTme.timeZoneOffset ${currentDatTme.timeZoneOffset}");

                Duration offset = currentDatTme.timeZoneOffset;
                log("offset $offset");

                // Calculate the user's local time based on the time zone offset
                //             DateTime userLocalTime = gstDateTime.add(offset);
              },
              child: Text("Time Related Query ")),
          ElevatedButton(
              onPressed: () async {
                final authProvider = Provider.of<AuthProvider>(context, listen: false);
                String id = Uuid().v4();

                log("${FieldValue.serverTimestamp()}");

                DateTime userDateTime = DateTime.now();
                Duration offset = userDateTime.timeZoneOffset;
                // DateTime userLocalTime = gstDateTime.add(offset);

                NotificationModel notificationModel = NotificationModel(
                  createdAt: DateTime.now().millisecondsSinceEpoch,
                  title: "Booking Cancel",
                  description: "Someone cancel their booking",
                  userName: authProvider.userModel.firstName,
                  type: "BookingCancel",
                  userId: authProvider.userModel.uid,
                  toSendID: "",
                  parkingStartDateTime: DateTime.now().add(offset).millisecondsSinceEpoch,
                );
                await ffstore.collection(collectionNotifications).doc(id).set(notificationModel.toJson());
              },
              child: Text("Time Related Query ")),

          */

          // ElevatedButton(
          //   onPressed: () {
          //     pageNavigator(context, const ApplyFilterPage());
          //   },
          //   child: const Text("Filter page "),
          // ),

          /*
          ElevatedButton(
              onPressed: () async {
                await Permission.location.request();
              },
              child: Text("Request Permission ")),
          */

          ///
          ///
          /*   ElevatedButton(
            onPressed: () async {
              // pageNavigator(context, const AllUserPage());

              //+START PARKING TIME RELATED
              await ffstore.collection(collectionBooking).where("isSentStartNotification", isEqualTo: false).get().then((value) {
                value.docs.forEach((element) async {
                  log("********************");

                  BookingModel bookingModel = BookingModel.fromJson(element.data());
                  log("bookingModel.parkingStartDate ${bookingModel.parkingStartDate}");

                  final parkingStartDate = DateTime.fromMillisecondsSinceEpoch(bookingModel.parkingStartDate ?? DateTime.now().millisecondsSinceEpoch);
                  log("parkingStartDate $parkingStartDate");

                  final currentDateTime = DateTime.now().millisecondsSinceEpoch;
                  log("currentDateTime  ${DateTime.fromMillisecondsSinceEpoch(currentDateTime)}");

                  final difference = parkingStartDate.difference(DateTime.fromMillisecondsSinceEpoch(currentDateTime));
                  log("isNegative Difference ${difference.isNegative}");
                  log("Difference inMinutes : ${difference.inMinutes}");
                  log("Difference inDays : ${difference.inDays}");

                  bool check = DateTime.now().isBefore(DateTime.fromMillisecondsSinceEpoch(bookingModel.parkingStartDate ?? DateTime.now().millisecondsSinceEpoch));
                  log("Check value : $check");

                  log("Compare value ${difference.inMinutes} &&  15");
                  if (check == true && difference.inMinutes < 15) {
                    log("inside if ");
                  } else {
                    log("inside else part");
                    log("Nothing to do");
                  }
                  //+END Parking Date Time Handling
                });
              });

              //+END
              await ffstore.collection(collectionBooking).get().then((value) {
                value.docs.forEach((element) {
                  log("********************");

                  BookingModel bookingModel = BookingModel.fromJson(element.data());
                  log("bookingModel.parkingEndDate ${bookingModel.parkingEndDate}");
                  final parkingEndDate = DateTime.fromMillisecondsSinceEpoch(bookingModel.parkingEndDate ?? DateTime.now().millisecondsSinceEpoch);
                  log("parkingEndDate   $parkingEndDate");

                  final currentDateTime = DateTime.now().millisecondsSinceEpoch;
                  log("currentDateTime  ${DateTime.fromMillisecondsSinceEpoch(currentDateTime)}");

                  final difference = parkingEndDate.difference(DateTime.fromMillisecondsSinceEpoch(currentDateTime));
                  log("isNegative Difference ${difference.isNegative}");
                  log("Difference inMinutes : ${difference.inMinutes}");
                  log("Difference inHours : ${difference.inHours}");
                  log("Difference inDays : ${difference.inDays}");

                  bool check = DateTime.now().isBefore(DateTime.fromMillisecondsSinceEpoch(bookingModel.parkingEndDate ?? DateTime.now().millisecondsSinceEpoch));
                  log("Check value : $check");
                  //check == true &&
                  log("Compare value ${difference.inMinutes} &&  30");
                  if ((check == true && difference.inMinutes < 30)) {
                    //now adding notification
                    log("inside if ");
                  } else {
                    log("inside else part");
                  }
                });
              });
            },
            child: const Text("All User  "),
          ),*/

          ///

          // profileListTile("Dialog OPEN", Icons.account_balance_wallet_outlined, () {
          //   openDialog(onPressed: () {}, title: "");
          // }, isWallet: true),
          // profileListTile("Test Page", Icons.account_balance_wallet_outlined, () {
          //   pageNavigator(context, TestPage());
          // }, isWallet: true),
          // profileListTile("Test Page second ", Icons.account_balance_wallet_outlined, () {
          //   pageNavigator(context, const MapView());
          // }, isWallet: true),
          user != null
              ? profileListTile(getTranslation(context, 'profile.wallet'), Icons.account_balance_wallet_outlined, () {
                  Navigator.pushNamed(context, '/wallet');
                }, isWallet: true)
              : SizedBox(),
          user != null
              ? profileListTile(getTranslation(context, 'profile.my_vehicle'), Icons.directions_car_filled_outlined, () {
                  pageNavigator(context, MyVehicleScreen());

                  // Navigator.pushNamed(context, '/myVehicle');
                })
              : SizedBox(),

          user != null
              ? profileListTile("Chats", Icons.chat, () {
                  pageNavigator(context, ChatHeads());
                })
              : SizedBox(),

          profileListTile(getTranslation(context, 'profile.help_support'), Icons.help_outline_rounded, () {
            Navigator.pushNamed(context, '/helpAndSupport');
          }),
          profileListTile(getTranslation(context, 'profile.privacy_policy'), Icons.privacy_tip_outlined, () {
            Navigator.pushNamed(context, '/privacyPolicy');
          }),
          profileListTile(getTranslation(context, 'profile.terms_condition'), Icons.list_alt_rounded, () {
            Navigator.pushNamed(context, '/termsCondition');
          }),
          profileListTile(getTranslation(context, 'profile.language'), CupertinoIcons.globe, () {
            Navigator.pushNamed(context, '/languages');
          }),
          profileListTile(getTranslation(context, 'profile.app_settings'), CupertinoIcons.gear_alt, () {
            pageNavigator(context, AppSettingsScreen());
          }),
          // profileListTile(getTranslation(context, 'profile.logout'), Icons.logout, () {}, color: redColor),

          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
            minLeadingWidth: 0,
            leading: Icon(
              Icons.logout,
              color: user != null ? redColor : greenColor,
              size: 22,
            ),
            title: Text(
              user != null ? getTranslation(context, 'profile.logout') : "Log in",
              style: bold16LightBlack.copyWith(
                color: user != null ? redColor : greenColor,
              ),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                widthSpace,
                Icon(
                  Icons.arrow_forward_ios,
                  size: 19,
                  color: lightBlackColor,
                ),
              ],
            ),
            onTap: user != null
                ? () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return Dialog(
                          backgroundColor: Colors.white,
                          insetPadding: const EdgeInsets.all(fixPadding * 2.0),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                          child: Padding(
                            padding: const EdgeInsets.all(fixPadding * 2.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  getTranslation(context, 'profile.logout'),
                                  style: bold18Red,
                                ),
                                heightSpace,
                                Text(
                                  getTranslation(context, 'profile.sure_text'),
                                  style: semibold18LightBlack,
                                  textAlign: TextAlign.center,
                                ),
                                heightSpace,
                                heightSpace,
                                Row(
                                  children: [
                                    Expanded(
                                      child: buttonWidget(
                                        getTranslation(context, 'profile.no'),
                                        () {
                                          Navigator.pop(context);
                                        },
                                        whiteColor,
                                        textColor,
                                      ),
                                    ),
                                    widthSpace,
                                    widthSpace,
                                    Expanded(
                                      child: buttonWidget(
                                        getTranslation(context, 'profile.yes_logout'),
                                        () async {
                                          Navigator.of(context).pop();
                                          AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
                                          authProvider.clearControllers();
                                          await auth.signOut();

                                          Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (BuildContext context) {
                                            return const LoginScreen();
                                          }), (route) => false);
                                        },
                                        primaryColor,
                                        lightBlackColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  }
                : () {
                    pageNavigator(context, LoginScreen());
                  },
          ),

          heightSpace,
        ],
      ),
    );
  }

  buttonWidget(String title, Function() onTap, Color color, Color textColor) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 1.2),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [boxShadow],
          color: color,
        ),
        child: Text(
          title,
          style: bold18TextColor.copyWith(color: textColor),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }

  profileListTile(title, icon, Function() onTap, {bool isWallet = false, Color color = lightBlackColor}) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
      onTap: onTap,
      minLeadingWidth: 0,
      leading: Icon(
        icon,
        color: color,
        size: 22,
      ),
      title: Text(
        title,
        style: bold16LightBlack.copyWith(color: color),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          isWallet == true
              ? Text(
                  "\$500",
                  style: bold16Green,
                )
              : const SizedBox(),
          widthSpace,
          const Icon(
            Icons.arrow_forward_ios,
            size: 19,
            color: lightBlackColor,
          ),
        ],
      ),
    );
  }
}
