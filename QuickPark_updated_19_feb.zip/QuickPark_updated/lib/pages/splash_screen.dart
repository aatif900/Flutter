import 'dart:async';
import 'dart:developer';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/pages/auth/phone_number_page.dart';
import 'package:parkingproject/pages/bottomNavigationBar/bottom_navigation_bar.dart';
import 'package:parkingproject/pages/onboarding/onboarding.dart';
import 'package:parkingproject/provider/auth_provider.dart' as auth_provider;
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:provider/provider.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    log("Splash Screen page");
    handleSignIn();
    super.initState();
  }

  handleSignIn() async {
    log("inside  handleSignIn");
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    final authProvider = Provider.of<auth_provider.AuthProvider>(context, listen: false);

    homeProvider.getCurrentLocation();
    log("timer start");
    Timer(const Duration(seconds: 1), () async {
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        await updateFCMToken();
        authProvider.initializeUserModel(user.uid);

        await ffstore.collection(collectionUsers).doc(user.uid).get().then((value) {
          if (value.exists) {
            UserModel userModel = UserModel.fromJson(value.data() as Map<String, dynamic>);
            log("userModel.isPhoneLinked ${userModel.isPhoneLinked}");
            if (userModel.isPhoneLinked == true) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (BuildContext context) => const BottomBar()), (route) => false);
            } else {
              print("else part ha");
              pageNavigator(context, PhoneNumberScreen());
            }
          } else {
            Utils.errorToast("No user found for that email");
          }
        });
      } else {
        pageNavigator(context, OnBoardingScreen());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Image.asset(
                "assets/splash/car.png",
                height: size.height * 0.35,
                width: double.maxFinite,
                fit: BoxFit.fill,
              ),
            ],
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                stops: const [0.6, 0.7, 0.8, 1.0],
                colors: [
                  primaryColor,
                  primaryColor.withOpacity(0.8),
                  primaryColor.withOpacity(0.6),
                  whiteColor.withOpacity(0),
                ],
              ),
            ),
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  "assets/splash/icon-park-outline_parking.png",
                  height: 50,
                  width: 50,
                ),
                heightSpace,
                Text(
                  "Quick parking",
                  style: semibold26Black,
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
