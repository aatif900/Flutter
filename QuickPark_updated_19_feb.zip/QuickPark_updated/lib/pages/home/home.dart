// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:developer';
import 'dart:math' show cos, sqrt, asin;

import 'package:dotted_border/dotted_border.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_place/google_place.dart';
import 'package:parkingproject/constants/key.dart';
import 'package:parkingproject/generated/assets.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/pages/auth/login.dart';
import 'package:parkingproject/pages/booking/select_vehicle.dart';
import 'package:parkingproject/pages/filter/apply_filter_page.dart';
import 'package:parkingproject/pages/home/home_detail.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/provider/booking_provider.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../theme/theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  PageController pageController = PageController(viewportFraction: 0.9, initialPage: 1);
  Completer<GoogleMapController> googleMapCompleterController = Completer();

  double _currPageValue = 1.0;
  double scaleFactor = .8;
  double height = 150;

  String _sessionToken = '1234567890';

  // final TextEditingController searchTextEditingController = TextEditingController();
  late GooglePlace googlePlace;
  var uuid = const Uuid();

  // List<AutocompletePrediction> predictionsList = List<AutocompletePrediction>.from([]);
  double? lat = 0.0;
  double? lng = 0.0;
  String location = "Location Name:";

  late StreamSubscription<bool> keyboardSubscription;

  @override
  void initState() {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

    callAwaitFunction();
    var keyboardVisibilityController = KeyboardVisibilityController();
    keyboardSubscription = keyboardVisibilityController.onChange.listen((bool visible) {});

    pageController.addListener(() {
      setState(() {
        _currPageValue = pageController.page!;
      });
    });
    //! OTHER
    googlePlace = GooglePlace(googleMapApiKey);
    homeProvider.searchTextEditingController.addListener(() {
      //+COMMENTING HERE PLEASE UNCOMMENT IT LATER
      // _onChanged();
    });

    super.initState();
  }

  callAwaitFunction() async {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      homeProvider.getDataFromFirebase();
    });
    // setStateIfMounted(() async {});
    await homeProvider.getCurrentLocation();
  }

  void setStateIfMounted(f) {
    if (mounted) setState(f);
  }

  _onChanged() {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

    if (_sessionToken == null) {
      setState(() {
        _sessionToken = uuid.v4();
      });
    }
    if (homeProvider.searchTextEditingController.text.isNotEmpty) {
      autoCompletePickUpSearch(homeProvider.searchTextEditingController.text);
    }
  }

  void autoCompletePickUpSearch(String value) async {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    log("searching autoCompletePickUpSearch ");
    var result = await googlePlace.autocomplete.get(value);
    if (result != null && result.predictions != null && mounted) {
      log(result.predictions!.first.description.toString());
      log("inside autoCompletePickUp Search ${result.predictions!.first.description.toString()}");

      homeProvider.addPredictionToList(result.predictions!);
    }
  }

  double _coordinateDistance(lat1, lon1, lat2, lon2) {
    var p = 0.017453292519943295;
    var c = cos;
    var a = 0.5 - c((lat2 - lat1) * p) / 2 + c(lat1 * p) * c(lat2 * p) * (1 - c((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a));
  }

  @override
  Widget build(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          //+GOOGLE MAP
          Consumer<HomeProvider>(
            builder: (context, provider, child) {
              return GoogleMap(
                mapType: MapType.normal,
                zoomControlsEnabled: false,
                initialCameraPosition: const CameraPosition(target: LatLng(31.53072810842491, 74.35096582519736), zoom: 14),
                markers: Set.from(homeProvider.allMarkers),
                // onMapCreated: mapCreated,
                onMapCreated: (GoogleMapController controller) async {
                  setState(() {
                    googleMapCompleterController.complete(controller);
                  });
                  homeProvider.googleMapController = controller;

                  log("inside onMapCreated ${homeProvider.currentLatLng?.latitude}");
                  log("inside onMapCreated  ${homeProvider.currentLatLng?.longitude}");

                  WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
                    // final GoogleMapController googleMapController1 = await homeProvider.googleMapCompleterController.future;
                    homeProvider.googleMapController?.animateCamera(
                      CameraUpdate.newLatLng(
                          LatLng(homeProvider.currentLatLng?.latitude ?? 31.52120082063814, homeProvider.currentLatLng?.longitude ?? 74.35851966242862)),
                    );
                    homeProvider.allMarkers.removeWhere((marker) => marker.mapsId.value == 'locationMarker');
                    homeProvider.addMarkerInList(
                      Marker(
                        markerId: const MarkerId("locationMarker"),
                        position: LatLng(homeProvider.currentLatLng?.latitude ?? 31.52120082063814, homeProvider.currentLatLng?.longitude ?? 74.35851966242862),
                        icon: BitmapDescriptor.fromBytes(await Utils.getBytesFromAsset(Assets.homeCar, 70)),
                        infoWindow: const InfoWindow(title: "Location"),
                      ),
                    );
                  });
                },
              );
            },
          ),
          KeyboardVisibilityBuilder(builder: (context, visible) {
            return visible ? const SizedBox() : parkingListContent(size);
          }),
          // parkingListContent(size),
          //+topGradient,
          Container(
            height: 125,
            width: double.maxFinite,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                stops: const [0.6, 1.0],
                colors: [const Color(0xFFF4F4F4).withOpacity(0.8), const Color(0xFFB4B4B4).withOpacity(0)],
              ),
            ),
          ),
          //+User Details WIth Search Field
          Padding(
            // padding: const EdgeInsets.only(left: fixPadding * 2.0, right: fixPadding * 2.0, top: fixPadding * 3.5),
            padding: const EdgeInsets.only(left: 10, right: 10, top: fixPadding * 3.5),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          image: NetworkImage((authProvider.userModel.profileImgUrl != null && authProvider.userModel.profileImgUrl != "")
                              ? authProvider.userModel.profileImgUrl ?? ""
                              : "https://media.istockphoto.com/id/1300845620/vector/user-icon-flat-isolated-on-white-background-user-symbol-vector-illustration.jpg?s=612x612&w=0&k=20&c=yBeyba0hUkh14_jgv1OKqIH0CCSWU_4ckRkAoy2p73o="),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    widthSpace,
                    widthSpace,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            authProvider.userModel.userName != null ? authProvider.userModel.userName ?? "" : "User not logged in",
                            style: bold18LightBlack,
                          ),
                          Text(
                            getTranslation(context, 'extend_parking_time.find'),
                            style: semibold14Grey.copyWith(
                              color: const Color(0xFF8E8E8E),
                            ),
                          )
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, '/notification');
                      },
                      child: Container(
                        height: 24,
                        width: 24,
                        alignment: Alignment.center,
                        child: Image.asset(
                          "assets/home/notification.png",
                          height: 20,
                          width: 20,
                        ),
                      ),
                    )
                  ],
                ),
                heightSpace,

                //+Search Field
                Container(
                  margin: const EdgeInsets.only(left: 0, right: 0),
                  height: 250,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      //+OLD SEARCH FIELD
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              width: double.maxFinite,
                              decoration: BoxDecoration(
                                color: whiteColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: blackColor.withOpacity(0.25),
                                    blurRadius: 6,
                                  ),
                                ],
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Theme(
                                data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: primaryColor)),
                                child: TextField(
                                  controller: homeProvider.searchTextEditingController,
                                  style: bold16LightBlack,
                                  cursorColor: primaryColor,
                                  onChanged: (value) {
                                    homeProvider.onSearchChanged(value);
                                  },
                                  decoration: InputDecoration(
                                      contentPadding: const EdgeInsets.symmetric(vertical: fixPadding, horizontal: fixPadding * 1.2),
                                      border: InputBorder.none,
                                      prefixIcon: const Icon(
                                        Icons.search,
                                        size: 20,
                                      ),
                                      suffixIcon: IconButton(
                                        onPressed: () {
                                          // filterBottomSheet(size, context);

                                          // pageNavigator(context, const ApplyFilterPage());
                                          homeProvider.searchTextEditingController.clear();
                                          homeProvider.predictionsList.clear();
                                          setState(() {});
                                        },
                                        /*icon: const Icon(
                                          Icons.filter_list_outlined,
                                          color: lightBlackColor,
                                        ),*/
                                        icon: const Icon(
                                          Icons.cancel,
                                          color: lightBlackColor,
                                        ),
                                      ),
                                      hintText: getTranslation(context, 'extend_parking_time.search'),
                                      hintStyle: bold15Grey),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 5),
                          Container(
                            height: 45,
                            // padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
                            decoration: BoxDecoration(
                              color: whiteColor,
                              borderRadius: BorderRadius.circular(10.0),
                              boxShadow: [
                                BoxShadow(
                                  color: blackColor.withOpacity(0.25),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                            child: IconButton(
                              onPressed: () {
                                pageNavigator(context, const ApplyFilterPage());
                              },
                              icon: const Icon(
                                Icons.filter_list_outlined,
                                color: lightBlackColor,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 0),

                      //+Result COMMENTED
                      /*    Consumer<HomeProvider>(
                        builder: (context, provider, child) {
                          if (homeProvider.predictionsList.isEmpty) {
                            return const SizedBox();
                          }
                          return Expanded(
                            child: Container(
                              margin: const EdgeInsets.only(top: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: kWhiteColor,
                                boxShadow: [
                                  BoxShadow(color: kBlackColor.withOpacity(0.16), offset: const Offset(0, 2), blurRadius: 6),
                                ],
                              ),
                              child: ListView.builder(
                                physics: const BouncingScrollPhysics(),
                                shrinkWrap: true,
                                // itemCount: predictions.length,
                                itemCount: homeProvider.predictionsList.length,
                                padding: const EdgeInsets.all(15),
                                itemBuilder: (context, index) {
                                  return GestureDetector(
                                    onTap: () async {
                                      //+ this is where we can either navigate to map or put a pin on the map on this same page and close the list

                                      hideKeyBoard(context);
                                      final placeId = homeProvider.predictionsList[index].placeId!;
                                      final details = await googlePlace.details.get(placeId);
                                      lat = details?.result?.geometry?.location?.lat ?? 0.0;
                                      lng = details?.result?.geometry?.location?.lng ?? 0.0;
                                      log("lat long are: $lat & lng: $lng");
                                      location = homeProvider.predictionsList[index].description ?? "";
                                      homeProvider.searchTextEditingController.text = homeProvider.predictionsList[index].description ?? "";

                                      homeProvider.googleMapController?.animateCamera(CameraUpdate.newLatLng(LatLng(lat ?? 0.0, lng ?? 0.0)));
                                      homeProvider.allMarkers.add(Marker(
                                        markerId: const MarkerId("locationMarker"),
                                        // markerId: MarkerId("${currentLocationCamera.latitude}"),
                                        position: LatLng(lat ?? 0.0, lng ?? 0.0),
                                        icon: BitmapDescriptor.fromBytes(await Utils.getBytesFromAsset("assets/home/parkingMarker.png", 70)),
                                        infoWindow: const InfoWindow(title: "Location"),
                                      ));

                                      homeProvider.clearPredictionsList();
                                      // Navigator.of(context).pop();
                                      // searchTextEditingController.clear();
                                      homeProvider.predictionsList.clear();

                                      setState(() {});

                                      // showLocationResults();
                                      log("at the end list length ${homeProvider.predictionsList.length}");
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.only(bottom: 10),
                                      child: Text(
                                        homeProvider.predictionsList[index].description ?? "",
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          );
                        },
                      ),*/

                      //+NEW FROM SALON APP
                      /* Consumer<HomeProvider>(
                        builder: (context, provider, child) {
                          if (homeProvider.getList.isNotEmpty) {
                            return Container(
                              decoration: const BoxDecoration(color: Colors.white),
                              child: Column(
                                children: [
                                  for (var item in homeProvider.getList)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                      child: InkWell(
                                        onTap: () {
                                          homeProvider.getLatLngFromAddress(item.description.toString());
                                        },
                                        child: Row(
                                          children: [
                                            const Icon(Icons.search),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              item.description!.length > 25 ? '${item.description!.substring(0, 25)}...' : item.description!,
                                            )
                                          ],
                                        ),
                                      ),
                                    )
                                ],
                              ),
                            );
                          }
                          return const SizedBox();
                        },
                      ),*/
                      //+WIth
                      Consumer<HomeProvider>(
                        builder: (context, provider, child) {
                          if (homeProvider.getList.isNotEmpty) {
                            return Expanded(
                              child: Container(
                                margin: const EdgeInsets.only(top: 10),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: kWhiteColor,
                                  boxShadow: [
                                    BoxShadow(color: kBlackColor.withOpacity(0.16), offset: const Offset(0, 2), blurRadius: 6),
                                  ],
                                ),
                                child: ListView.builder(
                                  physics: const BouncingScrollPhysics(),
                                  shrinkWrap: true,
                                  // itemCount: predictions.length,
                                  itemCount: homeProvider.getList.length,
                                  padding: const EdgeInsets.all(15),
                                  itemBuilder: (context, index) {
                                    return GestureDetector(
                                      onTap: () async {
                                        homeProvider.getLatLngFromAddress(homeProvider.getList[index].description.toString(), context);
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(bottom: 10),
                                        child: Row(
                                          children: [
                                            const Icon(Icons.search),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              homeProvider.getList[index].description!.length > 25
                                                  ? '${homeProvider.getList[index].description!.substring(0, 25)}...'
                                                  : homeProvider.getList[index].description!,
                                            )
                                          ],
                                        ),

                                        /*  Text(
                                        homeProvider.predictionsList[index].description ?? "",
                                      ),*/
                                      ),
                                    );
                                  },
                                ),
                              ),
                            );
                          }
                          return const SizedBox();
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  parkingListContent(Size size) {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

    return Positioned(
      left: 0,
      right: 0,
      bottom: fixPadding * 2,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.end,
        mainAxisSize: MainAxisSize.min,
        children: [
          //+ GPS BUTTON
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0, vertical: fixPadding),
            child: FloatingActionButton(
              onPressed: () {
                HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

                homeProvider.goToCurrentPosition(context);
              },
              mini: true,
              backgroundColor: const Color(0xFF494747),
              child: const Icon(
                Icons.my_location_sharp,
                color: whiteColor,
                size: 22,
              ),
            ),
          ),

          Consumer<HomeProvider>(
            builder: (context, provider, child) {
              if (homeProvider.allDataList.isEmpty) {
                return SizedBox();
              }
              return SizedBox(
                height: 180.0,
                width: size.width,
                child: PageView.builder(
                  physics: const BouncingScrollPhysics(),
                  onPageChanged: (index) {
                    homeProvider.allDataList.isNotEmpty ? moveCamera(homeProvider.allDataList[index].lat, homeProvider.allDataList[index].lng) : null;
                    // log("on page changed ${homeProvider.allDataList[index].lat}, ${homeProvider.allDataList[index].lng}");
                  },
                  controller: pageController,
                  // itemCount: parkingList.length,
                  itemCount: homeProvider.allDataList.length,
                  itemBuilder: (context, index) {
                    ParkingModel parkingModelValue = ParkingModel.fromJson(homeProvider.allDataList[index].toJson());

                    return _buildListContent(index, size, homeProvider.allDataList, parkingModelValue);
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  _buildListContent(int index, Size size, List<ParkingModel> list, ParkingModel parkingModel) {
    final HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

    /* Matrix4 matrix = Matrix4.identity();

    if (index == _currPageValue.floor()) {
      var currScale = 1 - (_currPageValue - index) * (1 - scaleFactor);
      var currTrans = height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1.0, currScale, 1.0)..setTranslationRaw(0.0, currTrans, 0.0);
    } else if (index == _currPageValue.floor() + 1) {
      var currScale = scaleFactor + (_currPageValue - index + 1) * (1 - scaleFactor);
      var currTrans = height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1.0, currScale, 1.0)..setTranslationRaw(0.0, currTrans, 0.0);
    } else if (index == _currPageValue.floor() - 1) {
      var currScale = 1 - (_currPageValue - index) * (1 - scaleFactor);
      var currTrans = height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1.0, currScale, 1.0)..setTranslationRaw(0.0, currTrans, 0.0);
    } else {
      var currScale = 0.8;
      matrix = Matrix4.diagonal3Values(1.0, currScale, 1.0)..setTranslationRaw(0.0, height * (1 - scaleFactor) / 2, 0.0);
    }*/
    return GestureDetector(
      onTap: () {},
      child: GestureDetector(
        onTap: () {
          // Navigator.pushNamed(context, '/detail');
          pageNavigator(context, DetailScreen(parkingModel: parkingModel));
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: fixPadding),
          margin: const EdgeInsets.symmetric(horizontal: fixPadding),
          decoration: BoxDecoration(
            color: whiteColor,
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: [buttonShadow],
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                child: Row(
                  children: [
                    Container(
                      height: size.width * 0.2,
                      width: size.width * 0.2,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.0),
                        boxShadow: [boxShadow],
                        image: DecorationImage(
                          image: NetworkImage(parkingModel.image.toString()),
                          fit: BoxFit.cover,
                        ),
                      ),
                      alignment: Alignment.bottomRight,
                      child: Container(
                        padding: const EdgeInsets.all(3.0),
                        decoration: const BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(5.0),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.star,
                              color: textColor,
                              size: 16,
                            ),
                            widthBox(3.0),
                            Text(
                              (parkingModel.rating.toString() == "0.1") ? "0.0" : parkingModel.rating.toString(),
                              style: semibold14LightBlack,
                            )
                          ],
                        ),
                      ),
                    ),
                    widthSpace,
                    width5Space,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            parkingModel.parkingName.toString(),
                            style: semibold18LightBlack,
                            overflow: TextOverflow.ellipsis,
                          ),
                          heightBox(3.0),
                          Text(
                            parkingModel.address.toString(),
                            style: semibold14Grey,
                            overflow: TextOverflow.ellipsis,
                          ),
                          heightBox(3.0),
                          Text.rich(
                            TextSpan(
                              text: "\$ ${parkingModel.priceHourly.toString()} ",
                              style: semibold16LightBlack,
                              children: [
                                TextSpan(
                                  text: getTranslation(context, 'extend_parking_time.per_hour'),
                                  style: semibold15Grey,
                                )
                              ],
                            ),
                            style: semibold14Grey,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              heightSpace,
              DottedBorder(
                padding: EdgeInsets.zero,
                color: greyD4Color,
                dashPattern: const [3],
                child: Container(),
              ),
              heightSpace,
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          //+OLD
                          Text.rich(
                            overflow: TextOverflow.ellipsis,
                            TextSpan(
                              text: "${getTranslation(context, 'extend_parking_time.distance_value')} : ",
                              style: medium14LightBlack,
                              children: [
                                TextSpan(
                                    text: (parkingModel.lat != null && parkingModel.lat != "" && parkingModel.lng != null && parkingModel.lng != "")
                                        ? (homeProvider.getDistance(double.parse(parkingModel.lat ?? "30.158702484783014"),
                                                    double.parse(parkingModel.lng ?? "71.52380700534404"), context) /
                                                1000)
                                            .toString()
                                        : "",

                                    /*( parkingModel.lat != null && parkingModel.lng != null)
                                        ? "${_coordinateDistance(
                                            double.parse(parkingModel.lat ?? "30.158702484783014"),
                                            double.parse(parkingModel.lng ?? "71.52380700534404"),
                                            homeProvider.currentLocation?.latitude,
                                            homeProvider.currentLocation?.longitude,
                                          ).toStringAsFixed(2)} ${getTranslation(context, 'extend_parking_time.min_walk')}"
                                        : "",*/

                                    style: semibold14LightBlack)
                              ],
                            ),
                          ),

                          /*  Text.rich(
                            overflow: TextOverflow.ellipsis,
                            TextSpan(
                              text: "",
                              style: medium14LightBlack,
                              children: [TextSpan(text: "", style: semibold14LightBlack)],
                            ),
                          ),*/

                          Text.rich(
                            TextSpan(text: "${getTranslation(context, 'extend_parking_time.slot_available')} : ", style: medium14LightBlack, children: [
                              TextSpan(
                                text: "${parkingModel.slot} ${getTranslation(context, 'extend_parking_time.slot')}".toString(),
                                style: semibold14LightBlack,
                              )
                            ]),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    width5Space,
                    //+Book Now Button
                    GestureDetector(
                      onTap: () async {
                        final bookingProvider = Provider.of<BookingProvider>(context, listen: false);
                        auth.User? currentUser = auth.FirebaseAuth.instance.currentUser;
                        log("current user $currentUser");

                        if (currentUser == null) {
                          pageNavigator(context, const LoginScreen());
                        } else {
                          bookingProvider.updateSelectedParkingModel(parkingModel);
                          pageNavigator(context, SelectVehicleScreen(parkingModel: parkingModel));

                          /* await ffstore.collection(collectionUsers).doc(currentUser.uid).get().then((value) async {
                            if (value.exists) {
                              UserModel userModel = UserModel.fromJson(value.data() as Map<String, dynamic>);

                              if (userModel.isProfileComplete == true) {
                                bookingProvider.updateSelectedParkingModel(parkingModel);
                                pageNavigator(context, SelectVehicleScreen(parkingModel: parkingModel));
                              } else {
                                Utils.toast("Please complete your profile", toastLength: Toast.LENGTH_LONG);
                                await Future.delayed(Duration(seconds: 1));
                                pageNavigator(context, CompleteProfile());
                              }
                            }
                          });*/
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: fixPadding, horizontal: fixPadding * 1.7),
                        decoration: BoxDecoration(
                          color: primaryColor,
                          borderRadius: BorderRadius.circular(5.0),
                          boxShadow: [buttonShadow],
                        ),
                        child: Text(
                          getTranslation(context, 'extend_parking_time.book_now'),
                          style: bold16LightBlack,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  mapCreated(GoogleMapController controller) async {}

  moveCamera(a, b) {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

    homeProvider.googleMapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(double.parse(a), double.parse(b)),
          bearing: 45.0,
          zoom: 14.0,
          tilt: 45.0,
        ),
      ),
    );
  }

  @override
  void dispose() {
    // homeProvider.googleMapController!.dispose();
    super.dispose();
  }
}
