import 'dart:developer';
import 'dart:math' show cos, sqrt, asin;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/constants/key.dart';
import 'package:parkingproject/generated/assets.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/pages/auth/login.dart';
import 'package:parkingproject/pages/booking/select_vehicle.dart';
import 'package:parkingproject/pages/home/all_images.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/provider/booking_provider.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/services/dynamic_link_handler.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:parkingproject/widget/column_builder.dart';
import 'package:parkingproject/widget/infinite_collection_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../profile/languages.dart';
import 'package:share_plus/share_plus.dart';

class DetailScreen extends StatefulWidget {
  final ParkingModel? parkingModel;

  const DetailScreen({super.key, required this.parkingModel});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  bool isBookMark = false;

  final facilitiesList = [
    {"image": "assets/detail/24-hours.png", "title": "24*7"},
    {"image": "assets/detail/security-camera.png", "title": "CCTV"},
    {"image": "assets/detail/payment-method.png", "title": "Payment"},
    {"image": "assets/detail/car-wash.png", "title": "Carwash"},
    {"image": "assets/detail/parking.png", "title": "Pickup"},
  ];

  final reviewList = [
    {
      "image": "assets/detail/review1.png",
      "name": "Esther Howard",
      "date": "1 april  2020",
      "description":
          "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet. Velit Amet minim mollit non",
      "rate": 4.5
    },
    {
      "image": "assets/detail/review2.png",
      "name": "Esther Howard",
      "date": "2 april  2020",
      "description":
          "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet. Velit Amet minim mollit non",
      "rate": 3.5
    }
  ];

/*  addFavouriteProduct({ParkingModel? parkingModel}) async {
    await ffstore.collection(userCollection).doc(userModel.value.currentuserid).collection(favouriteVehicles).doc(publishingModel!.vehicleId).get().then((value) async {
      if (!value.exists) {
        await ffstore
            .collection(userCollection)
            .doc(userModel.value.currentuserid)
            .collection(favouriteVehicles)
            .doc(publishingModel.vehicleId)
            .set(publishingModel.toJson());
      } else {
        await ffstore.collection(userCollection).doc(userModel.value.currentuserid).collection(favouriteVehicles).doc(publishingModel.vehicleId).delete();
      }
    });
  }*/

  double totalDistance = 0.0;

  double _coordinateDistance(lat1, lon1, lat2, lon2) {
    var p = 0.017453292519943295;
    var c = cos;
    var a = 0.5 - c((lat2 - lat1) * p) / 2 + c(lat1 * p) * c(lat2 * p) * (1 - c((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a));
  }

  @override
  void initState() {
    final HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);

    totalDistance += _coordinateDistance(
      double.parse(widget.parkingModel?.lat ?? "30.158702484783014"),
      double.parse(widget.parkingModel?.lng ?? "71.52380700534404"),
      homeProvider.currentLocation?.latitude,
      homeProvider.currentLocation?.longitude,
    );

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    log("WIdget Parking model toJson ${widget.parkingModel?.toJson()}");
    final AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
    final size = MediaQuery.of(context).size;
    auth.User? user = auth.FirebaseAuth.instance.currentUser;
    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverAppBar(
            expandedHeight: size.height * 0.31,
            backgroundColor: primaryColor,
            pinned: true,
            elevation: 0,
            titleSpacing: 0,
            centerTitle: false,
            leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(Icons.arrow_back),
            ),
            systemOverlayStyle: const SystemUiOverlayStyle(statusBarColor: Colors.transparent, statusBarIconBrightness: Brightness.light),
            actions: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: fixPadding),
                child: Row(
                  children: [
                    //+Share Button
                    GestureDetector(
                      onTap: () async {

                      },
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: fixPadding / 1.5),
                        child: Icon(
                          Icons.share_outlined,
                          color: whiteColor,
                          size: 22,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () async {
                        //+WORKING CODE
                        if (widget.parkingModel?.phoneNumber != null) {
                          final call = Uri.parse('tel:${widget.parkingModel?.phoneNumber}');
                          // final call = Uri.parse('tel:+91 9830268966');
                          if (await canLaunchUrl(call)) {
                            launchUrl(call);
                          } else {
                            throw 'Could not launch $call';
                          }
                        } else {
                          Utils.errorToast("Unable to call ");
                        }
                      },
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: fixPadding / 1.5),
                        child: Icon(
                          Icons.call_outlined,
                          color: whiteColor,
                          size: 22,
                        ),
                      ),
                    ),
                    user != null
                        ? StreamBuilder(
                            stream: ffstore
                                .collection(collectionUsers) //
                                .doc(authProvider.userModel.uid)
                                .collection(collectionFavourite)
                                .doc(widget.parkingModel?.documentID)
                                .snapshots(),
                            builder: (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                              if (snapshot.connectionState == ConnectionState.waiting) {
                                return const Icon(
                                  Icons.bookmark_rounded,
                                  color: kSecondaryColor,
                                  size: 20,
                                );
                              } else if (snapshot.connectionState == ConnectionState.active || snapshot.connectionState == ConnectionState.done) {
                                if (snapshot.hasError) {
                                  return const Text('Error');
                                } else if (snapshot.hasData) {
                                  return GestureDetector(
                                    child: snapshot.data!.exists
                                        ? const Padding(
                                            padding: EdgeInsets.symmetric(horizontal: fixPadding / 1.5),
                                            child: Icon(Icons.bookmark_rounded, color: whiteColor, size: 20),
                                          )
                                        : const Padding(
                                            padding: EdgeInsets.symmetric(horizontal: fixPadding / 1.5),
                                            child: Icon(Icons.bookmark_outline_rounded, color: whiteColor, size: 20),
                                          ),
                                    onTap: () async {
                                      auth.User? user = auth.FirebaseAuth.instance.currentUser;
                                      if (user != null) {
                                        // addFavouriteProduct(publishingModel: publishingModel);

                                        await ffstore
                                            .collection(collectionUsers)
                                            .doc(authProvider.userModel.uid)
                                            .collection(collectionFavourite)
                                            .doc(widget.parkingModel?.documentID)
                                            .get()
                                            .then((value) async {
                                          if (!value.exists) {
                                            await ffstore
                                                .collection(collectionUsers)
                                                .doc(authProvider.userModel.uid)
                                                .collection(collectionFavourite)
                                                .doc(widget.parkingModel?.documentID)
                                                .set(widget.parkingModel!.toJson());
                                          } else {
                                            await ffstore
                                                .collection(collectionUsers)
                                                .doc(authProvider.userModel.uid)
                                                .collection(collectionFavourite)
                                                .doc(widget.parkingModel?.documentID)
                                                .delete();
                                          }
                                        });
                                      } else {
                                        pageNavigator(context, const LoginScreen());
                                      }
                                    },
                                  );
                                } else {
                                  return const Text('Empty data');
                                }
                              } else {
                                return Text('State: ${snapshot.connectionState}');
                              }
                            },
                          )
                        : InkWell(
                            onTap: () {
                              setState(() {
                                isBookMark = !isBookMark;
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  backgroundColor: blackColor,
                                  duration: const Duration(milliseconds: 1500),
                                  behavior: SnackBarBehavior.floating,
                                  content: Text(
                                    isBookMark ? getTranslation(context, 'detail.add_bookmark') : getTranslation(context, 'detail.remove_bookmark'),
                                    style: bold15White,
                                  ),
                                ),
                              );
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: fixPadding / 1.5),
                              child: Icon(
                                isBookMark ? Icons.bookmark_rounded : Icons.bookmark_outline_rounded,
                                color: whiteColor,
                              ),
                            ),
                          ),
                  ],
                ),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                // decoration: const BoxDecoration(
                //   image: DecorationImage(
                //     image: AssetImage("assets/detail/image.png"),
                //     fit: BoxFit.cover,
                //   ),
                // ),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: NetworkImage((widget.parkingModel?.image != null && widget.parkingModel?.image != "")
                        ? widget.parkingModel?.image ?? ""
                        : "https://media.istockphoto.com/id/1300845620/vector/user-icon-flat-isolated-on-white-background-user-symbol-vector-illustration.jpg?s=612x612&w=0&k=20&c=yBeyba0hUkh14_jgv1OKqIH0CCSWU_4ckRkAoy2p73o="),
                    fit: BoxFit.cover,
                  ),
                ),
                alignment: languageValue == 4 ? Alignment.bottomLeft : Alignment.bottomRight,
                child: GestureDetector(
                  onTap: () {
                    pageNavigator(context, ImageScreen(parkingModel: widget.parkingModel));
                    // Navigator.pushNamed(context, '/images');
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: fixPadding * 1.2, vertical: fixPadding * 0.8),
                    decoration: BoxDecoration(
                      color: primaryColor,
                      borderRadius: languageValue == 4 ? const BorderRadius.only(topRight: Radius.circular(5.0)) : const BorderRadius.only(topLeft: Radius.circular(5.0)),
                    ),
                    child: Text(
                      getTranslation(context, 'detail.more_image'),
                      style: bold15LightBlack,
                    ),
                  ),
                ),
              ),
            ),
          ),

          //+BODY PART AFTER IMAGE
          SliverList(
            delegate: SliverChildListDelegate(
              [
                heightSpace,
                heightSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "${widget.parkingModel?.parkingName}",
                              style: semibold18LightBlack,
                              overflow: TextOverflow.ellipsis,
                            ),
                            height5Space,
                            Text(
                              "${widget.parkingModel?.address}",
                              style: semibold14Grey,
                            ),
                            height5Space,
                            Text(
                              "\$ ${widget.parkingModel?.priceHourly}/${getTranslation(context, 'detail.hours')}",
                              style: semibold18TextColor,
                            ),
                            SizedBox(height: 10),
                            //+DISTANCE
                            Text.rich(
                              overflow: TextOverflow.ellipsis,
                              TextSpan(
                                text: "${getTranslation(context, 'extend_parking_time.distance_value')} : ",
                                style: medium14LightBlack,
                                children: [
                                  TextSpan(
                                    text: "${totalDistance.toStringAsFixed(2)} Km ",
                                    style: semibold14LightBlack,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Image.asset(
                                "assets/detail/car.png",
                                height: 22,
                                width: 22,
                              ),
                              widthSpace,
                              /*Text(
                                "24 ${getTranslation(context, 'detail.slot')}",
                                style: bold15LightBlack,
                              ),*/
                            ],
                          ),
                          heightSpace,
                          Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: fixPadding / 2,
                              horizontal: fixPadding,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF9F9F9),
                              boxShadow: [
                                BoxShadow(
                                  color: shadowColor.withOpacity(0.1),
                                  blurRadius: 6,
                                )
                              ],
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.star,
                                  color: textColor,
                                  size: 16,
                                ),
                                widthBox(3),
                                Text(
                                  (widget.parkingModel?.rating.toString() == "0.1") ? "0.0" : widget.parkingModel?.rating.toString() ?? "",
                                  style: semibold14LightBlack,
                                )
                              ],
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
                heightSpace,
                heightSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        getTranslation(context, 'detail.information'),
                        style: bold16LightBlack,
                      ),
                      heightSpace,
                      Text(
                        "${widget.parkingModel?.description}",
                        style: semibold14Grey,
                      )
                    ],
                  ),
                ),
                heightSpace,
                heightSpace,
                user != null
                    ? Row(
                        children: [
                          const SizedBox(width: 20),
                          Container(
                            height: 52,
                            width: 52,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(width: 2.0, color: primaryColor),
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap: () async {
                                  final authProvider = Provider.of<AuthProvider>(context, listen: false);

                                  auth.User? user = auth.FirebaseAuth.instance.currentUser;
                                  if (user == null) {
                                    Utils.errorToast("Please login first for starting conversation");
                                  } else if (user.uid == widget.parkingModel?.parkingProviderId) {
                                    Utils.errorToast("You cannot start chat with this person");
                                  } else {
                                    UserModel otherUserModel = UserModel();
                                    await ffstore.collection(collectionUsers).doc(widget.parkingModel?.parkingProviderId).get().then((value) {
                                      otherUserModel = UserModel.fromJson(value.data() ?? {});
                                    });
                                    await chatController.createChatRoomAndStartConversation(
                                      user1Model: authProvider.userModel,
                                      user2Model: otherUserModel,
                                      context: context,
                                    );
                                  }
                                },
                                borderRadius: BorderRadius.circular(100),
                                splashColor: kBlackColor.withOpacity(0.05),
                                highlightColor: kBlackColor.withOpacity(0.05),
                                child: Center(
                                  child: Image.asset(
                                    Assets.imageMessage,
                                    height: 24,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 15),
                          const SizedBox(width: 15),
                        ],
                      )
                    : SizedBox(),
                heightSpace,
                //+FACILITY
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                      child: Text(
                        getTranslation(context, 'detail.facility_provide'),
                        style: bold16LightBlack,
                      ),
                    ),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.all(fixPadding),
                      physics: const BouncingScrollPhysics(),
                      child: Row(
                        children: List.generate(
                          facilitiesList.length,
                          (index) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: fixPadding),
                              child: Column(
                                children: [
                                  Container(
                                    height: 48,
                                    width: 48,
                                    padding: const EdgeInsets.all(fixPadding),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFAFAFA),
                                      boxShadow: [boxShadow],
                                      shape: BoxShape.circle,
                                    ),
                                    child: Image.asset(
                                      facilitiesList[index]['image'].toString(),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  heightSpace,
                                  Text(
                                    facilitiesList[index]['title'].toString(),
                                    style: semibold15Grey,
                                  )
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    )
                  ],
                ),
                heightSpace,
                //+Rating && Reviews
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              getTranslation(context, 'detail.rate_review'),
                              style: bold16LightBlack,
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.pushNamed(context, '/review');
                            },
                            child: Text(
                              getTranslation(context, 'detail.see_all'),
                              style: bold14Grey,
                            ),
                          ),
                        ],
                      ),
                      ColumnBuilder(
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: fixPadding),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 48,
                                        width: 48,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          image: DecorationImage(
                                            image: AssetImage(
                                              reviewList[index]['image'].toString(),
                                            ),
                                          ),
                                        ),
                                      ),
                                      widthSpace,
                                      Expanded(
                                          child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            reviewList[index]['name'].toString(),
                                            style: regular16LightBlack,
                                          ),
                                          height5Space,
                                          Text(
                                            reviewList[index]['date'].toString(),
                                            style: semibold14Grey,
                                          )
                                        ],
                                      )),
                                      Container(
                                        padding: const EdgeInsets.symmetric(vertical: fixPadding / 2, horizontal: fixPadding),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFF9F9F9),
                                          boxShadow: [
                                            BoxShadow(
                                              color: shadowColor.withOpacity(0.1),
                                              blurRadius: 6,
                                            )
                                          ],
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              Icons.star,
                                              size: 16,
                                              color: textColor,
                                            ),
                                            widthBox(3),
                                            Text(
                                              reviewList[index]['rate'].toString(),
                                              style: semibold14LightBlack,
                                            )
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                  heightSpace,
                                  Text(
                                    reviewList[index]['description'].toString(),
                                    style: medium14Grey,
                                  )
                                ],
                              ),
                            );
                          },
                          itemCount: reviewList.length)
                    ],
                  ),
                ),
              ],
            ),
          )
        ],
      ),
      bottomNavigationBar: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.all(fixPadding * 2.0),
        color: scaffoldBgColor,
        child: Row(
          children: [
            Expanded(
              child: buttonWidget(
                getTranslation(context, 'detail.get_direction'),
                () async {
                  Utils.openMap(double.parse(widget.parkingModel!.lat ?? ""), double.parse(widget.parkingModel?.lng ?? ""));
                },
                whiteColor,
                textColor,
              ),
            ),
            widthSpace,
            widthSpace,
            Expanded(
              child: buttonWidget(
                getTranslation(context, 'detail.book_now'),
                () {
                  // Navigator.pushNamed(context, '/selectVehical');

                  final bookingProvider = Provider.of<BookingProvider>(context, listen: false);
                  auth.User? currentUser = auth.FirebaseAuth.instance.currentUser;
                  log("current user $currentUser");

                  if (currentUser == null) {
                    pageNavigator(context, const LoginScreen());
                  } else {
                    bookingProvider.updateSelectedParkingModel(widget.parkingModel);

                    pageNavigator(context, SelectVehicleScreen(parkingModel: widget.parkingModel));
                  }
                },
                primaryColor,
                lightBlackColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  buttonWidget(String title, Function() onTap, Color color, Color textColor) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.maxFinite,
        padding: const EdgeInsets.symmetric(horizontal: fixPadding, vertical: fixPadding * 1.4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [buttonShadow],
          color: color,
        ),
        child: Text(
          title,
          style: bold18TextColor.copyWith(color: textColor),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }
}
