///
///
///
///
///
///

enum NotificationType {
  bookedParking,
  bookingCancel,
}
