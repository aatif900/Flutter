import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:parkingproject/provider/chat_controller.dart';

FirebaseFirestore ffstore = FirebaseFirestore.instance;
FirebaseAuth auth = FirebaseAuth.instance;
FirebaseStorage fstorage = FirebaseStorage.instance;
FirebaseMessaging fcm = FirebaseMessaging.instance;

String collectionUsers = "Users";
String collectionBooking = "Booking";
String collectionNotifications = "Notifications";
String collectionFavourite = "Favourite";
String collectionVehicles = "Vehicles";

String collectionParking = "Parking";
String collectionSlots = "Slots";
String collectionAppSetting = "AppSetting";


String chatRoomCollection = "ChatRoom";
String messagesCollection = "messages";

ChatController chatController = ChatController.instance;

Future<void> init() async {
  Get.put(ChatController());
}

updateFCMToken() async {
  User? user = FirebaseAuth.instance.currentUser;
  if (user != null) {
    log("initializeToken called");
    String? token = await fcm.getToken();
    try {
      ffstore.collection("Users").doc(auth.currentUser?.uid).update(
        {
          "fcmToken": token,
          "deviceType": Platform.isAndroid ? "android" : "ios",
        },
      );
    } catch (e) {
      log("error in fcm token update: $e");
    }
    fcm.onTokenRefresh.listen((streamedToken) {
      try {
        ffstore.collection("Users").doc(auth.currentUser?.uid).update(
          {
            "fcmToken": streamedToken,
            "deviceType": Platform.isAndroid ? "android" : "ios",
          },
        );
      } catch (e) {
        print(e);
      }
    });
  } else {
    log("Current user is null");
  }
}

String formatTimeDifference(Duration difference) {
  if (difference.inDays >= 365) {
    int years = difference.inDays ~/ 365;
    return '$years year${years > 1 ? 's' : ''} ago';
  } else if (difference.inDays >= 30) {
    int months = difference.inDays ~/ 30;
    return '$months month${months > 1 ? 's' : ''} ago';
  } else if (difference.inDays > 0) {
    return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
  } else if (difference.inHours > 0) {
    return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
  } else if (difference.inMinutes > 0) {
    return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
  } else {
    return 'just now';
  }
}

String convertGSTToLocalTime(String gstTime) {
  print(gstTime);

  DateTime gstDateTime = DateFormat('yyyy-MM-dd HH:mm:ss').parse(gstTime);

// Get the user's local time zone offset
  DateTime userDateTime = DateTime.now();
  Duration offset = userDateTime.timeZoneOffset;

// Calculate the user's local time based on the time zone offset
  DateTime userLocalTime = gstDateTime.add(offset);

  // DateTime userLocalTime =
  //     DateTime.now().subtract(Duration(hours: hourDifference));

  String userTime = DateFormat('yyyy-MM-dd HH:mm:ss').format(userLocalTime);
  print('usertime:$userTime');
  Duration timeDifference = userDateTime.difference(userLocalTime);

  String formattedTimeDifference = formatTimeDifference(timeDifference);

  return formattedTimeDifference;
}
