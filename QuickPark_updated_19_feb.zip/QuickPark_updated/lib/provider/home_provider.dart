import 'dart:async';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:geocoding/geocoding.dart' as geo_coding;
import 'package:geolocator/geolocator.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:get/get_connect/http/src/response/response.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_place/google_place.dart' as pred_list;
import 'package:location/location.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/constants/key.dart';
import 'package:parkingproject/generated/assets.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/services/api_services.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/my_logger.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:uuid/uuid.dart';

import '../models/google_places_model.dart';

class HomeProvider extends ChangeNotifier {
  //

  final TextEditingController searchTextEditingController = TextEditingController();

  GoogleMapController? googleMapController;

  List<Marker> allMarkers = [];

  void addMarkerInList(Marker newMarker) {
    allMarkers.add(newMarker);
    notifyListeners();
  }

  List<pred_list.AutocompletePrediction> predictionsList = List<pred_list.AutocompletePrediction>.from([]);

  getDistance(double othersLatitude, double othersLongitude, BuildContext context) {
    log("in getDistance latitude and longitude ");
    log(" ${currentLocation?.latitude} ${currentLocation?.longitude}");

    log("OTHERS LATITUDE AND Longitude  $othersLatitude  $othersLongitude");

    double result =
        Geolocator.distanceBetween(currentLocation?.latitude ?? 30.157666229927827, currentLocation?.longitude ?? 71.52469666319631, othersLatitude, othersLongitude);
    double calculate = result / 1000;
    log("Calculated distance is :  $calculate");
    return result;
  }

  addPredictionToList(value) {
    // predictionsList.add(value);
    predictionsList = value;
    notifyListeners();
  }

  clearPredictionsList() {
    predictionsList.clear();

    predictionsList = [];
    notifyListeners();
  }

  List<ParkingModel> allDataList = <ParkingModel>[];

  getDataFromFirebase() async {
    allDataList.clear();
    ffstore.collection(collectionParking).snapshots().listen((event) async {
      for (var element in event.docs) {
        allDataList.add(ParkingModel.fromJson(element.data()));
        allMarkers.add(
          Marker(
            markerId: MarkerId(DateTime.now().millisecondsSinceEpoch.toString()),
            position: LatLng(double.parse(element.data()['lat']), double.parse(element.data()['lng'])),
            infoWindow: InfoWindow(title: "${element.data()['parkingName']}"),
            icon: BitmapDescriptor.fromBytes(await Utils.getBytesFromAsset(Assets.homeParkingMarker, 70)),
          ),
        );
      }
    });
    notifyListeners();

    log("Simple Data done HA ----------- & length is ${allDataList.length}");
  }

  Future<void> goToCurrentPosition(context) async {
    if (currentLocation != null) {
      allMarkers.removeWhere((marker) => marker.mapsId.value == 'myCurrentLocationID');
      allMarkers.add(Marker(
        markerId: const MarkerId("myCurrentLocationID"),
        position: LatLng(currentLocation?.latitude ?? 31.520522265609166, currentLocation?.longitude ?? 74.35876302880217),
        infoWindow: const InfoWindow(title: 'My Current Location'),
        icon: BitmapDescriptor.fromBytes(await Utils.getBytesFromAsset(Assets.homeCar, 70)),
      ));

      // final GoogleMapController googleMapController1 = await googleMapCompleterController.future;
      googleMapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: LatLng(currentLocation?.latitude ?? 31.520522265609166, currentLocation?.longitude ?? 74.35876302880217), zoom: 14)));

      notifyListeners();
    } else {
      showCircularLoadingDialog(context);
      bool permission = await Utils.requestLocationPermission();

      if (permission) {
        await Geolocator.getCurrentPosition(desiredAccuracy: geo.LocationAccuracy.best).then((Position position) async {
          log("on pressed ${position.latitude} and ${position.longitude}");
          allMarkers.removeWhere((marker) => marker.mapsId.value == 'myCurrentLocationID');

          allMarkers.add(Marker(
            markerId: const MarkerId("myCurrentLocationID"),
            position: LatLng(position.latitude, position.longitude),
            infoWindow: const InfoWindow(title: 'My Current Location'),
            icon: BitmapDescriptor.fromBytes(await Utils.getBytesFromAsset(Assets.homeCar, 70)),
          ));

          // final GoogleMapController googleMapController1 = await googleMapCompleterController.future;
          googleMapController?.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(target: LatLng(position.latitude, position.longitude), zoom: 14)));

          notifyListeners();
        });
        Navigator.of(context).pop();
      } else {
        Navigator.of(context).pop();
        Utils.errorToast("Permission are denied unable to get correct location");
      }
    }
  }

  Position? currentLatLng;
  LocationData? currentLocation;

  StreamSubscription<LocationData>? subscription;

  getCurrentLocation() async {
    log("inside  getCurrentLocation() ");
    await Utils.requestLocationPermission().then((value) async {
      if (value) {
        await Geolocator.getCurrentPosition(desiredAccuracy: geo.LocationAccuracy.best).then((Position position) async {
          currentLatLng = position;
          // log("currentLatLng value inside await Geolocator.getCurrentPosition( $currentLatLng");
        });
        notifyListeners();

        subscription = Location().onLocationChanged.listen((changeLocation) {
          // log("subscription location?.onLocationChanged.listen $changeLocation lat ${changeLocation.latitude} lng ${changeLocation.longitude}");
          currentLocation = changeLocation;
        });
        subscription?.onData((LocationData data) async {
          double? lat = data.latitude;
          double? long = data.longitude;
          currentLocation = data;
          // log("subscription onData :  $data \n lat ${data.latitude} lng ${data.longitude}  \n &&&&&&&& $currentLocation.");

          /*
          final GoogleMapController controller = await googleMapCompleterController.future;
          CameraPosition cameraPosition = CameraPosition(zoom: 14, tilt: 80, bearing: 30, target: LatLng(lat!, long!));
          controller.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

          allMarkers.removeWhere((marker) => marker.mapsId.value == 'sourcePosition');
          allMarkers.add(
            Marker(
              markerId: const MarkerId('sourcePosition'),
              position: LatLng(lat, long),
              infoWindow: const InfoWindow(title: 'My Current Location'),
              icon: BitmapDescriptor.fromBytes(await Utils.getBytesFromAsset(Assets.homeCar, 70)),
            ),
          );
          */
          notifyListeners();

          // Utils.showCustomSnackBar(context, "Changing location with updating locations pins");
        });
        Location().enableBackgroundMode(enable: true);
        notifyListeners();
      } else {
        Utils.errorToast("Permission are denied unable to get correct location");
      }
    });
  }

  //+Search Places Related

  List<GooglePlacesModel> _getList = <GooglePlacesModel>[];

  List<GooglePlacesModel> get getList => _getList;

  bool isConfirmed = false;
  double myLat = 21.5397106;
  double myLng = 71.8215543;

  void onSearchChanged(String value) {
    print(value);
    if (value.isNotEmpty) {
      getPlacesList(value);
    }
  }

  Future<void> getPlacesList(String value) async {
    var sessionToken = Uuid().v4();
    String request = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$value&key=$googleMapApiKey&sessiontoken=$sessionToken&types=locality';

    Response response = await ApiService.getPlacesList(request);
    if (response.statusCode == 200) {
      log("response.body  ${response.body}");
      Map<String, dynamic> myMap = Map<String, dynamic>.from(response.body);
      var body = myMap['predictions'];
      _getList = [];
      body.forEach((data) {
        GooglePlacesModel datas = GooglePlacesModel.fromJson(data);
        _getList.add(datas);
      });
      isConfirmed = false;
      notifyListeners();
      log("_getList.length.toString() : ${_getList.length.toString()}");
    } else {
      errorLog("Response is not equal to 200");
    }
  }

  Future<void> getLatLngFromAddress(String address, BuildContext context) async {
    List<geo_coding.Location> locations = await geo_coding.locationFromAddress(address);
    print(locations.toString());
    if (locations.isNotEmpty) {
      _getList = [];
      _getList.clear();
      notifyListeners();
      log("After clearing list length is ${_getList.length}");
      searchTextEditingController.text = address;
      myLat = locations[0].latitude;
      myLng = locations[0].longitude;
      isConfirmed = true;
      hideKeyBoard(context);

      googleMapController?.animateCamera(CameraUpdate.newLatLng(LatLng(myLat ?? 0.0, myLng ?? 0.0)));

      var pinPosition = LatLng(myLat, myLng);
      allMarkers.removeWhere((m) => m.markerId.value == 'SearchLocation');
      allMarkers.add(
        Marker(
          markerId: const MarkerId('SearchLocation'),
          position: pinPosition,
          icon: BitmapDescriptor.fromBytes(await Utils.getBytesFromAsset("assets/home/parkingMarker.png", 70)),
          infoWindow: const InfoWindow(title: "Location"),
        ),
      );
      notifyListeners();
    }
  }
}
