import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class FirestoreDataProvider extends ChangeNotifier {
  final _datalistSnapshot = <DocumentSnapshot>[];
  String _errorMessage = '';
  bool _hasNext = true;
  bool _isFetchingData = false;

  String get errorMessage => _errorMessage;

  bool get hasNext => _hasNext;

  List get recievedDocs => _datalistSnapshot.map((snap) => snap.data()).toList();

  reset() {
    _hasNext = true;
    _datalistSnapshot.clear();
    _isFetchingData = false;
    _errorMessage = '';
    recievedDocs.clear();
    notifyListeners();
  }

  Future fetchNextData(String? dataType, Query? refdataa, bool isAfterNewdocCreated) async {
    if (_isFetchingData) return;

    _errorMessage = '';
    _isFetchingData = true;

    try {
      final snap = isAfterNewdocCreated == true
          ? await FirebaseApi.getFirestoreCOLLECTIONData(NumberLimits.totalDatatoLoadAtOnceFromFirestore, refdata: refdataa)
          : await FirebaseApi.getFirestoreCOLLECTIONData(NumberLimits.totalDatatoLoadAtOnceFromFirestore,
              startAfter: _datalistSnapshot.isNotEmpty ? _datalistSnapshot.last : null, refdata: refdataa);
      if (isAfterNewdocCreated == true) {
        _datalistSnapshot.clear();
        _datalistSnapshot.addAll(snap.docs);
      } else {
        _datalistSnapshot.addAll(snap.docs);
      }
      // notifyListeners();
      if (snap.docs.length < NumberLimits.totalDatatoLoadAtOnceFromFirestore) _hasNext = false;
      notifyListeners();
    } catch (error) {
      _errorMessage = error.toString();
      notifyListeners();
    }

    _isFetchingData = false;
  }

/*  updateparticulardocinProvider({required CollectionReference colRef, required String userid, required Function(DocumentSnapshot user) onfetchDone}) async {
    int index = _datalistSnapshot.indexWhere((prod) => prod[dbkeys.id] == userid);
    await colRef.doc(userid).get().then((value) {
      _datalistSnapshot.removeAt(index);
      _datalistSnapshot.insert(index, value);
      notifyListeners();
      onfetchDone(value);
    });
  }

  deleteparticulardocinProvider({
    String? collection,
    String? document,
    String? compareKey,
    String? compareVal,
    GlobalKey? scaffoldkey,
    GlobalKey? keyloader,
    BuildContext? context,
  }) async {
    int index = _datalistSnapshot.indexWhere((prod) => prod[compareKey!] == compareVal);

    _datalistSnapshot.removeAt(index);
    notifyListeners();
  }*/
}

class NumberLimits {
  static int totalDatatoLoadAtOnceFromFirestore = 14;
}

class FirebaseApi {
  static Future<QuerySnapshot> getFirestoreCOLLECTIONData(int limit, {DocumentSnapshot? startAfter, String? dataType, Query? refdata}) async {
    if (startAfter == null) {
      return refdata!.get();
    } else {
      return refdata!.startAfterDocument(startAfter).get();
    }
  }
}
