// ignore_for_file: avoid_function_literals_in_foreach_calls

import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/utils/my_logger.dart';
import 'package:provider/provider.dart';

class FilterProvider extends ChangeNotifier {
  ///

  double minimumPrice = 2.0;
  double maximumPrice = 2.00;
  double selectedFilterPrice = 200.0;

  var selectedFilterDistance = 300.0;
  int selectedFilterRating = 0;

  bool videoSurveillanceValue = false;
  bool coveredValue = false;
  bool monthlyRentValue = false;
  bool lockedValue = false;
  bool fullHoursAccessValue = false;
  bool isSearching = false;
  bool applyFilter = false;

  String selectedVehicleType = "Select vehicle type";
  List<String> vehicleTypesList = [
    "Select vehicle type",
    "Motorcycle",
    "Car",
    "SUV",
    "Camper",
  ];

  void updateSelectedVehicleValue(String value) {
    selectedVehicleType = value;
    notifyListeners();
    log("selectedVehicleType $selectedVehicleType");
  }

  void updateVideoSurveillanceValue(bool value) {
    videoSurveillanceValue = value;
    notifyListeners();
  }

  void updateFullHoursAccessValue(bool value) {
    fullHoursAccessValue = value;
    notifyListeners();
  }

  void updateLockedValue(bool value) {
    lockedValue = value;
    notifyListeners();
  }

  void updateCoverValue(bool value) {
    coveredValue = value;
    notifyListeners();
  }

  void updateMonthlyRentValue(bool value) {
    monthlyRentValue = value;
    notifyListeners();
  }

  changeBoolValue(bool value) {
    applyFilter = value;
    notifyListeners();
  }

  updateSearching(value) {
    isSearching = value;
    notifyListeners();
  }

  List<ParkingModel> tempList = List<ParkingModel>.from([]);
  List<ParkingModel> filteredDataList = List<ParkingModel>.from([]);

  List<ParkingModel> listForDistance = List<ParkingModel>.from([]);

  getDistance(double othersLatitude, double othersLongitude, BuildContext context) {
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    log("in getDistance latitude and longitude ");
    log(" ${homeProvider.currentLocation?.latitude} ${homeProvider.currentLocation?.longitude}");

    double result = Geolocator.distanceBetween(
        homeProvider.currentLocation?.latitude ?? 30.157666229927827, homeProvider.currentLocation?.longitude ?? 71.52469666319631, othersLatitude, othersLongitude);
    double calculate = result / 1000;
    log("Calculated distance is :  $calculate");
    return result;
  }

  //!-------------------------------------------------------------------------------------

  Future<void> showResults(context) async {
    infoLog(" INSIDE SHOW RESULT ");

    log("INSIDE SHOW RESULT");
    log(" \n Selected Value for filter :"
        " \n selectedFilterPrice ${selectedFilterPrice.toInt()}"
        " \n selectedVehicleType $selectedVehicleType"
        " \n videoSurveillanceValue $videoSurveillanceValue"
        " \n fullHoursAccessValue $fullHoursAccessValue"
        " \n lockedValue $lockedValue"
        " \n coveredValue $coveredValue"
        " \n monthlyRentValue $monthlyRentValue"
        " \n selectedFilterRating $selectedFilterRating "
        " \n selectedFilterRating.runtimeType  ${selectedFilterRating.runtimeType} \n"
        " \n selectedFilterRating.toDouble()  ${selectedFilterRating.toDouble()} \n"
        ""
        " ");

    updateSearching(true);
    tempList = [];
    filteredDataList = [];
    listForDistance = [];
    tempList.clear();
    filteredDataList.clear();
    listForDistance.clear();
    notifyListeners();

    log("All list length respectively ${tempList.length} ${filteredDataList.length} ${listForDistance.length} ");

    // await ffstore
    //     .collection(collectionParking)
    //     .where(
    //       Filter.or(
    //         Filter("vehicleType", isEqualTo: selectedVehicleType),
    //         Filter("isVideoSurveillance", isEqualTo: selectedVehicleType),
    //         Filter("isFullHourAccess", isEqualTo: fullHoursAccessValue),
    //         Filter("isLocked", isEqualTo: lockedValue),
    //         Filter("isCovered", isEqualTo: coveredValue),
    //         Filter("monthlyRent", isEqualTo: monthlyRentValue),
    //         // Filter("rating", isEqualTo: monthlyRentValue),
    //       ),
    //     )
    //     .get()
    //     .then((querySnap) {
    //   log("All Apply filter  doc length  ${querySnap.docs.length}");
    //   querySnap.docs.forEach((element) {
    //     log("SOMETHING GONE HERE ");
    //     tempList.add(ParkingModel.fromJson(element.data()));
    //   });
    //   notifyListeners();
    //   tempList.forEach((element) => log(" ALL FILTER DATA ${element.toJson()}"));
    // });

    //+ DISTANCE

    // List<Location> filteredLocations =
    // locations.where((location) => calculateDistance(referenceLat, referenceLon, location.latitude, location.longitude) <= maxDistance).toList();

    await ffstore.collection(collectionParking).get().then((querySnap) {
      querySnap.docs.forEach((element) {
        listForDistance.add(
          ParkingModel(
            createdAt: element.data()['createdAt'],
            lat: element.data()['lat'],
            lng: element.data()['lng'],
            description: element.data()['description'],
            title: element.data()['title'],
            address: element.data()['address'],
            phoneNumber: element.data()['phoneNumber'],
            parkingName: element.data()['parkingName'],
            image: element.data()['image'],
            imageList: element.data()['imageList'],
            slot: element.data()['slot'],
            vehicleType: element.data()['vehicleType'],
            documentID: element.data()['documentID'],
            isCovered: element.data()['isCovered'],
            isFullHourAccess: element.data()['isFullHourAccess'],
            isLocked: element.data()['isLocked'],
            isVideoSurveillance: element.data()['isVideoSurveillance'],
            monthlyRent: element.data()['monthlyRent'],
            parkingProviderId: element.data()['parkingProviderId'],
            priceDaily: element.data()['priceDaily'],
            priceHourly: element.data()['priceHourly'],
            priceMonthly: element.data()['priceMonthly'],
            priceWeekly: element.data()['priceWeekly'],
            providerType: element.data()['providerType'],
            rating: element.data()['rating'],
            distance: (getDistance(double.parse(element.data()['lat'] ?? "30.157666229927827"), double.parse(element.data()['lng'] ?? ""), context) / 1000),
          ),
        );
      });
      log(" after adding length of listForDistance is :   ${listForDistance.length}");

      // tempList = listForDistance
      //     .where((location) => (getDistance(double.parse(location.lat ?? "30.157666229927827"), double.parse(location.lng ?? ""), context) / 1000) >= selectedFilterPrice)
      //     .toList();

      // tempList.add(listForDistance.firstWhere(
      //     (location) => selectedFilterPrice <= (getDistance(double.parse(location.lat ?? "30.157666229927827"), double.parse(location.lng ?? ""), context) / 1000),
      //     orElse: () => ParkingModel()));

      tempList.add(
        listForDistance.firstWhere(
          (location) => (getDistance(double.parse(location.lat ?? "30.157666229927827"), double.parse(location.lng ?? ""), context) / 1000) <= selectedFilterDistance,
          orElse: () => ParkingModel(),
        ),
      );
      // tempList.removeWhere((element) => (element.priceHourly ?? 0) > (selectedFilterPrice.toInt())   );

      notifyListeners();

      log("listForDistance length ${listForDistance.length}");

      log("tempList length in DISTANCE : => ${tempList.length}");
      tempList.forEach((element) => log("element data DISTANCE ${element.toJson()}"));
    });

    //+ PRICE

    await ffstore
        .collection(collectionParking) //
        .where("price", isGreaterThanOrEqualTo: selectedFilterPrice.toInt())
        .get()
        .then((querySnap) {
      tempList.removeWhere((element) => (element.priceHourly ?? 0) < (selectedFilterPrice.toInt()));

      querySnap.docs.forEach((element) {
        // checking already added or not IF NOT IN THE LIST THEN WE GO  inside if condition and add element
        if (tempList.firstWhere((item) => item.documentID == element["docID"], orElse: () => ParkingModel()).documentID == null) {
          tempList.add(ParkingModel.fromJson(element.data()));
        }
      });
      notifyListeners();
      // log("tempList length in Price : => ${tempList.length}");
      // tempList.forEach((element) => log("element data Price ${element.toJson()}"));
    });

    //+vehicleType

    if (selectedVehicleType != "Select vehicle type") {
      await ffstore.collection(collectionParking).where("vehicleType", isEqualTo: selectedVehicleType).get().then((querySnap) {
        log("Get vehicleType doc length ${querySnap.docs.length}");

        querySnap.docs.forEach((element) {
          log("tempList.firstWhere((item) =>  item.vehicleType == element[vehicleType] "
              "${tempList.firstWhere((item) => item.vehicleType == element["vehicleType"], orElse: () => ParkingModel()).documentID}");

          if (tempList.firstWhere((item) => item.vehicleType == element["vehicleType"], orElse: () => ParkingModel()).documentID == null) {
            tempList.add(ParkingModel.fromJson(element.data()));
          }
        });
        notifyListeners();
      });
      log("tempList length in vehicleType : => ${tempList.length}");
      tempList.forEach((element) => log("element data vehicleType ${element.toJson()}"));
    } else {
      log("No Vehicle type Selected");
    }

    //+isVideoSurveillance

    await ffstore.collection(collectionParking).where("isVideoSurveillance", isEqualTo: videoSurveillanceValue).get().then((querySnap) {
      querySnap.docs.forEach((element) {
        log("tempList.firstWhere((item) =>"
            "  ${tempList.firstWhere((item) => item.isVideoSurveillance == element["isVideoSurveillance"], orElse: () => ParkingModel()).isVideoSurveillance}");
        if (tempList.firstWhere((item) => item.isFullHourAccess == element["isFullHourAccess"], orElse: () => ParkingModel()).isFullHourAccess == null) {
          tempList.add(ParkingModel.fromJson(element.data()));
        }
      });
      notifyListeners();
      log("tempList length ${tempList.length}");

      for (var element in tempList) {
        log("element toJson ${element.toJson()}");
      }
    });

    //+isFullHourAccess
    await ffstore.collection(collectionParking).where("isFullHourAccess", isEqualTo: fullHoursAccessValue).get().then((querySnap) {
      querySnap.docs.forEach((element) {
        log("element['isFullHourAccess') ${element["isFullHourAccess"]} ");
        log(" abc element isFullHourAccess  ${tempList.firstWhere((item) => element["isFullHourAccess"] == item.isFullHourAccess, orElse: () => ParkingModel()).isFullHourAccess}");
        log("tempList.firstWhere((item) =>  ${tempList.firstWhere((item) => item.isFullHourAccess == element["isFullHourAccess"], orElse: () => ParkingModel()).isFullHourAccess}");

        // checking already added or not IF NOT IN THE LIST THEN WE GO  inside if condition and add element
        if (tempList.firstWhere((item) => item.isFullHourAccess == element["isFullHourAccess"], orElse: () => ParkingModel()).isFullHourAccess == null) {
          tempList.add(ParkingModel.fromJson(element.data()));
        }
      });
      notifyListeners();
      log("tempList length ${tempList.length}");

      for (var element in tempList) {
        log("element toJson ${element.toJson()}");
      }
    });

    //+isLocked

    await ffstore.collection(collectionParking).where("isLocked", isEqualTo: lockedValue).get().then((querySnap) {
      querySnap.docs.forEach((element) {
        log("element['lockedValue') ${element["isLocked"]} ");
        log(" abc element lockedValue  ${tempList.firstWhere((item) => element["isLocked"] == item.isLocked, orElse: () => ParkingModel()).isLocked}");
        log("tempList.firstWhere((item) =>  ${tempList.firstWhere((item) => item.isLocked == element["isLocked"], orElse: () => ParkingModel()).isLocked}");

        // checking already added or not IF NOT IN THE LIST THEN WE GO  inside if condition and add element
        if (tempList.firstWhere((item) => item.isLocked == element["isLocked"], orElse: () => ParkingModel()).isLocked == null) {
          tempList.add(ParkingModel.fromJson(element.data()));
        }
      });
      notifyListeners();
      log("tempList length ${tempList.length}");

      for (var element in tempList) {
        log("element toJson ${element.toJson()}");
      }
    });

    //+Covered

    await ffstore.collection(collectionParking).where("isCovered", isEqualTo: coveredValue).get().then((querySnap) {
      querySnap.docs.forEach((element) {
        log("element['isCovered') ${element["isCovered"]} ");
        log(" abc element isCovered  ${tempList.firstWhere((item) => element["isCovered"] == item.isCovered, orElse: () => ParkingModel()).isCovered}");
        log("tempList.firstWhere((item) =>  ${tempList.firstWhere((item) => item.isCovered == element["isCovered"], orElse: () => ParkingModel()).isCovered}");

        // checking already added or not IF NOT IN THE LIST THEN WE GO  inside if condition and add element
        if (tempList.firstWhere((item) => item.isCovered == element["isCovered"], orElse: () => ParkingModel()).isCovered == null) {
          tempList.add(ParkingModel.fromJson(element.data()));
        }
      });
      notifyListeners();
      log("tempList length ${tempList.length}");

      for (var element in tempList) {
        log("element toJson ${element.toJson()}");
      }
    });

    //+Monthly Rent

    await ffstore.collection(collectionParking).where("monthlyRent", isEqualTo: monthlyRentValue).get().then((querySnap) {
      for (var element in querySnap.docs) {
        log("element['monthlyRent') ${element["monthlyRent"]} ");
        log(" abc element monthlyRent  ${tempList.firstWhere((item) => element["monthlyRent"] == item.monthlyRent, orElse: () => ParkingModel()).monthlyRent}");
        log("tempList.firstWhere((item) =>  ${tempList.firstWhere((item) => item.monthlyRent == element["monthlyRent"], orElse: () => ParkingModel()).monthlyRent}");

        // checking already added or not IF NOT IN THE LIST THEN WE GO  inside if condition and add element
        if (tempList.firstWhere((item) => item.monthlyRent == element["monthlyRent"], orElse: () => ParkingModel()).monthlyRent == null) {
          tempList.add(ParkingModel.fromJson(element.data()));
        }
      }
      notifyListeners();
      log("tempList length ${tempList.length}");

      for (var element in tempList) {
        log("element toJson ${element.toJson()}");
      }
    });

    //+Rating
    await ffstore.collection(collectionParking).where("rating", isEqualTo: selectedFilterRating.toDouble()).get().then((querySnap) {
      querySnap.docs.forEach((element) {
        log("element['rating') ${element["rating"]} ");
        log(" abc element Rating  ${tempList.firstWhere((item) => element["rating"] == item.rating, orElse: () => ParkingModel()).rating}");
        log("tempList.firstWhere((item) =>  ${tempList.firstWhere((item) => item.rating == element["rating"], orElse: () => ParkingModel()).rating}");

        // checking already added or not IF NOT IN THE LIST THEN WE GO  inside if condition and add element
        if (tempList.firstWhere((item) => item.rating == element["rating"], orElse: () => ParkingModel()).rating == null) {
          tempList.add(ParkingModel.fromJson(element.data()));
        }
        tempList.removeWhere((element) => (element.rating) != (selectedFilterRating.toDouble()));
      });
      notifyListeners();
      tempList.forEach((element) => log("INSIDE RATING ALL RATING ${element.rating}"));

      tempList.forEach((element) => log("INSIDE RATING DATA ${element.toJson()}"));
    });

    // var removingDuplication = tempList.toSet().toList();

    log("--------------------tempList---------- length : ${tempList.length}------------------------------");
    tempList.forEach((element) => log("All TEMP LIST DATA ${element.toJson()}"));
    tempList.sort((a, b) => a.distance!.toInt().compareTo(b.distance!.toInt()));

    /* ((vehicle.filterNameList.contains(name.toLowerCase()) || name.isEmpty) &&
              (vehicle.filterLocationList.toSet().intersection(locationSearchableList.toSet()).length > 0 || location.isEmpty) &&
              (vehicle.model == model || model.isEmpty) &&
              (vehicle.brand == brand || brand.isEmpty) &&
              (vehicle.price ?? 0) >= minPrice &&
              (vehicle.price ?? 0) <= maxPrice) &&
              (vehicle.category == category || category.isEmpty),*/
    filteredDataList = tempList
        .where(
          (element) =>
              ((getDistance(double.parse(element.lat ?? "30.157666229927827"), double.parse(element.lng ?? ""), context) / 1000) <= selectedFilterDistance) ||
              (element.priceHourly! >= selectedFilterPrice) ||
              (element.isLocked == lockedValue) ||
              (element.isFullHourAccess == fullHoursAccessValue) ||
              (element.isVideoSurveillance == videoSurveillanceValue) ||
              (element.vehicleType == selectedVehicleType) ||
              (element.isCovered == coveredValue),
        )
        .toList();

    // if (selectedFilterRating.toDouble() != 0.1) {
    //   filteredDataList = tempList.where((element) => (element.rating == selectedFilterRating.toDouble())).toList();
    // }
    notifyListeners();

    log("Result---------- length : ${filteredDataList.length}");
    // filteredDataList.forEach((element) => log(" filteredDataList element toJson ${element.toJson()}"));

    updateSearching(false);
  }
}
