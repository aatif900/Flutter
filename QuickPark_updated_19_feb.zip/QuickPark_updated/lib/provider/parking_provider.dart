import 'dart:developer';
import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/pages/bottomNavigationBar/bottom_navigation_bar.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/my_logger.dart';
import 'package:parkingproject/utils/utils.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

class ParkingProvider extends ChangeNotifier {
  //
  TextEditingController titleController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController numberOfSlotsController = TextEditingController();
  TextEditingController priceHourlyController = TextEditingController();
  TextEditingController priceDailyController = TextEditingController();
  TextEditingController priceWeeklyController = TextEditingController();
  TextEditingController priceMonthlyController = TextEditingController();
  TextEditingController otpController = TextEditingController();

  List<String> providerTypes = [
    "Private",
    "Commercial",
  ];
  final vehicleTypeList = [
    "Motorcycle",
    "Car",
    "SUV",
    "Camper",
  ];
  List<String> selectedVehicle = [];
  String vehicleType = "Motorcycle";
  String selectedProviderType = "Private";

  bool videoSurveillanceValue = false;
  bool fullHoursAccessValue = false;
  bool lockedValue = false;
  bool coveredValue = false;
  bool monthlyRentValue = false;

  List pickedImages = [];
  List<String> imageUrlList = [];

  void updateMonthlyRentValue(bool value) {
    monthlyRentValue = value;
    notifyListeners();
  }

  void updateProviderTypeValue(String value) {
    selectedProviderType = value;
    notifyListeners();
  }

  void updateVideoSurveillanceValue(bool value) {
    videoSurveillanceValue = value;
    notifyListeners();
  }

  void updateFullHoursAccessValue(bool value) {
    fullHoursAccessValue = value;
    notifyListeners();
  }

  void updateLockedValue(bool value) {
    lockedValue = value;
    notifyListeners();
  }

  void updateCoverValue(bool value) {
    coveredValue = value;
    notifyListeners();
  }

  void removePickedImage(int index) {
    pickedImages.removeWhere((element) => element == pickedImages[index]);
    notifyListeners();
  }

  Future<void> pickFromCamera(BuildContext context) async {
    try {
      final img = await ImagePicker().pickImage(source: ImageSource.camera);
      if (img == null) {
        return;
      } else {
        pickedImages.add(File(img.path));
      }
      notifyListeners();
    } on PlatformException catch (e) {
      Utils.errorToast("Something wrong ${e.toString()}");
    }
  }

  Future<void> pickFromGallery(BuildContext context) async {
    try {
      List<XFile> images = await ImagePicker().pickMultiImage();
      for (int i = 0; i < images.length; i++) {
        pickedImages.add(images[i]);
      }
      notifyListeners();
    } on PlatformException catch (e) {
      Utils.errorToast("Something wrong ${e.toString()}");
    }
  }

  Future<void> uploadPhotos() async {
    imageUrlList.clear();
    for (int i = 0; i < pickedImages.length; i++) {
      Reference ref = fstorage.ref().child('OfferParkingImages/${DateTime.now().toString()}');
      await ref.putFile(File(pickedImages[i].path));
      await ref.getDownloadURL().then((value) {
        log('Profile Image URL $value');
        imageUrlList.add(value);
        log("imgUrl List =  ${imageUrlList.length}");
      });
    }
    notifyListeners();
  }

  uploadParkingDataToDataBase(context) async {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
    HomeProvider homeProvider = Provider.of<HomeProvider>(context, listen: false);
    double? latitudeValue;
    double? longitudeValue;

    if (titleController.text.isEmpty) {
      Utils.errorToast("Please enter parking name");
    } else if (descriptionController.text.isEmpty) {
      Utils.errorToast("Please enter description");
    } else if (addressController.text.isEmpty) {
      Utils.errorToast("Please enter parking address");
    } else if (descriptionController.text.isEmpty) {
      Utils.errorToast("Please enter description");
    } else if (priceHourlyController.text.isEmpty && priceDailyController.text.isEmpty && priceWeeklyController.text.isEmpty && priceMonthlyController.text.isEmpty) {
      Utils.errorToast("Please enter hourly or daily or weekly or monthly parking price ", toastLength: Toast.LENGTH_LONG);
    } else if (selectedVehicle.isEmpty) {
      Utils.errorToast("Please select at least one vehicle");
    } else if (pickedImages.isEmpty) {
      Utils.errorToast("Please select at least one image");
    } else {
      showLoadingDialog(context);
      if (homeProvider.currentLocation != null) {
        latitudeValue = homeProvider.currentLocation?.latitude;
        longitudeValue = homeProvider.currentLocation?.longitude;
      } else {
        bool permission = await Utils.requestLocationPermission();

        if (permission) {
          Position position = await Geolocator.getCurrentPosition();
          latitudeValue = position.latitude;
          longitudeValue = position.longitude;
        } else {
          Navigator.of(context).pop();
          await Permission.location.request();
          return;
        }
      }
      notifyListeners();
      log("longitudeValue   : $latitudeValue");
      log("longitudeValue   : $longitudeValue");

      await uploadPhotos();

      String documentID = const Uuid().v4();
      ParkingModel parkingModel = ParkingModel(
        createdAt: DateTime.now().millisecondsSinceEpoch,
        documentID: documentID,
        title: titleController.text,
        description: descriptionController.text,
        vehicleType: vehicleType,
        selectedVehicles: selectedVehicle,
        address: addressController.text,
        slot: 5,
        priceHourly: priceHourlyController.text.isNotEmpty ? int.parse(priceHourlyController.text) : 0,
        priceDaily: priceDailyController.text.isNotEmpty ? int.parse(priceDailyController.text) : 0,
        priceWeekly: priceWeeklyController.text.isNotEmpty ? int.parse(priceWeeklyController.text) : 0,
        priceMonthly: priceMonthlyController.text.isNotEmpty ? int.parse(priceMonthlyController.text) : 0,
        providerType: selectedProviderType,
        distance: 0.1,
        isCovered: coveredValue,
        isFullHourAccess: fullHoursAccessValue,
        isLocked: lockedValue,
        isVideoSurveillance: videoSurveillanceValue,
        monthlyRent: monthlyRentValue,
        phoneNumber: authProvider.userModel.phoneNumber,
        parkingProviderId: authProvider.userModel.uid,
        rating: 0.1,
        image: imageUrlList.isNotEmpty ? imageUrlList.first : "",
        imageList: imageUrlList,
        lat: latitudeValue.toString(),
        lng: longitudeValue.toString(),
        parkingName: titleController.text,
      );
      await ffstore.collection(collectionParking).doc(documentID).set(parkingModel.toJson());

      await ffstore.collection(collectionSlots).doc(documentID).set({"totalSlots": 10});

      for (int index = 1; index <= 10; index++) {
        await ffstore
            .collection(collectionSlots) //
            .doc(documentID)
            .collection(documentID)
            .doc("Slot$index")
            .set({
          "slotName": "Slot $index",
          "status": "available",
        });
      }

      Navigator.of(context).pop();

      infoLog("i got success ");
      Utils.toast("Parking slot was added successfully!", toastLength: Toast.LENGTH_LONG);
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (BuildContext context) => const BottomBar()), (route) => false);

      videoSurveillanceValue = false;
      fullHoursAccessValue = false;
      lockedValue = false;
      coveredValue = false;
      monthlyRentValue = false;
      notifyListeners();
      titleController.clear();
      descriptionController.clear();
      addressController.clear();

      priceHourlyController.clear();
      priceDailyController.clear();
      priceWeeklyController.clear();
      priceMonthlyController.clear();
      pickedImages.clear();
      imageUrlList.clear();
    }
  }
}
