// ignore_for_file: use_build_context_synchronously

import 'dart:developer';
import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/pages/auth/login.dart';
import 'package:parkingproject/pages/auth/otp.dart';
import 'package:parkingproject/pages/bottomNavigationBar/bottom_navigation_bar.dart';
import 'package:parkingproject/services/shared_preference.dart';
import 'package:parkingproject/utils/error.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/my_logger.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:parkingproject/utils/utils.dart';

class AuthProvider extends ChangeNotifier {
  AuthProvider();

  UserModel userModel = UserModel();

  TextEditingController userNameController = TextEditingController();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController emailAddressController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController passwordConfirmController = TextEditingController();
  TextEditingController otpController = TextEditingController();
  TextEditingController houseNumberController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController zipCodeController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController countryController = TextEditingController();

  UserCredential? userCredential;
  String verificationPhoneId = '';

  String pickedImagePath = '';
  File? pickedFile;

  String countryCode = '41';
  String countryFlag = '🇨🇭';

  void getCountryCodeAndPhone(String flag, String code) {
    countryFlag = flag;
    countryCode = code;
    notifyListeners();
    log(countryFlag);
    log(countryCode);
  }

  bool isHidden = true;
  bool isHiddenConfirmPassword = true;

  void togglePasswordView() {
    isHidden = !isHidden;
    notifyListeners();
  }

  void toggleConfirmPasswordView() {
    isHiddenConfirmPassword = !isHiddenConfirmPassword;
    notifyListeners();
  }

  Stream<User?> get user => auth.authStateChanges();

  Future<void> signUpWithEmailAndPassword(BuildContext context) async {
    if (userNameController.text.isEmpty) {
      Utils.showCustomSnackBar(context, "Please enter user name");
    } else if (firstNameController.text.isEmpty) {
      Utils.showCustomSnackBar(context, "Please enter first name");
    } else if (lastNameController.text.isEmpty) {
      Utils.showCustomSnackBar(context, "Please enter last name");
    } else if (phoneNumberController.text.isEmpty) {
      Utils.showCustomSnackBar(context, "Please enter phone number");
    } else if (!RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(emailAddressController.text)) {
      Utils.showCustomSnackBar(context, "Please enter a valid email address.");
    } else if (passwordController.text.isEmpty) {
      Utils.showCustomSnackBar(context, "Please enter password");
    } else if (passwordController.text.length < 8) {
      Utils.showCustomSnackBar(context, "Please enter eight character password");
    } else if (!RegExp(r'[A-Z]').hasMatch(passwordController.text)) {
      Utils.showCustomSnackBar(context, "Password should be at least one capital letter.");
    } else if (!RegExp(r'[0-9]').hasMatch(passwordController.text)) {
      Utils.showCustomSnackBar(context, "Password should be at least one number.");
    } else if (!RegExp(r'[!@#\$&*~]').hasMatch(passwordController.text)) {
      Utils.showCustomSnackBar(context, "Password should be at least one special character.");
    } else if ((passwordController.text.isEmpty || passwordConfirmController.text.isEmpty)) {
      Utils.showCustomSnackBar(context, "Please enter password in both fields");
    } else if (passwordController.text != passwordConfirmController.text) {
      Utils.showCustomSnackBar(context, "Password mismatch");
    } else {
      log("continue");
      hideKeyBoard(context);
      String phoneNumber = '+$countryCode${phoneNumberController.text.trim()}';

      showLoadingDialog(context);

      String? token = await fcm.getToken();
      String? apnsToken = await fcm.getAPNSToken();
      try {
        UserCredential userCredential = await auth.createUserWithEmailAndPassword(
          email: emailAddressController.text.trim().toLowerCase(),
          password: passwordController.text,
        );

        if (userCredential.user != null) {
          UserModel userModel = UserModel(
            uid: userCredential.user!.uid,
            userName: userNameController.text,
            firstName: firstNameController.text,
            lastName: lastNameController.text,
            phoneNumber: phoneNumber,
            emailAddress: emailAddressController.text.trim().toLowerCase(),
            password: passwordController.text,
            joiningDate: DateTime.now().millisecondsSinceEpoch,
            fcmToken: Platform.isAndroid ? token : apnsToken,
            deviceType: Platform.isAndroid ? "android" : "ios",
            address: "",
            city: "",
            country: "",
            houseNumber: "",
            zipCode: "",
            isProfileComplete: true,
            profileImgUrl: "",
          );
          await ffstore
              .collection(collectionUsers) //
              .doc(userCredential.user!.uid)
              .set(userModel.toJson());
          await phoneSignUp(context);
        }
      } on FirebaseAuthException catch (e) {
        emailAddressController.clear();
        passwordController.clear();

        log("Error code is ${e.code}");
        auth.signOut();
        Navigator.of(context).pop();
        String errorMessage = "An error occurred. Please try again.";
        errorMessage = getMessageFromErrorCode(e.code);
        Utils.showCustomSnackBar(context, errorMessage);
      } catch (e) {
        log(e.toString());
      }
    }
  }
  //17
  //17

  Future<void> signInWithEmailAndPassword(BuildContext context) async {
    if ((emailAddressController.text.isEmpty && passwordController.text.isEmpty)) {
      Utils.showCustomSnackBar(context, "Please enter email and password.");
    } else if (emailAddressController.text.isEmpty) {
      Utils.showCustomSnackBar(context, "Please enter email address.");
    } else if (passwordController.text.isEmpty) {
      Utils.showCustomSnackBar(context, "Please enter password");
    } else if (passwordController.text.length < 6) {
      Utils.showCustomSnackBar(context, "Password must be six or greater than six");
    } else if (!RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(emailAddressController.text)) {
      Utils.showCustomSnackBar(context, "Please enter a valid email address.");
    } else {
      showLoadingDialog(context);

      await ffstore
          .collection(collectionUsers) //
          .where("emailAddress", isEqualTo: emailAddressController.text.trim().toLowerCase())
          .get()
          .then((value) async {
        if (value.docs.isNotEmpty) {
          try {
            UserCredential userCredential = await auth.signInWithEmailAndPassword(
              email: emailAddressController.text.trim().toLowerCase(),
              password: passwordController.text,
            );
            if (userCredential.user != null) {
              if (!userCredential.user!.emailVerified) {
                await userCredential.user?.sendEmailVerification();
                auth.signOut();
                Navigator.of(context).pop();

                Utils.errorToast(
                  "Your email is not verified. We have send a confirmation email and click on a link to verify email address after that you can login.",
                  toastLength: Toast.LENGTH_LONG,
                );
              } else {
                await updateFCMToken();
                initializeUserModel(auth.currentUser!.uid);

                Helper.setBoolean(Helper.isLogin, true);
                Navigator.of(context).pop();
                emailAddressController.clear();
                passwordController.clear();
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (BuildContext context) => const BottomBar()), (route) => false);
              }
            }
          } on FirebaseAuthException catch (e) {
            log("Catch exception :  ${e.code}");
            Navigator.of(context).pop();
            // auth.signOut();

            if (e.code == 'user-not-found') {
              print('No user found for that email.');
              Utils.showCustomSnackBar(context, "User does not exist. Please register !");
            } else if (e.code == 'wrong-password') {
              print('Wrong password provided for that user.');
              Utils.showCustomSnackBar(context, "Wrong password provided for that user.");
            } else if (e.code == 'invalid-credential') {
              Utils.showCustomSnackBar(context, "Email or password is incorrect");
            } else if (e.code == 'too-many-requests') {
              Utils.showCustomSnackBar(context, "Too many requests to log into this account. Please try later !");
            } else {
              infoLog("No exception found");
            }
          }
        } else {
          Navigator.of(context).pop();
          Utils.errorToast("User does not exist. Please register !", toastLength: Toast.LENGTH_LONG);
        }
      });
    }
  }

  Future<void> phoneSignUp(BuildContext context, {bool isResendOtp = false}) async {
    log("inside phone sign Up");
    String phoneNumber = '+$countryCode${phoneNumberController.text.trim()}';

    int? forceResendToken;
    log("phone number $phoneNumber ");
    await auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        try {
          log("in try catch of phoneSignUp()");
          final userCredential = await FirebaseAuth.instance.currentUser?.linkWithCredential(credential);
          log("userCredential.user in verificationCompleted is: ${userCredential?.user}");
          log("inside verificationCompleted ");
          // await auth.signInWithCredential(credential);

          await ffstore.collection(collectionUsers).doc(userCredential!.user!.uid).update({
            "phoneNumber": phoneNumber,
            "isPhoneLinked": true,
          });

          initializeUserModel(auth.currentUser!.uid);
          Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (BuildContext context) => const BottomBar()), (route) => false);
        } on FirebaseAuthException catch (e) {
          emailAddressController.clear();
          passwordController.clear();
          auth.signOut();
          log("FirebaseAuthException ${e.toString()}");
          String errorMessage = "An error occurred. Please try again.";
          errorMessage = getMessageFromErrorCode(e.code);
          Utils.showCustomSnackBar(context, errorMessage);
        } catch (e) {
          emailAddressController.clear();
          passwordController.clear();
          auth.signOut();
          log("FirebaseAuthException ${e.toString()}");
        }
      },
      verificationFailed: (FirebaseAuthException exception) {
        auth.signOut();
        emailAddressController.clear();
        passwordController.clear();
        Navigator.of(context).pop();
        log("inside verificationFailed");
        String errorMessage = "An error occurred. Please try again.";
        errorMessage = getMessageFromErrorCode(exception.code);
        Utils.showCustomSnackBar(context, errorMessage);
      },
      codeSent: (String verificationId, int? resendToken) {
        log("inside codeSent");
        forceResendToken = resendToken;
        verificationPhoneId = verificationId;
        Navigator.of(context).pop();
        emailAddressController.clear();
        passwordController.clear();
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => OTPScreen()));

        notifyListeners();
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        log("inside codeAutoRetrievalTimeout");
        verificationPhoneId = verificationId;
      },
      timeout: const Duration(seconds: 60),
      forceResendingToken: isResendOtp ? forceResendToken : null,
    );

    notifyListeners();
  }

  Future<void> phoneSignUpMissingLinkedPhone(BuildContext context, {bool isResendOtp = false}) async {
    log("inside phoneSignUpMissingLinkedPhone sign Up");
    String phoneNumber = '+$countryCode${phoneNumberController.text.trim()}';

    int? forceResendToken;
    log("phone number $phoneNumber ");
    showLoadingDialog(context);

    await auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        try {
          log("in try catch of phoneSignUp()");
          final UserCredential? userCredential = await FirebaseAuth.instance.currentUser?.linkWithCredential(credential);
          log("userCredential.user in verificationCompleted is: ${userCredential?.user}");
          log("inside verificationCompleted ");

          await ffstore.collection(collectionUsers).doc(userCredential!.user!.uid).update({
            "phoneNumber": phoneNumber,
            "isPhoneLinked": true,
          });

          initializeUserModel(auth.currentUser!.uid);
          Navigator.of(context).pop();
          Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (BuildContext context) => const BottomBar()), (route) => false);
        } on FirebaseAuthException catch (e) {
          auth.signOut();
          log("FirebaseAuthException ${e.toString()}");

          String errorMessage = "An error occurred. Please try again.";
          errorMessage = getMessageFromErrorCode(e.code);
          Utils.showCustomSnackBar(context, errorMessage);
        } catch (e) {
          auth.signOut();

          log("FirebaseAuthException ${e.toString()}");
        }
      },
      verificationFailed: (FirebaseAuthException exception) {
        auth.signOut();
        Navigator.of(context).pop();
        log("inside verificationFailed");
        String errorMessage = "An error occurred. Please try again.";
        errorMessage = getMessageFromErrorCode(exception.code);
        Utils.showCustomSnackBar(context, errorMessage);
      },
      codeSent: (String verificationId, int? resendToken) {
        log("inside codeSent");
        forceResendToken = resendToken;
        verificationPhoneId = verificationId;
        Navigator.of(context).pop();
        Utils.toast("Code sent successfully Please verify your number !");

        pageNavigator(context, const OTPScreen());
        notifyListeners();
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        log("inside codeAutoRetrievalTimeout");
        verificationPhoneId = verificationId;
      },
      timeout: const Duration(seconds: 60),
      forceResendingToken: isResendOtp ? forceResendToken : null,
    );

    notifyListeners();
  }

  Future<void> verifyOTP(String verificationId, String smsCode, BuildContext context) async {
    log(smsCode);
    String phoneNumber = '+$countryCode${phoneNumberController.text.trim()}';
    showLoadingDialog(context);
    try {
      final PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: smsCode,
      );
      final userCredential = await FirebaseAuth.instance.currentUser?.linkWithCredential(credential);
      log("userCredential.user in _verifyOTP is: ${userCredential?.user.toString()}");
      log("userCredential.user in _verifyOTP is: ${userCredential?.user!.getIdToken().toString()}");

      await ffstore.collection(collectionUsers).doc(userCredential!.user!.uid).update({
        "phoneNumber": phoneNumber,
        "isPhoneLinked": true,
      });

      log('User :${userCredential.user}');
      initializeUserModel(auth.currentUser!.uid);
      auth.currentUser?.sendEmailVerification();
      emailAddressController.clear();
      passwordController.clear();

      Navigator.of(context).pop();
      auth.signOut();
      Utils.toast(
        "We have send a verification email Please verify your email",
        toastLength: Toast.LENGTH_LONG,
      );
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (BuildContext context) => const LoginScreen()), (route) => false);
    } on FirebaseAuthException catch (e) {
      Navigator.of(context).pop();
      auth.signOut();
      log("FirebaseAuthException ${e.toString()}");
      String errorMessage = "An error occurred. Please try again.";
      errorMessage = getMessageFromErrorCode(e.code);
      Utils.showCustomSnackBar(context, errorMessage);
    } catch (e) {
      auth.signOut();
      log("FirebaseAuthException ${e.toString()}");
    }
    notifyListeners();
  }

  pickImageForProfile(BuildContext context, ImageSource source) async {
    try {
      final img = await ImagePicker().pickImage(source: source);
      if (img == null) {
        return;
      } else {
        pickedFile = File(img.path);
        pickedImagePath = img.path;
      }
      notifyListeners();
    } on PlatformException catch (e) {
      Utils.showCustomSnackBar(context, e.toString());
    }
  }

  updateProfile(context) async {
    showLoadingDialog(context);

    if (pickedFile != null && (pickedImagePath != null || pickedImagePath != "")) {
      Reference ref = fstorage.ref().child('Profile Images/${DateTime.now().toString()}');
      await ref.putFile(pickedFile!);
      await ref.getDownloadURL().then((value) async {
        log('Profile Image URL $value');
        await ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).update({
          "profileImgUrl": value,
        });
      }).catchError((onError) {
        log(onError.toString());
      });
    }

    await ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).update(
      {
        "userName": userNameController.text,
        "firstName": firstNameController.text,
        "lastName": lastNameController.text,
        "address": addressController.text,
        "houseNumber": houseNumberController.text,
        "zipCode": zipCodeController.text,
        "country": countryController.text,
        "city": cityController.text,
      },
    ).catchError((onError) {
      log(onError.toString());
    });
    initializeUserModel(auth.currentUser!.uid);
    Navigator.of(context).pop();
  }

  completeUserProfile(context) async {
    if (houseNumberController.text.isEmpty) {
      Utils.errorToast("Please enter house number");
    } else if (zipCodeController.text.isEmpty) {
      Utils.errorToast("Please enter Zip Code");
    } else if (cityController.text.isEmpty) {
      Utils.errorToast("Please enter city");
    } else if (countryController.text.isEmpty) {
      Utils.errorToast("Please enter country");
    } else {
      showLoadingDialog(context);

      if (pickedFile != null && (pickedImagePath != null || pickedImagePath != "")) {
        Reference ref = fstorage.ref().child('Profile Images/${DateTime.now().toString()}');
        await ref.putFile(pickedFile!);
        await ref.getDownloadURL().then((value) async {
          log('Profile Image URL $value');
          await ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).update({
            "profileImgUrl": value,
          });
        }).catchError((onError) {
          log(onError.toString());
        });
      }

      await ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).update(
        {
          // "userName": userNameController.text,
          // "firstName": firstNameController.text,
          // "lastName": lastNameController.text,
          "address": addressController.text,
          "houseNumber": houseNumberController.text,
          "zipCode": zipCodeController.text,
          "city": cityController.text,
          "country": countryController.text,
          "isProfileComplete": true,
        },
      ).catchError((onError) {
        Navigator.of(context).pop();

        log(onError.toString());
      });
      initializeUserModel(auth.currentUser!.uid);
      Navigator.of(context).pop();
      Navigator.of(context).pop();
      Utils.toast("Your profile is completed successfully now you can do booking");
    }
  }

  deleteUserFromFirebase() async {
    User? user = userCredential?.user;
    if (user != null) {
      try {
        await user.delete();
        log('User deleted successfully.');
      } catch (e) {
        log('Error deleting user: $e');
      }
    } else {
      log('No user currently signed in.');
    }
    notifyListeners();
  }

  initializeUserModel(String userId) async {
    userModel = await ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).get().then((value) => UserModel.fromJson(value.data() ?? {}));

    ffstore.collection(collectionUsers).doc(auth.currentUser!.uid).snapshots().listen((event) async {
      userModel = UserModel.fromJson(event.data() ?? {});
    });
    notifyListeners();
  }

  clearControllers() {
    userNameController.clear();
    phoneNumberController.clear();
    emailAddressController.clear();
    passwordController.clear();
  }

  sendPasswordResetEmail(context) async {
    if (emailAddressController.text.isEmpty) {
      Utils.showCustomSnackBar(context, "Please enter your email address .");
    } else if (!RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(emailAddressController.text)) {
      Utils.showCustomSnackBar(context, "Please enter a valid email address !");
    } else {
      showLoadingDialog(context);
      await ffstore.collection(collectionUsers).where("emailAddress", isEqualTo: emailAddressController.text.trim()).get().then((querySnapshot) async {
        if (querySnapshot.docs.isNotEmpty) {
          await auth.sendPasswordResetEmail(email: emailAddressController.text.trim());
          emailAddressController.clear();

          Navigator.of(context).pop();
          Utils.toast("Password reset email sent successfully", toastLength: Toast.LENGTH_LONG);
          emailAddressController.clear();
          Navigator.of(context).pop();
        } else {
          Navigator.of(context).pop();
          Utils.errorToast("No user found for the provided email address");
        }
      });
    }
  }
}
