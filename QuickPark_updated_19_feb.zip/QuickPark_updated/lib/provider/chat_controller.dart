import 'dart:async';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/models/chat_models/chat_head_model.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/pages/chat/chat_screen.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:provider/provider.dart';

class ChatController extends GetxController {
  static ChatController instance = Get.find();

  RxBool showSearch = false.obs;

  RxBool isDeleting = false.obs;
  RxList deleteMsgIdList = [].obs;
  RxList deleteLeftMsgIdList = [].obs;
  RxList deleteAudioIdList = [].obs;
  RxList deleteAudioLinksList = [].obs;
  RxList deleteImageLinksList = [].obs;
  RxList deleteImageIdsList = [].obs;

  RxBool isPlayingMsg = false.obs;
  RxString selectedVoiceId = ''.obs;

  RxList<ChatHeadModel> chatHeads = RxList<ChatHeadModel>([]);

  RxString messageControllerText = "".obs;
  RxBool isActiveChat = true.obs;
  RxBool isKeyboardOpen = false.obs;
  RxBool isBlocked = false.obs;
  RxString blockedById = "".obs;

  RxDouble uploadProgress = 0.0.obs;

  void showSearchBar() {
    showSearch.value = !showSearch.value;
  }

  Stream<List<ChatHeadModel>>? myChatHeadsList(String? myId) {
    log('my id in chatController before getting stream is is: $myId');
    var myid = myId;

    if (myid != null && myid != '') {
      return ffstore.collection('ChatRoom').where('users', arrayContains: myId).snapshots().map((QuerySnapshot querySnap) {
        List<ChatHeadModel> myChats = [];
        querySnap.docs.forEach((doc) {
          if (doc["notDeletedFor"].asMap().containsValue(myId)) {
            // log("activeChatCount changed");
            ffstore
                .collection("ChatRoom")
                .doc(doc['chatRoomId'])
                .collection("chats")
                .where("isReceived", isEqualTo: false)
                .where("receivedById", isEqualTo: myId)
                .get()
                .then((value) {
              value.docs.forEach((element) {
                element.reference.update({'isReceived': true});
              });
            });
            myChats.add(ChatHeadModel.fromDocumentSnapshot(doc));
          }
        });
        update();
        chatHeads.refresh();
        update();
        return myChats;
      });
    } else {
      log("inside my chatHeads not null else");
      return null;
    }
  }

  messageReceivedStreamActivator(myId) {
    log(" messageReceivedStreamActivator caled");
    ffstore.collection(chatRoomCollection).where("notDeletedFor", arrayContains: myId).snapshots().listen((QuerySnapshot querySnap) {
      log("in messageReceivedStreamActivator listen");
      querySnap.docs.forEach((doc) {
        log("messageReceivedStreamActivator notDeletedFor changed");
        ffstore
            .collection(chatRoomCollection)
            .doc(doc['chatRoomId'])
            .collection("messages")
            .where("isReceived", isEqualTo: false)
            .where("receivedById", isEqualTo: myId)
            .get()
            .then((value) {
          value.docs.forEach((element) {
            element.reference.update({'isReceived': true});
          });
        });
        // }
      });
    });
  }

  getChatRoomId(String userID, String anotherUserID) {
    print("inside getChatRoomId a = $userID & b = $anotherUserID");
    var chatRoomId;
    if (userID.compareTo(anotherUserID) > 0) {
      chatRoomId = '$userID - $anotherUserID';
    } else {
      chatRoomId = '$anotherUserID - $userID';
    }
    return chatRoomId;
  }

//first time creating chat head
  createChatRoomAndStartConversation({required UserModel user1Model, required UserModel user2Model, required BuildContext context}) async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    showCircularLoadingDialog(context);
    log("inside createChatRoomAndStartConversation and userDetailsModel.uID is: ${authProvider.userModel.uid}"
        " and userDetailsModel.fullName is: ${authProvider.userModel.firstName}");
    List<String> users;
    List<String> searchParameters = [];
    log("id user 1 ${user2Model.uid}");
    log("id user 2 ${user1Model.uid}");
    if (user2Model.uid != user1Model.uid) {
      users = [
        "${user1Model.uid}",
        "${user2Model.uid}",
      ];
      String chatRoomId = getChatRoomId(user1Model.uid ?? "", user2Model.uid ?? "");
      var anotherUserId = user1Model.uid == authProvider.userModel.uid ? user2Model.uid : user1Model.uid;
      var anotherUserName = user1Model.uid == authProvider.userModel.uid ? "${user2Model.firstName}" : "${user1Model.firstName}";

      var myName = "${authProvider.userModel.firstName}";
      log("anotherUserId: $anotherUserId");

      for (int i = 0; i < anotherUserName.length; i++) {
        if (anotherUserName[i] != " ") {
          searchParameters.add(anotherUserName[i].toLowerCase());
          var wordUntil = anotherUserName.substring(0, i);
          log("wordUntil: $wordUntil");
          searchParameters.add(wordUntil);
        }
      }

      for (int i = 0; i < myName.length; i++) {
        if (myName[i] != " ") {
          searchParameters.add(myName[i].toLowerCase());
          var wordUntil = myName.substring(0, i);
          log("wordUntil: $wordUntil");
          searchParameters.add(wordUntil);
        }
      }

      //+code for searching the chat heads
      //+to be put in the search streamBuilder
      // ffstore.collection(chatRoomCollection)
      //     .where("passengerId", isEqualTo: userDetailsModel.currentUserId)
      //     .where("searchParameters", arrayContains: "varToSearch").snapshots();

      await ffstore.collection(chatRoomCollection).doc(chatRoomId).get().then((value) async {
        if (value.exists) {
          //+means chat head is already created
          Get.back();
          if (!value["notDeletedFor"].asMap().containsValue(auth.currentUser!.uid)) {
            await FirebaseFirestore.instance.collection('ChatRoom').doc(chatRoomId).update({
              "notDeletedFor": FieldValue.arrayUnion([auth.currentUser!.uid])
            });
            Get.to(() => ChatScreen(docs: value.data()));
          } else {
            Get.to(() => ChatScreen(docs: value.data()));
          }
          // Get.to(() => ChatScreen(docs: value.data()));
        } else {
          Map<String, dynamic> chatRoomMap = {
            "users": users,
            "searchParameters": searchParameters,
            "chatRoomId": chatRoomId,
            "user1Id": user1Model.uid,
            "user2Id": user2Model.uid,
            'user1Model': user1Model.toJson(),
            'user2Model': user2Model.toJson(),
            'isBlocked': false,
            'blockedById': "",
            'notDeletedFor': users,
            // 'inActiveFor': [userDetailsModel.uID],
            // 'notInActiveFor': [user2Model.id],
            'createdAt': DateTime.now().millisecondsSinceEpoch,
            'lastMessageAt': DateTime.now().millisecondsSinceEpoch,
            'lastMessage': '',
            'lastMessageType': '',
          };
          await ffstore.collection(chatRoomCollection).doc(chatRoomId).set(chatRoomMap).catchError((e) => print("error in generating an  chat  ${e.toString()}"));
          Get.back();
          Get.to(() => ChatScreen(docs: chatRoomMap));
        }
      });
    } else {
      Get.back();
      Get.defaultDialog(
        title: 'Error',
        middleText: "You cannot send message to yourself.",
      );
      print(
        'You can not send message to yourself.',
      );
    }
  }

  addConversationMessage(String chatRoomId, var time, String type, messageMap, String msg) async {
    log('called addConversationMessage');
    await FirebaseFirestore.instance.collection(chatRoomCollection).doc(chatRoomId).collection(messagesCollection).add(messageMap).then((value) async {
      await FirebaseFirestore.instance.collection(chatRoomCollection).doc(chatRoomId).update({
        'lastMessageAt': time,
        'lastMessage': msg,
        'lastMessageType': type,
      }).catchError((e) {
        log('\n\n\n\n error in updating last message and last message time ${e.toString()}');
      });
    }).catchError((e) {
      log('\n\n\n\n error in adding message ${e.toString()}');
    });
  }

  Future<void> deleteAChatRoom({String? chatRoomId}) async {
    log("inside chatRoom delete and chatRoom Id: $chatRoomId");
    try {
      log("inside chatRoom delete and chatRoom Id: $chatRoomId");
      await ffstore.collection("ChatRoom").doc(chatRoomId).update({
        "notDeletedFor": FieldValue.arrayRemove([auth.currentUser!.uid])
      }).then((value) async {
        await ffstore.collection(chatRoomCollection).doc(chatRoomId).collection(messagesCollection).get().then((value) {
          value.docs.forEach((element) {
            element.reference.update({
              "isDeletedFor": FieldValue.arrayUnion([auth.currentUser!.uid])
            });
          });
        });
      });
    } catch (e) {
      log("Following error was thrown in chat deletion: ${e.toString()}. Please try again.");
    }
  }

  Future<DocumentSnapshot<Map<String, dynamic>>> getAChatRoomInfo(String chatRoomId) async {
    return FirebaseFirestore.instance.collection(chatRoomCollection).doc(chatRoomId).get();
  }

  getConversationMessage(String chatRoomId) async {
    return ffstore.collection(chatRoomCollection).doc(chatRoomId).collection(messagesCollection).orderBy('time').snapshots();
  }
}
