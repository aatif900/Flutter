import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/constants/enum.dart';
import 'package:parkingproject/localization/localization_const.dart';
import 'package:parkingproject/models/add_vehicle_model.dart';
import 'package:parkingproject/models/booking_model.dart';
import 'package:parkingproject/models/notification_model.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/pages/booking/ticket_screen.dart';
import 'package:parkingproject/pages/bottomNavigationBar/bottom_navigation_bar.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/loading_dialog.dart';
import 'package:parkingproject/utils/page_navigator.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

class BookingProvider extends ChangeNotifier {
  //

  //
  ParkingModel parkingModel = ParkingModel();
  VehicleModel? selectedVehicleModel;
  BookingModel? bookingModel;

  int? selectedIndex;

  double durationHour = 6.0;
  int calculatedParkingPrice = 0;

  int? selectedIndexForSlot;
  String selectedNameForSlot = "";

  updateSelectedParkingModel(ParkingModel? model) {
    parkingModel = model!;
    log("Selected Parking Model Value: ${parkingModel.toJson()}");
    notifyListeners();
  }

  selectVehicle(int index, VehicleModel vehicleModel) {
    selectedIndex = index;
    selectedVehicleModel = vehicleModel;

    notifyListeners();
    log("Selected Vehicle Model ${selectedVehicleModel?.toJson()}");
  }

  int calculatePrice() {
    log("inside calculating price ");
    log("parkingModel?.pricePerHour ${parkingModel.priceHourly}");
    log("inside calculate: Hours ${finalParkingDuration.inHours} Days ${finalParkingDuration.inDays}");
    int result = (parkingModel.priceHourly ?? 5) * (finalParkingDuration.inHours);
    calculatedParkingPrice = result;
    print("calculatedParkingPrice : $calculatedParkingPrice");
    notifyListeners();
    return result;
  }

  updatePrice(int value) {
    calculatedParkingPrice = value;
    notifyListeners();
  }

  changeDurationValue(dynamic value) {
    durationHour = value;
    notifyListeners();
  }

  DateTime roughEndDate = DateTime.now();

  updateRoughEndDate(DateTime dateTime) {
    roughEndDate = dateTime;
    notifyListeners();
  }

  //+Start Date & Time
  DateTime startParkingDateTime = DateTime.now();
  TextEditingController startParkingTimeController = TextEditingController();

  //!Date
  updateStartParkingDate(DateTime date) {
    startParkingDateTime = DateTime(
      date.year,
      date.month,
      date.day,
      DateTime.now().hour,
      DateTime.now().minute,
    );
    calculateDuration();
    calculatePrice();
    notifyListeners();
    log("startParkingDateTime  while selecting Date $startParkingDateTime");
  }

//!Time
  updateStartParkingTime(TimeOfDay timeOfDay) {
    startParkingDateTime = DateTime(
      startParkingDateTime.year,
      startParkingDateTime.month,
      startParkingDateTime.day,
      timeOfDay.hour,
      timeOfDay.minute,
    );
    startParkingTimeController.text = DateFormat.jm().format(startParkingDateTime);
    calculatePrice();
    calculateDuration();
    notifyListeners();
    log("startParkingDateTime while Selecting time  $startParkingDateTime");
  }

  //+END DATE TIME
  // DateTime endParkingDate = DateTime.now();
  DateTime endParkingDateTime = DateTime.now();
  TextEditingController endParkingTimeController = TextEditingController();

  updateEndParkingDate(DateTime date) {
    endParkingDateTime = DateTime(
      date.year,
      date.month,
      date.day,
      endParkingDateTime.hour,
      endParkingDateTime.minute,
    );
    calculateDuration();
    calculatePrice();

    notifyListeners();
    log("endParkingDateTime Date $endParkingDateTime");
  }

  updateEndParkingTime(TimeOfDay timeOfDay) {
    log("inside updating parking time");
    endParkingDateTime = DateTime(
      endParkingDateTime.year,
      endParkingDateTime.month,
      endParkingDateTime.day,
      timeOfDay.hour,
      timeOfDay.minute,
    );
    endParkingTimeController.text = DateFormat.jm().format(endParkingDateTime);
    calculateDuration();
    calculatePrice();
    notifyListeners();
    log("endParkingDateTime Date $endParkingDateTime");

    log("End parking  endParkingTimeController.text ${endParkingTimeController.text}");
  }

  String calculatedDuration = "3 Hours";

  Duration finalParkingDuration = Duration(days: 0, hours: 0, minutes: 0, seconds: 0, milliseconds: 0, microseconds: 0);

  String calculateDuration() {
    String result = "";

    if (startParkingDateTime.day == endParkingDateTime.day) {
      if (startParkingDateTime.day == endParkingDateTime.day) {
        Duration duration = endParkingDateTime.difference(startParkingDateTime);
        finalParkingDuration = duration;
        result = "${duration.inHours.toString()} Hours";
      } else {
        Duration duration = endParkingDateTime.difference(startParkingDateTime);
        finalParkingDuration = duration;

        result = "${duration.inDays.toString()} Days";
      }
    } else if (startParkingDateTime.day != endParkingDateTime.day) {
      Duration duration = endParkingDateTime.difference(startParkingDateTime);
      finalParkingDuration = duration;

      result = "${duration.inDays.toString()} Days";
    }
    calculatedDuration = result;

    log("durationValue jo chaiye thi $finalParkingDuration");
    log("durationValue jo chaiye inHours ${finalParkingDuration.inHours}");
    log("durationValue jo chaiye indays ${finalParkingDuration.inDays}");
    notifyListeners();
    return result;
  }

  updateStartHourTime(dynamic value) {
    startParkingTimeController.text = value;
    notifyListeners();
  }

  updateSelectedSlotNameAndIndex(String name, int index) {
    selectedIndexForSlot = index;
    selectedNameForSlot = name;
    notifyListeners();
  }

  bookedParking(context) async {
    AuthProvider authProvider = Provider.of<AuthProvider>(context, listen: false);
    showLoadingDialog(context);
    String bookingID = const Uuid().v4();

    bookingModel = BookingModel(
      documentID: bookingID,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      bookedById: authProvider.userModel.uid,
      parkingProviderId: parkingModel.parkingProviderId,
      bookedByName: "${authProvider.userModel.firstName} ${authProvider.userModel.lastName}",
      bookedByImage: authProvider.userModel.profileImgUrl,
      vehicleName: selectedVehicleModel?.vehicleType,
      duration: finalParkingDuration.inMinutes < 60
          ? "${finalParkingDuration.inMinutes} Minutes"
          : finalParkingDuration.inHours < 24
              ? "${finalParkingDuration.inHours} Hours"
              : finalParkingDuration.inDays == 1
                  ? "${finalParkingDuration.inDays} Day"
                  : "${finalParkingDuration.inDays} Days",
      parkingStartDate: startParkingDateTime.millisecondsSinceEpoch,
      parkingEndDate: endParkingDateTime.millisecondsSinceEpoch,
      startingTime: startParkingDateTime.millisecondsSinceEpoch,
      endingTime: endParkingDateTime.millisecondsSinceEpoch,
      pricePerHour: parkingModel.priceHourly,
      parkingSLot: selectedNameForSlot,
      parkingName: parkingModel.parkingName,
      parkingAddress: parkingModel.address,
      parkingImage: parkingModel.image,
      parkingPricePerHour: parkingModel.priceHourly,
      tax: 0,
      totalPrice: calculatedParkingPrice,
      phoneNumber: parkingModel.phoneNumber,
      parkingRating: parkingModel.rating,
      isSentStartNotification: false,
      isSentEndNotification: false,
      lat: parkingModel.lat,
      lng: parkingModel.lng,
      licencePlateNumber: selectedVehicleModel?.vehicleLicencePlate,
    );
    notifyListeners();
    log("bookingModel ${bookingModel?.toJson()}");
    await ffstore
        .collection(collectionBooking) //
        .doc(bookingID)
        .set(bookingModel!.toJson())
        .onError((error, stackTrace) => log("Something wrong"));
    log("Before closing loading dialog ");

    String id = Uuid().v4();

    NotificationModel notificationModel = NotificationModel(
      createdAt: DateTime.now().millisecondsSinceEpoch,
      title: "Booked Parking",
      description: "${authProvider.userModel.firstName} ${authProvider.userModel.lastName} booked a parking",
      userName: "${authProvider.userModel.firstName} ${authProvider.userModel.lastName}",
      type: "BookingCancel",
      userId: authProvider.userModel.uid,
      toSendID: authProvider.userModel.uid,
      notificationType: NotificationType.bookedParking.name,
      parkingStartDateTime: startParkingDateTime.millisecondsSinceEpoch,
      parkingEndDateTime: endParkingDateTime.millisecondsSinceEpoch,
      isSentStartNotification: false,
      isSentEndNotification: false,
      notifyUser: true,
    );
    await ffstore.collection(collectionNotifications).doc(id).set(notificationModel.toJson());

    Navigator.of(context).pop();
    // successDialog(MediaQuery.sizeOf(context), context);

    showDialog(
        context: context,
        builder: (context) {
          Size size = MediaQuery.sizeOf(context);
          return Dialog(
            insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 3.0, vertical: fixPadding * 2.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            backgroundColor: whiteColor,
            child: Container(
              padding: const EdgeInsets.all(fixPadding * 2.0),
              width: double.maxFinite,
              child: ListView(
                shrinkWrap: true,
                children: [
                  Image.asset(
                    "assets/arrived/success.png",
                    height: size.width * 0.25,
                    width: size.width * 0.25,
                  ),
                  heightSpace,
                  heightSpace,
                  Text(
                    getTranslation(context, 'confirmation.successful'),
                    style: bold22LightBlack,
                    textAlign: TextAlign.center,
                  ),
                  heightSpace,
                  Text(
                    getTranslation(context, 'confirmation.successful_text'),
                    style: semibold16Grey,
                    textAlign: TextAlign.center,
                  ),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  GestureDetector(
                    onTap: () {


                      pageNavigator(context, TicketScreen(bookingModel: bookingModel, parkingModel: parkingModel));
                    },
                    child: Container(
                      width: double.maxFinite,
                      padding: const EdgeInsets.all(fixPadding * 1.4),
                      margin: const EdgeInsets.symmetric(horizontal: fixPadding),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.circular(10.0),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 6,
                            color: shadowColor.withOpacity(0.1),
                          ),
                          buttonShadow,
                        ],
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        getTranslation(context, 'confirmation.view_parking_ticket'),
                        style: bold18TextColor,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  heightSpace,
                  heightSpace,
                  GestureDetector(
                    onTap: () {
                      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (BuildContext context) => const BottomBar()), (route) => false);
                    },
                    child: Container(
                      width: double.maxFinite,
                      padding: const EdgeInsets.all(fixPadding * 1.4),
                      margin: const EdgeInsets.symmetric(horizontal: fixPadding),
                      decoration: BoxDecoration(
                        color: primaryColor,
                        borderRadius: BorderRadius.circular(10.0),
                        boxShadow: [buttonShadow],
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        getTranslation(context, 'confirmation.back_home'),
                        style: bold18LightBlack,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  successDialog(Size size, context) {
    return showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 3.0, vertical: fixPadding * 2.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            backgroundColor: whiteColor,
            child: Container(
              padding: const EdgeInsets.all(fixPadding * 2.0),
              width: double.maxFinite,
              child: ListView(
                shrinkWrap: true,
                children: [
                  Image.asset(
                    "assets/arrived/success.png",
                    height: size.width * 0.25,
                    width: size.width * 0.25,
                  ),
                  heightSpace,
                  heightSpace,
                  Text(
                    getTranslation(context, 'confirmation.successful'),
                    style: bold22LightBlack,
                    textAlign: TextAlign.center,
                  ),
                  heightSpace,
                  Text(
                    getTranslation(context, 'confirmation.successful_text'),
                    style: semibold16Grey,
                    textAlign: TextAlign.center,
                  ),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  GestureDetector(
                    onTap: () {
                      Navigator.pushNamed(context, '/parkingTicket', arguments: {"id": 1}).then((value) => Navigator.pop(context));
                    },
                    child: Container(
                      width: double.maxFinite,
                      padding: const EdgeInsets.all(fixPadding * 1.4),
                      margin: const EdgeInsets.symmetric(horizontal: fixPadding),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.circular(10.0),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 6,
                            color: shadowColor.withOpacity(0.1),
                          ),
                          buttonShadow,
                        ],
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        getTranslation(context, 'confirmation.view_parking_ticket'),
                        style: bold18TextColor,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  heightSpace,
                  heightSpace,
                  GestureDetector(
                    onTap: () {
                      Navigator.pushNamed(context, '/bottomBar');
                    },
                    child: Container(
                      width: double.maxFinite,
                      padding: const EdgeInsets.all(fixPadding * 1.4),
                      margin: const EdgeInsets.symmetric(horizontal: fixPadding),
                      decoration: BoxDecoration(
                        color: primaryColor,
                        borderRadius: BorderRadius.circular(10.0),
                        boxShadow: [buttonShadow],
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        getTranslation(context, 'confirmation.back_home'),
                        style: bold18LightBlack,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}
