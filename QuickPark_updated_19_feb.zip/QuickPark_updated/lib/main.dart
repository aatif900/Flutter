import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:parkingproject/constants/constant.dart';
import 'package:parkingproject/models/parking_model.dart';
import 'package:parkingproject/models/user_model.dart';
import 'package:parkingproject/pages/splash_screen.dart';
import 'package:parkingproject/provider/auth_provider.dart';
import 'package:parkingproject/provider/filter_provider.dart';
import 'package:parkingproject/provider/home_provider.dart';
import 'package:parkingproject/services/firebase_services.dart';

import 'package:parkingproject/services/shared_preference.dart';
import 'package:parkingproject/theme/theme.dart';
import 'package:parkingproject/utils/routes.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'localization/localization.dart';
import 'localization/localization_const.dart';
import 'pages/screens.dart';
import 'provider/booking_provider.dart';
import 'provider/parking_provider.dart';




Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await Helper.initPref();


  init();

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  static void setLocale(BuildContext context, Locale locale) {
    _MyAppState state = context.findAncestorStateOfType<_MyAppState>()!;
    state.setLocale(locale);
  }

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  Locale? _locale;

  void setLocale(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  @override
  void initState() {
    // initPlatformState();
    WidgetsBinding.instance.addObserver(this);

    super.initState();
  }

  @override
  void didChangeDependencies() {
    getLocale().then((locale) {
      setState(() {
        _locale = locale;
      });
    });
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(statusBarColor: Colors.transparent, statusBarIconBrightness: Brightness.dark),
    );
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => HomeProvider()),
        ChangeNotifierProvider(create: (_) => ParkingProvider()),
        ChangeNotifierProvider(create: (_) => BookingProvider()),
        ChangeNotifierProvider(create: (_) => FilterProvider()),
        StreamProvider(
          create: (_) => FirebaseServices().getAllUserList(),
          initialData: const [],
        )
      ],
      child: StreamProvider<List<ParkingModel>>(
        initialData: const [],
        create: (BuildContext context) {
          return FirebaseServices().parkingListStream;
        },
        child: StreamProvider<List<UserModel>>.value(
          initialData: const [],
          value: FirebaseServices().getAllUserList(),
          child: GetMaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'FL QuickPark',
            theme: ThemeData(
              primarySwatch: Colors.blue,
              primaryColor: primaryColor,
              fontFamily: 'Mulish',
              scaffoldBackgroundColor: scaffoldBgColor,
              elevatedButtonTheme: ElevatedButtonThemeData(
                style: ElevatedButton.styleFrom(
                  elevation: 4,
                  fixedSize: Size(MediaQuery.sizeOf(context).width - 100, 40),
                  minimumSize: const Size(100, 40),
                  maximumSize: Size(MediaQuery.sizeOf(context).width - 100, 40),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
              ),
            ),
            // home: GoogleSearchPlacesApi(),

            home: const SplashScreen(),
            onGenerateRoute: routes,
            locale: _locale,
            supportedLocales: const [
              Locale('en'),
              Locale('hi'),
              Locale('id'),
              Locale('zh'),
              Locale('ar'),
            ],
            localizationsDelegates: [
              DemoLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
            ],
            localeResolutionCallback: (deviceLocale, supportedLocales) {
              for (var locale in supportedLocales) {
                if (locale.languageCode == deviceLocale?.languageCode) {
                  return deviceLocale;
                }
              }
              return supportedLocales.first;
            },
          ),
        ),
      ),
    );
  }
}

// nothing change just