package com.example.parkingproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
