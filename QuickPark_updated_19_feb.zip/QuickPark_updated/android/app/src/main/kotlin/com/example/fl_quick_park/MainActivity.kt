package com.example.fl_quick_park

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
